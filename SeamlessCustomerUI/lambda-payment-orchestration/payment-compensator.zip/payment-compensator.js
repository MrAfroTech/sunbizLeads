const AWS = require('aws-sdk');

// Initialize AWS SDK
const lambda = new AWS.Lambda();
const dynamodb = new AWS.DynamoDB.DocumentClient();

// Configuration
const PAYMENT_TRANSACTIONS_TABLE = process.env.PAYMENT_TRANSACTIONS_TABLE || 'payment-transactions';
const CIRCUIT_BREAKER_TABLE = process.env.CIRCUIT_BREAKER_TABLE || 'circuit-breaker-state';

/**
 * Main Lambda handler for payment compensation/rollback
 */
exports.handler = async (event, context) => {
  console.log('=== PAYMENT COMPENSATOR START ===');
  console.log('Event received:', JSON.stringify(event, null, 2));
  
  try {
    const { transactionId, successfulPayments } = event;
    
    if (!transactionId || !successfulPayments || !Array.isArray(successfulPayments)) {
      throw new Error('Invalid compensation request: missing transactionId or successfulPayments');
    }
    
    console.log(`Starting rollback for transaction: ${transactionId}`);
    console.log(`Rolling back ${successfulPayments.length} successful payments`);
    
    // Get transaction details
    const transaction = await getTransactionDetails(transactionId);
    if (!transaction) {
      throw new Error(`Transaction not found: ${transactionId}`);
    }
    
    // Mark rollback as attempted
    await markRollbackAttempted(transactionId);
    
    // Process rollbacks in parallel
    const rollbackResults = await processRollbacks(successfulPayments);
    
    // Analyze rollback results
    const analysis = analyzeRollbackResults(rollbackResults);
    
    // Update transaction status
    await updateTransactionStatus(transactionId, analysis);
    
    // Log compensation completion
    await logCompensationCompletion(transactionId, analysis);
    
    console.log('=== PAYMENT COMPENSATOR SUCCESS ===');
    
    return {
      statusCode: 200,
      body: JSON.stringify({
        success: true,
        transactionId,
        rollbackResults: analysis,
        message: 'Compensation process completed'
      })
    };
    
  } catch (error) {
    console.error('=== PAYMENT COMPENSATOR ERROR ===');
    console.error('Error in payment compensator:', error);
    console.error('Error stack:', error.stack);
    
    // Try to log the error
    try {
      await logCompensationError(event.transactionId, error);
    } catch (logError) {
      console.error('Failed to log compensation error:', logError);
    }
    
    return {
      statusCode: 500,
      body: JSON.stringify({
        success: false,
        error: 'Compensation process failed',
        message: error.message
      })
    };
  }
};

/**
 * Get transaction details from DynamoDB
 */
async function getTransactionDetails(transactionId) {
  try {
    const result = await dynamodb.get({
      TableName: PAYMENT_TRANSACTIONS_TABLE,
      Key: { transactionId }
    }).promise();
    
    return result.Item;
  } catch (error) {
    console.error('Error getting transaction details:', error);
    return null;
  }
}

/**
 * Mark rollback as attempted
 */
async function markRollbackAttempted(transactionId) {
  await dynamodb.update({
    TableName: PAYMENT_TRANSACTIONS_TABLE,
    Key: { transactionId },
    UpdateExpression: 'SET rollbackAttempted = :rollbackAttempted, updatedAt = :updatedAt',
    ExpressionAttributeValues: {
      ':rollbackAttempted': true,
      ':updatedAt': new Date().toISOString()
    }
  }).promise();
}

/**
 * Process rollbacks for all successful payments
 */
async function processRollbacks(successfulPayments) {
  const rollbackPromises = successfulPayments.map(async (payment) => {
    try {
      console.log(`Processing rollback for vendor: ${payment.vendorId}`);
      
      // Get vendor payment details
      const vendorPayment = await getVendorPaymentDetails(payment.transactionId, payment.vendorId);
      
      if (!vendorPayment) {
        throw new Error(`Vendor payment not found: ${payment.vendorId}`);
      }
      
      // Call the appropriate rollback Lambda function
      const rollbackResult = await callRollbackLambda(vendorPayment, payment);
      
      // Update vendor payment status
      await updateVendorPaymentRollbackStatus(payment.transactionId, payment.vendorId, {
        status: rollbackResult.success ? 'ROLLED_BACK' : 'ROLLBACK_FAILED',
        rollbackTransactionId: rollbackResult.rollbackTransactionId,
        rollbackErrorMessage: rollbackResult.error,
        rolledBackAt: new Date().toISOString()
      });
      
      return {
        vendorId: payment.vendorId,
        success: rollbackResult.success,
        rollbackTransactionId: rollbackResult.rollbackTransactionId,
        error: rollbackResult.error,
        amount: payment.amount,
        originalTransactionId: payment.transactionId
      };
      
    } catch (error) {
      console.error(`Error processing rollback for vendor ${payment.vendorId}:`, error);
      
      // Mark rollback as failed
      await updateVendorPaymentRollbackStatus(payment.transactionId, payment.vendorId, {
        status: 'ROLLBACK_FAILED',
        rollbackErrorMessage: error.message,
        rolledBackAt: new Date().toISOString()
      });
      
      return {
        vendorId: payment.vendorId,
        success: false,
        error: error.message,
        amount: payment.amount,
        originalTransactionId: payment.transactionId
      };
    }
  });
  
  return await Promise.all(rollbackPromises);
}

/**
 * Get vendor payment details
 */
async function getVendorPaymentDetails(transactionId, vendorId) {
  try {
    const result = await dynamodb.get({
      TableName: PAYMENT_TRANSACTIONS_TABLE,
      Key: {
        pk: transactionId,
        sk: `vendor#${vendorId}`
      }
    }).promise();
    
    return result.Item;
  } catch (error) {
    console.error('Error getting vendor payment details:', error);
    return null;
  }
}

/**
 * Call the appropriate rollback Lambda function
 */
async function callRollbackLambda(vendorPayment, payment) {
  try {
    const rollbackFunctionName = `${vendorPayment.posSystem}-payment-rollback`;
    
    const rollbackParams = {
      FunctionName: rollbackFunctionName,
      Payload: JSON.stringify({
        vendorId: vendorPayment.vendorId,
        originalTransactionId: vendorPayment.posTransactionId,
        amount: vendorPayment.amount,
        items: vendorPayment.items,
        transactionId: payment.transactionId,
        reason: 'multi_vendor_orchestration_failure'
      })
    };
    
    console.log(`Calling rollback function: ${rollbackFunctionName}`);
    
    const result = await lambda.invoke(rollbackParams).promise();
    const response = JSON.parse(result.Payload);
    
    return {
      success: response.success || false,
      rollbackTransactionId: response.rollbackTransactionId,
      error: response.error
    };
    
  } catch (error) {
    console.error('Error calling rollback Lambda:', error);
    return {
      success: false,
      error: error.message
    };
  }
}

/**
 * Update vendor payment rollback status
 */
async function updateVendorPaymentRollbackStatus(transactionId, vendorId, updates) {
  await dynamodb.update({
    TableName: PAYMENT_TRANSACTIONS_TABLE,
    Key: {
      pk: transactionId,
      sk: `vendor#${vendorId}`
    },
    UpdateExpression: 'SET #status = :status, rollbackTransactionId = :rollbackTransactionId, rollbackErrorMessage = :rollbackErrorMessage, rolledBackAt = :rolledBackAt, updatedAt = :updatedAt',
    ExpressionAttributeNames: {
      '#status': 'status'
    },
    ExpressionAttributeValues: {
      ':status': updates.status,
      ':rollbackTransactionId': updates.rollbackTransactionId || null,
      ':rollbackErrorMessage': updates.rollbackErrorMessage || null,
      ':rolledBackAt': updates.rolledBackAt,
      ':updatedAt': new Date().toISOString()
    }
  }).promise();
}

/**
 * Analyze rollback results
 */
function analyzeRollbackResults(rollbackResults) {
  const successfulRollbacks = rollbackResults.filter(result => result.success);
  const failedRollbacks = rollbackResults.filter(result => !result.success);
  
  const totalAmount = rollbackResults.reduce((sum, result) => sum + result.amount, 0);
  const rolledBackAmount = successfulRollbacks.reduce((sum, result) => sum + result.amount, 0);
  
  let finalStatus = 'ROLLED_BACK';
  
  if (failedRollbacks.length > 0) {
    finalStatus = 'PARTIAL_ROLLBACK';
  }
  
  return {
    successfulRollbacks,
    failedRollbacks,
    totalAmount,
    rolledBackAmount,
    finalStatus,
    rollbackSuccessRate: successfulRollbacks.length / rollbackResults.length
  };
}

/**
 * Update transaction status
 */
async function updateTransactionStatus(transactionId, analysis) {
  await dynamodb.update({
    TableName: PAYMENT_TRANSACTIONS_TABLE,
    Key: { transactionId },
    UpdateExpression: 'SET #status = :status, rollbackResults = :rollbackResults, updatedAt = :updatedAt',
    ExpressionAttributeNames: {
      '#status': 'status'
    },
    ExpressionAttributeValues: {
      ':status': analysis.finalStatus,
      ':rollbackResults': analysis,
      ':updatedAt': new Date().toISOString()
    }
  }).promise();
}

/**
 * Log compensation completion
 */
async function logCompensationCompletion(transactionId, analysis) {
  const logEntry = {
    transactionId,
    type: 'COMPENSATION_COMPLETED',
    timestamp: new Date().toISOString(),
    results: analysis,
    success: analysis.failedRollbacks.length === 0
  };
  
  // Store in DynamoDB for audit trail
  await dynamodb.put({
    TableName: 'compensation-logs',
    Item: {
      logId: `log_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      ...logEntry
    }
  }).promise();
  
  console.log('Compensation completion logged:', logEntry);
}

/**
 * Log compensation error
 */
async function logCompensationError(transactionId, error) {
  const logEntry = {
    transactionId,
    type: 'COMPENSATION_ERROR',
    timestamp: new Date().toISOString(),
    error: {
      message: error.message,
      stack: error.stack
    }
  };
  
  // Store in DynamoDB for audit trail
  await dynamodb.put({
    TableName: 'compensation-logs',
    Item: {
      logId: `error_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      ...logEntry
    }
  }).promise();
  
  console.log('Compensation error logged:', logEntry);
}
