const AWS = require('aws-sdk');

// Initialize AWS SDK
const lambda = new AWS.Lambda();
const dynamodb = new AWS.DynamoDB.DocumentClient();

// Configuration
const VENDOR_CONFIGURATIONS_TABLE = process.env.VENDOR_CONFIGURATIONS_TABLE || 'vendor-configurations';
const CIRCUIT_BREAKER_TABLE = process.env.CIRCUIT_BREAKER_TABLE || 'circuit-breaker-state';
const PAYMENT_TRANSACTIONS_TABLE = process.env.PAYMENT_TRANSACTIONS_TABLE || 'payment-transactions';

// Circuit breaker configuration
const CIRCUIT_BREAKER_CONFIG = {
  failureThreshold: 5,
  recoveryTimeout: 120000, // 2 minutes
  timeout: 30000 // 30 seconds
};

/**
 * Main Lambda handler for payment orchestration
 */
exports.handler = async (event, context) => {
  console.log('=== PAYMENT ORCHESTRATOR START ===');
  console.log('Event received:', JSON.stringify(event, null, 2));
  
  try {
    const { cartItems, paymentDetails, customerInfo } = JSON.parse(event.body);
    
    // Validate input
    if (!cartItems || !paymentDetails || !customerInfo) {
      return createResponse(400, {
        success: false,
        error: 'Missing required fields: cartItems, paymentDetails, customerInfo'
      });
    }

    // Generate transaction ID
    const transactionId = `txn_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    // Group items by vendor
    const vendorGroups = groupItemsByVendor(cartItems);
    console.log('Vendor groups:', JSON.stringify(vendorGroups, null, 2));
    
    // Create transaction record
    const transaction = await createTransactionRecord(transactionId, customerInfo, cartItems, paymentDetails);
    
    // Perform health checks on all vendors
    const healthCheckResults = await performHealthChecks(vendorGroups);
    
    // Check if any vendors are unhealthy
    const unhealthyVendors = healthCheckResults.filter(result => !result.healthy);
    
    if (unhealthyVendors.length > 0) {
      console.log('Unhealthy vendors detected:', unhealthyVendors);
      
      // Handle graceful degradation
      const gracefulDegradation = await handleGracefulDegradation(vendorGroups, unhealthyVendors);
      
      if (gracefulDegradation.available.length === 0) {
        return createResponse(503, {
          success: false,
          error: 'All vendors are currently unavailable',
          recommendation: 'try_again_later'
        });
      }
      
      // Update transaction with graceful degradation info
      await updateTransactionWithGracefulDegradation(transactionId, gracefulDegradation);
      
      // Proceed with available vendors only
      vendorGroups = gracefulDegradation.available;
    }
    
    // Create vendor payment records
    const vendorPayments = await createVendorPaymentRecords(transactionId, vendorGroups);
    
    // Process payments in parallel
    const paymentResults = await processVendorPayments(vendorPayments, paymentDetails);
    
    // Analyze results
    const analysis = analyzePaymentResults(paymentResults);
    
    // Update transaction status
    await updateTransactionStatus(transactionId, analysis);
    
    // Handle rollback if needed
    if (analysis.rollbackRequired) {
      console.log('Rollback required, triggering compensation Lambda');
      await triggerCompensationLambda(transactionId, analysis.successfulPayments);
    }
    
    console.log('=== PAYMENT ORCHESTRATOR SUCCESS ===');
    
    return createResponse(200, {
      success: true,
      transactionId,
      status: analysis.finalStatus,
      successfulVendors: analysis.successfulPayments,
      failedVendors: analysis.failedPayments,
      totalAmount: analysis.totalAmount,
      processedAmount: analysis.successfulAmount,
      rollbackRequired: analysis.rollbackRequired
    });
    
  } catch (error) {
    console.error('=== PAYMENT ORCHESTRATOR ERROR ===');
    console.error('Error in payment orchestrator:', error);
    console.error('Error stack:', error.stack);
    
    return createResponse(500, {
      success: false,
      error: 'Payment orchestration failed',
      message: error.message
    });
  }
};

/**
 * Group cart items by vendor
 */
function groupItemsByVendor(cartItems) {
  const vendorGroups = {};
  
  for (const item of cartItems) {
    const vendorId = item.vendorId;
    
    if (!vendorGroups[vendorId]) {
      vendorGroups[vendorId] = {
        vendorId,
        vendorName: item.vendorName,
        items: [],
        totalAmount: 0
      };
    }
    
    vendorGroups[vendorId].items.push(item);
    vendorGroups[vendorId].totalAmount += item.price * item.quantity;
  }
  
  return Object.values(vendorGroups);
}

/**
 * Create transaction record in DynamoDB
 */
async function createTransactionRecord(transactionId, customerInfo, cartItems, paymentDetails) {
  const totalAmount = cartItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  
  const transaction = {
    transactionId,
    customerId: customerInfo.email || customerInfo.id,
    totalAmount,
    status: 'PROCESSING',
    customerPaymentDetails: {
      paymentToken: paymentDetails.token,
      customerInfo
    },
    vendors: [],
    rollbackRequired: false,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
  
  // Store in DynamoDB
  await dynamodb.put({
    TableName: PAYMENT_TRANSACTIONS_TABLE,
    Item: transaction
  }).promise();
  
  return transaction;
}

/**
 * Perform health checks on all vendors
 */
async function performHealthChecks(vendorGroups) {
  const healthCheckPromises = vendorGroups.map(async (vendorGroup) => {
    try {
      const vendorConfig = await getVendorConfiguration(vendorGroup.vendorId);
      
      if (!vendorConfig) {
        return {
          vendorId: vendorGroup.vendorId,
          healthy: false,
          error: 'Vendor configuration not found'
        };
      }
      
      // Check circuit breaker status
      const circuitBreakerStatus = await getCircuitBreakerStatus(vendorGroup.vendorId);
      
      if (circuitBreakerStatus === 'OPEN') {
        return {
          vendorId: vendorGroup.vendorId,
          healthy: false,
          error: 'Circuit breaker is open'
        };
      }
      
      // Perform actual health check by calling vendor's health endpoint
      const healthCheckResult = await performVendorHealthCheck(vendorConfig);
      
      return {
        vendorId: vendorGroup.vendorId,
        healthy: healthCheckResult.healthy,
        error: healthCheckResult.error,
        responseTime: healthCheckResult.responseTime
      };
      
    } catch (error) {
      return {
        vendorId: vendorGroup.vendorId,
        healthy: false,
        error: error.message
      };
    }
  });
  
  return await Promise.all(healthCheckPromises);
}

/**
 * Get vendor configuration from DynamoDB
 */
async function getVendorConfiguration(vendorId) {
  try {
    const result = await dynamodb.get({
      TableName: VENDOR_CONFIGURATIONS_TABLE,
      Key: { vendorId }
    }).promise();
    
    return result.Item;
  } catch (error) {
    console.error('Error getting vendor configuration:', error);
    return null;
  }
}

/**
 * Get circuit breaker status
 */
async function getCircuitBreakerStatus(vendorId) {
  try {
    const result = await dynamodb.get({
      TableName: CIRCUIT_BREAKER_TABLE,
      Key: { vendorId }
    }).promise();
    
    if (!result.Item) {
      return 'CLOSED'; // Default to closed if no record exists
    }
    
    const { state, lastFailureTime, failureCount } = result.Item;
    
    // Check if circuit should be half-open
    if (state === 'OPEN' && Date.now() - lastFailureTime > CIRCUIT_BREAKER_CONFIG.recoveryTimeout) {
      return 'HALF_OPEN';
    }
    
    return state;
  } catch (error) {
    console.error('Error getting circuit breaker status:', error);
    return 'CLOSED'; // Default to closed on error
  }
}

/**
 * Perform vendor health check
 */
async function performVendorHealthCheck(vendorConfig) {
  const startTime = Date.now();
  
  try {
    // Call the vendor's health check Lambda function
    const healthCheckParams = {
      FunctionName: `${vendorConfig.posSystem}-health-check`,
      Payload: JSON.stringify({
        vendorId: vendorConfig.vendorId,
        locationId: vendorConfig.locationId,
        merchantId: vendorConfig.merchantId
      })
    };
    
    const result = await lambda.invoke(healthCheckParams).promise();
    const response = JSON.parse(result.Payload);
    
    const responseTime = Date.now() - startTime;
    
    return {
      healthy: response.success || false,
      error: response.error,
      responseTime
    };
    
  } catch (error) {
    return {
      healthy: false,
      error: error.message,
      responseTime: Date.now() - startTime
    };
  }
}

/**
 * Handle graceful degradation when vendors are unhealthy
 */
async function handleGracefulDegradation(vendorGroups, unhealthyVendors) {
  const unhealthyVendorIds = unhealthyVendors.map(v => v.vendorId);
  
  const available = vendorGroups.filter(vg => !unhealthyVendorIds.includes(vg.vendorId));
  const unavailable = vendorGroups.filter(vg => unhealthyVendorIds.includes(vg.vendorId));
  
  return {
    available,
    unavailable,
    message: `Removed ${unavailable.length} items from ${unavailable.length} unavailable vendors`
  };
}

/**
 * Update transaction with graceful degradation info
 */
async function updateTransactionWithGracefulDegradation(transactionId, gracefulDegradation) {
  await dynamodb.update({
    TableName: PAYMENT_TRANSACTIONS_TABLE,
    Key: { transactionId },
    UpdateExpression: 'SET metadata = :metadata, updatedAt = :updatedAt',
    ExpressionAttributeValues: {
      ':metadata': {
        gracefulDegradation,
        originalVendorCount: gracefulDegradation.available.length + gracefulDegradation.unavailable.length,
        availableVendorCount: gracefulDegradation.available.length
      },
      ':updatedAt': new Date().toISOString()
    }
  }).promise();
}

/**
 * Create vendor payment records
 */
async function createVendorPaymentRecords(transactionId, vendorGroups) {
  const vendorPayments = [];
  
  for (const vendorGroup of vendorGroups) {
    const vendorConfig = await getVendorConfiguration(vendorGroup.vendorId);
    
    const vendorPayment = {
      transactionId,
      vendorId: vendorGroup.vendorId,
      posSystem: vendorConfig.posSystem,
      amount: vendorGroup.totalAmount,
      items: vendorGroup.items,
      lambdaFunction: `${vendorConfig.posSystem}-payment-processor`,
      status: 'PENDING',
      createdAt: new Date().toISOString()
    };
    
    vendorPayments.push(vendorPayment);
    
    // Store in DynamoDB
    await dynamodb.put({
      TableName: PAYMENT_TRANSACTIONS_TABLE,
      Item: {
        ...vendorPayment,
        pk: transactionId,
        sk: `vendor#${vendorGroup.vendorId}`
      }
    }).promise();
  }
  
  return vendorPayments;
}

/**
 * Process vendor payments in parallel
 */
async function processVendorPayments(vendorPayments, paymentDetails) {
  const paymentPromises = vendorPayments.map(async (vendorPayment) => {
    try {
      console.log(`Processing payment for vendor: ${vendorPayment.vendorId}`);
      
      const paymentParams = {
        FunctionName: vendorPayment.lambdaFunction,
        Payload: JSON.stringify({
          vendorId: vendorPayment.vendorId,
          amount: vendorPayment.amount,
          items: vendorPayment.items,
          paymentToken: paymentDetails.token,
          transactionId: vendorPayment.transactionId
        })
      };
      
      const result = await lambda.invoke(paymentParams).promise();
      const response = JSON.parse(result.Payload);
      
      // Update vendor payment status
      await updateVendorPaymentStatus(vendorPayment.transactionId, vendorPayment.vendorId, {
        status: response.success ? 'SUCCESS' : 'FAILED',
        posTransactionId: response.transactionId,
        errorMessage: response.error,
        processedAt: new Date().toISOString()
      });
      
      // Update circuit breaker
      await updateCircuitBreaker(vendorPayment.vendorId, response.success);
      
      return {
        vendorId: vendorPayment.vendorId,
        success: response.success,
        transactionId: response.transactionId,
        error: response.error,
        amount: vendorPayment.amount
      };
      
    } catch (error) {
      console.error(`Error processing payment for vendor ${vendorPayment.vendorId}:`, error);
      
      // Update vendor payment status to failed
      await updateVendorPaymentStatus(vendorPayment.transactionId, vendorPayment.vendorId, {
        status: 'FAILED',
        errorMessage: error.message,
        processedAt: new Date().toISOString()
      });
      
      // Update circuit breaker
      await updateCircuitBreaker(vendorPayment.vendorId, false);
      
      return {
        vendorId: vendorPayment.vendorId,
        success: false,
        error: error.message,
        amount: vendorPayment.amount
      };
    }
  });
  
  return await Promise.all(paymentPromises);
}

/**
 * Update vendor payment status
 */
async function updateVendorPaymentStatus(transactionId, vendorId, updates) {
  await dynamodb.update({
    TableName: PAYMENT_TRANSACTIONS_TABLE,
    Key: {
      pk: transactionId,
      sk: `vendor#${vendorId}`
    },
    UpdateExpression: 'SET #status = :status, posTransactionId = :posTransactionId, errorMessage = :errorMessage, processedAt = :processedAt, updatedAt = :updatedAt',
    ExpressionAttributeNames: {
      '#status': 'status'
    },
    ExpressionAttributeValues: {
      ':status': updates.status,
      ':posTransactionId': updates.posTransactionId || null,
      ':errorMessage': updates.errorMessage || null,
      ':processedAt': updates.processedAt,
      ':updatedAt': new Date().toISOString()
    }
  }).promise();
}

/**
 * Update circuit breaker status
 */
async function updateCircuitBreaker(vendorId, success) {
  try {
    const result = await dynamodb.get({
      TableName: CIRCUIT_BREAKER_TABLE,
      Key: { vendorId }
    }).promise();
    
    const currentState = result.Item || {
      vendorId,
      state: 'CLOSED',
      failureCount: 0,
      lastFailureTime: null,
      lastSuccessTime: null
    };
    
    let newState = currentState.state;
    let failureCount = currentState.failureCount;
    
    if (success) {
      failureCount = 0;
      newState = 'CLOSED';
      currentState.lastSuccessTime = Date.now();
    } else {
      failureCount++;
      currentState.lastFailureTime = Date.now();
      
      if (failureCount >= CIRCUIT_BREAKER_CONFIG.failureThreshold) {
        newState = 'OPEN';
      }
    }
    
    await dynamodb.put({
      TableName: CIRCUIT_BREAKER_TABLE,
      Item: {
        ...currentState,
        state: newState,
        failureCount,
        updatedAt: new Date().toISOString()
      }
    }).promise();
    
  } catch (error) {
    console.error('Error updating circuit breaker:', error);
  }
}

/**
 * Analyze payment results
 */
function analyzePaymentResults(paymentResults) {
  const successfulPayments = paymentResults.filter(result => result.success);
  const failedPayments = paymentResults.filter(result => !result.success);
  
  const totalAmount = paymentResults.reduce((sum, result) => sum + result.amount, 0);
  const successfulAmount = successfulPayments.reduce((sum, result) => sum + result.amount, 0);
  
  let finalStatus = 'COMPLETED';
  let rollbackRequired = false;
  
  if (failedPayments.length === paymentResults.length) {
    // All payments failed
    finalStatus = 'FAILED';
    rollbackRequired = false; // No successful payments to rollback
  } else if (failedPayments.length > 0) {
    // Partial failure
    finalStatus = 'PARTIAL_SUCCESS';
    rollbackRequired = true; // Rollback successful payments
  }
  
  return {
    successfulPayments,
    failedPayments,
    totalAmount,
    successfulAmount,
    finalStatus,
    rollbackRequired
  };
}

/**
 * Update transaction status
 */
async function updateTransactionStatus(transactionId, analysis) {
  await dynamodb.update({
    TableName: PAYMENT_TRANSACTIONS_TABLE,
    Key: { transactionId },
    UpdateExpression: 'SET #status = :status, rollbackRequired = :rollbackRequired, updatedAt = :updatedAt',
    ExpressionAttributeNames: {
      '#status': 'status'
    },
    ExpressionAttributeValues: {
      ':status': analysis.finalStatus,
      ':rollbackRequired': analysis.rollbackRequired,
      ':updatedAt': new Date().toISOString()
    }
  }).promise();
}

/**
 * Trigger compensation Lambda
 */
async function triggerCompensationLambda(transactionId, successfulPayments) {
  try {
    const compensationParams = {
      FunctionName: 'payment-compensator',
      Payload: JSON.stringify({
        transactionId,
        successfulPayments
      })
    };
    
    // Invoke asynchronously
    await lambda.invokeAsync(compensationParams).promise();
    
  } catch (error) {
    console.error('Error triggering compensation Lambda:', error);
  }
}

/**
 * Create HTTP response
 */
function createResponse(statusCode, body) {
  return {
    statusCode,
    headers: {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization'
    },
    body: JSON.stringify(body)
  };
}
