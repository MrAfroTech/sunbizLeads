const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, PutCommand, ScanCommand } = require('@aws-sdk/lib-dynamodb');

// Initialize AWS SDK v3
const client = new DynamoDBClient({ region: 'us-east-1' });
const dynamodb = DynamoDBDocumentClient.from(client);

// DynamoDB table name for storing vendor updates
const VENDOR_UPDATES_TABLE = process.env.VENDOR_UPDATES_TABLE || 'vendor-updates-table';

/**
 * Main Lambda handler for customer bridge API
 */
exports.handler = async (event, context) => {
  console.log('=== CUSTOMER BRIDGE LAMBDA START ===');
  console.log('🔍 INCOMING EVENT ANALYSIS:');
  console.log('   - Event type:', typeof event);
  console.log('   - Event is null/undefined:', !event);
  console.log('   - Event keys:', event ? Object.keys(event) : 'N/A');
  console.log('   - Full event:', JSON.stringify(event, null, 2));
  
  try {
    let result;
    
    // Check if this is an EventBridge event (has source OR detail-type fields)
    if (event && (event.source || event['detail-type'])) {
      console.log('🔍 MAIN HANDLER: Routing to EventBridge handler');
      console.log('   - Event has source:', event.source);
      console.log('   - Event has detail-type:', event['detail-type']);
      console.log('   - Event has detail:', !!event.detail);
      result = await handleEventBridgeVendorEvent(event);
    }
    // Check if this is an HTTP API Gateway event OR Function URL event
    else if (event && (event.requestContext && event.requestContext.http || event.httpMethod)) {
      console.log('🔍 MAIN HANDLER: Routing to HTTP handler');
      console.log(`   - HTTP Method: ${event.httpMethod || (event.requestContext && event.requestContext.http && event.requestContext.http.method) || 'N/A'}`);
      console.log(`   - Path: ${event.path || event.rawPath || 'N/A'}`);
      result = await handleHttpRequest(event);
    }
    // Check if this is a null/undefined event
    else if (!event) {
      console.log('🔍 MAIN HANDLER: Null/undefined event detected');
      console.log('   - Event value:', event);
      console.log('   - Event type:', typeof event);
      result = {
        statusCode: 400,
        body: JSON.stringify({ 
          error: 'Invalid EventBridge event structure',
          received: event,
          expected: 'EventBridge event object with source, detail-type, and detail fields'
        })
      };
    }
    // Unknown event type
    else {
      console.log('🔍 MAIN HANDLER: Unknown event type detected');
      console.log('   - Event structure analysis:');
      console.log('     * Has source:', !!event?.source);
      console.log('     * Has detail-type:', !!event?.['detail-type']);
      console.log('     * Has detail:', !!event?.detail);
      console.log('     * Has httpMethod:', !!event?.httpMethod);
      console.log('     * Has path:', !!event?.path);
      console.log('   - Event keys:', event ? Object.keys(event) : 'N/A');
      console.log('   - Event type:', typeof event);
      console.log('   - Event value:', JSON.stringify(event, null, 2));
      
      result = {
        statusCode: 400,
        body: JSON.stringify({ 
          error: 'Unknown event type',
          received: { 
            source: event?.source, 
            detailType: event?.['detail-type'],
            httpMethod: event?.httpMethod, 
            path: event?.path 
          }
        })
      };
    }
    
    console.log('Handler result:', JSON.stringify(result, null, 2));
    console.log('=== CUSTOMER BRIDGE LAMBDA SUCCESS ===');
    
    return result;
    
  } catch (error) {
    console.error('=== CUSTOMER BRIDGE LAMBDA ERROR ===');
    console.error('Error in main handler:', error);
    console.error('Error stack:', error.stack);
    console.error('=== CUSTOMER BRIDGE LAMBDA ERROR END ===');
    
    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
        'Access-Control-Allow-Methods': 'GET,POST,OPTIONS'
      },
      body: JSON.stringify({
        error: 'Internal server error',
        message: error.message
      })
    };
  }
};

/**
 * Handle HTTP API Gateway requests
 */
async function handleHttpRequest(event) {
  // Handle both API Gateway and Function URL events
  const httpMethod = event.httpMethod || (event.requestContext && event.requestContext.http && event.requestContext.http.method);
  const path = event.path || event.rawPath;
  
  console.log('HTTP Request Details:');
  console.log('  - Method:', httpMethod);
  console.log('  - Path:', path);
  console.log('  - Event type:', event.requestContext ? 'Function URL' : 'API Gateway');
  console.log('  - Full event structure:', JSON.stringify(event, null, 2));
  
  switch (httpMethod) {
    case 'OPTIONS':
      return await handleOptions(event);
      
    case 'POST':
      if (path === '/vendor-update') {
        return await handleVendorUpdate(event);
      } else {
        return {
          statusCode: 404,
          headers: {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
            'Access-Control-Allow-Methods': 'GET,POST,OPTIONS'
          },
          body: JSON.stringify({ error: 'Route not found' })
        };
      }
      
    case 'GET':
      if (path === '/vendor-info') {
        return await handleGetVendorInfo(event);
      } else {
        return {
          statusCode: 404,
          headers: {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
            'Access-Control-Allow-Methods': 'GET,POST,OPTIONS'
        },
          body: JSON.stringify({ error: 'Route not found' })
        };
      }
      
    default:
      return {
        statusCode: 405,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
          'Access-Control-Allow-Methods': 'GET,POST,OPTIONS'
        },
        body: JSON.stringify({ error: 'Method not allowed' })
      };
  }
}

/**
 * Handle EventBridge vendor onboarding events
 */
async function handleEventBridgeVendorEvent(event) {
  try {
    console.log('=== EVENTBRIDGE EVENT PROCESSING START ===');
    console.log('Raw EventBridge event received:', JSON.stringify(event, null, 2));
    
    // Step 1: Validate EventBridge event structure
    console.log('Validating EventBridge event structure...');
    
    // Check if this is a valid EventBridge event
    if (!event || typeof event !== 'object') {
      console.error('❌ Invalid EventBridge event: event is not an object');
      return {
        statusCode: 400,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
          'Access-Control-Allow-Methods': 'GET,POST,OPTIONS'
        },
        body: JSON.stringify({ 
          error: 'Invalid EventBridge event structure',
          received: event,
          expected: 'EventBridge event object with source, detail-type, and detail fields'
        })
      };
    }
    
    // Log expected vs actual event structure
    console.log('Expected EventBridge event structure:');
    console.log('  - source: "seamless.vendor.onboarding"');
    console.log('  - detail-type: "VendorOnboarded"');
    console.log('  - detail: { vendorId, vendorName, vendorType, ... }');
    console.log('  - time: ISO timestamp');
    console.log('  - id: unique event identifier');
    
    console.log('Actual EventBridge event structure:');
    console.log('  - source:', event.source);
    console.log('  - detail-type:', event['detail-type']);
    console.log('  - detail keys:', event.detail ? Object.keys(event.detail) : 'undefined');
    console.log('  - time:', event.time);
    console.log('  - id:', event.id);
    
    // Validate required EventBridge fields
    if (!event.source || event.source !== 'seamless.vendor.onboarding') {
      console.error('❌ Invalid EventBridge event source:', event.source);
      return {
        statusCode: 400,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
          'Access-Control-Allow-Methods': 'GET,POST,OPTIONS'
        },
        body: JSON.stringify({ 
          error: 'Invalid EventBridge event source',
          received: { source: event.source },
          expected: { source: 'seamless.vendor.onboarding' }
        })
      };
    }
    
    if (!event['detail-type'] || event['detail-type'] !== 'VendorOnboarded') {
      console.error('❌ Invalid EventBridge event detail-type:', event['detail-type']);
      return {
        statusCode: 400,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
          'Access-Control-Allow-Methods': 'GET,POST,OPTIONS'
        },
        body: JSON.stringify({ 
          error: 'Invalid EventBridge event detail-type',
          received: { 'detail-type': event['detail-type'] },
          expected: { 'detail-type': 'VendorOnboarded' }
        })
      };
    }
    
    if (!event.detail || typeof event.detail !== 'object') {
      console.error('❌ Invalid EventBridge event detail:', event.detail);
      return {
        statusCode: 400,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
          'Access-Control-Allow-Methods': 'GET,POST,OPTIONS'
        },
        body: JSON.stringify({ 
          error: 'Invalid EventBridge event detail',
          received: { detail: event.detail },
          expected: 'detail should be an object containing vendor information'
        })
      };
    }
    
    // Step 2: Extract and validate vendor data from detail
    console.log('Extracting vendor data from event.detail...');
    const vendorData = event.detail;
    
    // Log expected vs actual vendor data structure
    console.log('Expected vendor data structure:');
    console.log('  - vendorId: string (required)');
    console.log('  - vendorName: string (recommended)');
    console.log('  - vendorType: string (recommended)');
    console.log('  - location: string (optional)');
    console.log('  - contactInfo: object (optional)');
    console.log('  - menu: object (optional)');
    
    console.log('Actual vendor data received:');
    console.log('  - vendorId:', vendorData.vendorId);
    console.log('  - vendorName:', vendorData.vendorName);
    console.log('  - vendorType:', vendorData.vendorType);
    console.log('  - location:', vendorData.location);
    console.log('  - contactInfo:', vendorData.contactInfo);
    console.log('  - menu:', vendorData.menu);
    console.log('  - All vendor data keys:', Object.keys(vendorData));
    
    // Validate required vendor fields
    if (!vendorData.vendorId || typeof vendorData.vendorId !== 'string') {
      console.error('❌ Invalid vendorId:', vendorData.vendorId);
      return {
        statusCode: 400,
        body: JSON.stringify({ 
          error: 'Invalid or missing vendorId',
          received: { vendorId: vendorData.vendorId },
          expected: 'vendorId should be a non-empty string'
        })
      };
    }
    
    if (vendorData.vendorId.trim() === '') {
      console.error('❌ Empty vendorId received');
      return {
        statusCode: 400,
        body: JSON.stringify({ 
          error: 'vendorId cannot be empty',
          received: { vendorId: vendorData.vendorId }
        })
      };
    }
    
    // Validate optional fields if they exist
    if (vendorData.vendorName && typeof vendorData.vendorName !== 'string') {
      console.warn('⚠️  vendorName is not a string:', vendorData.vendorName);
    }
    
    if (vendorData.vendorType && typeof vendorData.vendorType !== 'string') {
      console.warn('⚠️  vendorType is not a string:', vendorData.vendorType);
    }
    
    if (vendorData.location && typeof vendorData.location !== 'string') {
      console.warn('⚠️  location is not a string:', vendorData.location);
    }
    
    // Step 3: Create update record with enhanced validation
    console.log('Creating vendor update record...');
    
    const updateRecord = {
      id: `${vendorData.vendorId}-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      vendorId: vendorData.vendorId.trim(),
      updateType: 'vendor_onboarded',
      timestamp: new Date().toISOString(),
      data: {
        ...vendorData,
        // Ensure vendorId is clean
        vendorId: vendorData.vendorId.trim()
      },
      status: 'received',
      source: 'eventbridge',
      eventId: event.id || 'unknown',
      eventTime: event.time || new Date().toISOString(),
      processingTime: new Date().toISOString()
    };
    
    console.log('Vendor update record created:', JSON.stringify(updateRecord, null, 2));
    
    // Step 4: Save to DynamoDB with error handling
    console.log('Saving EventBridge vendor update to DynamoDB...');
    
    try {
      await dynamodb.put({
        TableName: VENDOR_UPDATES_TABLE,
        Item: updateRecord
      }).promise();
      
      console.log('✅ EventBridge vendor update saved successfully to DynamoDB');
      console.log('   - Table:', VENDOR_UPDATES_TABLE);
      console.log('   - Record ID:', updateRecord.id);
      console.log('   - Vendor ID:', updateRecord.vendorId);
      
    } catch (dbError) {
      console.error('❌ Failed to save to DynamoDB:', dbError);
      console.error('   - Error code:', dbError.code);
      console.error('   - Error message:', dbError.message);
      console.error('   - Table name:', VENDOR_UPDATES_TABLE);
      
      return {
        statusCode: 500,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
          'Access-Control-Allow-Methods': 'GET,POST,OPTIONS'
        },
        body: JSON.stringify({
          error: 'Failed to save vendor update to database',
          message: dbError.message,
          code: dbError.code,
          vendorId: vendorData.vendorId
        })
      };
    }
    
    // Step 5: Return success response
    console.log('=== EVENTBRIDGE EVENT PROCESSING SUCCESS ===');
    
    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
        'Access-Control-Allow-Methods': 'GET,POST,OPTIONS'
      },
      body: JSON.stringify({
        message: 'EventBridge vendor event processed successfully',
        updateId: updateRecord.id,
        timestamp: updateRecord.timestamp,
        vendorId: updateRecord.vendorId,
        eventId: updateRecord.eventId,
        processingTime: updateRecord.processingTime
      })
    };
    
  } catch (error) {
    console.error('=== EVENTBRIDGE EVENT PROCESSING ERROR ===');
    console.error('Unexpected error processing EventBridge vendor event:', error);
    console.error('Error stack:', error.stack);
    console.error('Event that caused error:', JSON.stringify(event, null, 2));
    
    return {
      statusCode: 500,
      body: JSON.stringify({
        error: 'Failed to process EventBridge vendor event',
        message: error.message,
        errorType: error.constructor.name,
        vendorId: event?.detail?.vendorId || 'unknown'
      })
    };
  }
}

/**
 * Handle POST /vendor-update - Receives vendor updates from Point A
 */
async function handleVendorUpdate(event) {
  try {
    console.log('=== VENDOR UPDATE HANDLER START ===');
    console.log('🔍 Raw event received:', JSON.stringify(event, null, 2));
    console.log('🔍 Event body type:', typeof event.body);
    console.log('🔍 Event body length:', event.body ? event.body.length : 'undefined');
    
    // Parse the request body
    let vendorData;
    try {
      vendorData = JSON.parse(event.body);
      console.log('✅ Successfully parsed vendor data:', JSON.stringify(vendorData, null, 2));
      console.log('🔍 Vendor data keys:', Object.keys(vendorData));
      console.log('🔍 Vendor ID:', vendorData.vendorId);
      console.log('🔍 Update type:', vendorData.updateType);
      console.log('🔍 Additional data:', vendorData.data);
    } catch (parseError) {
      console.error('❌ Failed to parse request body:', parseError);
      console.error('❌ Raw body content:', event.body);
      return {
        statusCode: 400,
        body: JSON.stringify({ error: 'Invalid JSON in request body' })
      };
    }
    
    // Validate required fields
    console.log('🔍 Validating required fields...');
    if (!vendorData.vendorId || !vendorData.updateType) {
      console.error('❌ Missing required fields:');
      console.error('   - vendorId:', vendorData.vendorId);
      console.error('   - updateType:', vendorData.updateType);
      return {
        statusCode: 400,
        body: JSON.stringify({ 
          error: 'Missing required fields: vendorId and updateType are required' 
        })
      };
    }
    console.log('✅ Required fields validation passed');
    
    // Add timestamp and unique ID
    const updateRecord = {
      id: `${vendorData.vendorId}-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      vendorId: vendorData.vendorId,
      updateType: vendorData.updateType,
      timestamp: new Date().toISOString(),
      data: vendorData.data || {},
      status: 'received'
    };
    
    console.log('🔍 Prepared update record:', JSON.stringify(updateRecord, null, 2));
    console.log('🔍 DynamoDB table name:', VENDOR_UPDATES_TABLE);
    
    // Save to DynamoDB
    console.log('💾 Saving to DynamoDB...');
    const dynamoParams = {
      TableName: VENDOR_UPDATES_TABLE,
      Item: updateRecord
    };
    console.log('🔍 DynamoDB params:', JSON.stringify(dynamoParams, null, 2));
    
    await dynamodb.send(new PutCommand(dynamoParams));
    
    console.log('✅ Vendor update saved successfully to DynamoDB');
    console.log('🔍 Saved record ID:', updateRecord.id);
    console.log('🔍 Saved timestamp:', updateRecord.timestamp);
    
    // Return success response
    const response = {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
        'Access-Control-Allow-Methods': 'GET,POST,OPTIONS'
      },
      body: JSON.stringify({
        message: 'Got it, thanks!',
        updateId: updateRecord.id,
        timestamp: updateRecord.timestamp
      })
    };
    
    console.log('🔍 Returning response:', JSON.stringify(response, null, 2));
    console.log('=== VENDOR UPDATE HANDLER SUCCESS ===');
    
    return response;
    
  } catch (error) {
    console.error('=== VENDOR UPDATE HANDLER ERROR ===');
    console.error('❌ Error handling vendor update:', error);
    console.error('❌ Error stack:', error.stack);
    console.error('❌ Error message:', error.message);
    console.error('❌ Error name:', error.name);
    console.error('=== VENDOR UPDATE HANDLER ERROR END ===');
    
    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
        'Access-Control-Allow-Methods': 'GET,POST,OPTIONS'
      },
      body: JSON.stringify({
        error: 'Failed to process vendor update',
        message: error.message
      })
    };
  }
}

/**
 * Handle GET /vendor-info - Provides latest vendor info to Customer UI
 */
async function handleGetVendorInfo(event) {
  try {
    console.log('Handling get vendor info request');
    
    // Parse query parameters
    const queryParams = event.queryStringParameters || {};
    const vendorId = queryParams.vendorId;
    const limit = parseInt(queryParams.limit) || 10;
    
    console.log('Query parameters:', { vendorId, limit });
    
    let scanParams = {
      TableName: VENDOR_UPDATES_TABLE,
      Limit: Math.min(limit, 100), // Cap at 100 items
      ScanIndexForward: false // Get newest first
    };
    
    // If vendorId is specified, filter by it
    if (vendorId) {
      scanParams.FilterExpression = 'vendorId = :vendorId';
      scanParams.ExpressionAttributeValues = {
        ':vendorId': vendorId
      };
    }
    
    console.log('Scanning DynamoDB with params:', scanParams);
    
    // Query DynamoDB
    const result = await dynamodb.send(new ScanCommand(scanParams));
    
    console.log(`Found ${result.Items.length} vendor updates`);
    
    // Sort by timestamp (newest first) and limit results
    const sortedItems = result.Items
      .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp))
      .slice(0, limit);
    
    // Return vendor info
    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
        'Access-Control-Allow-Methods': 'GET,POST,OPTIONS'
      },
      body: JSON.stringify({
        message: 'Here is the latest vendor info!',
        totalUpdates: result.Items.length,
        returnedUpdates: sortedItems.length,
        updates: sortedItems
      })
    };
    
  } catch (error) {
    console.error('Error handling get vendor info:', error);
    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
        'Access-Control-Allow-Methods': 'GET,POST,OPTIONS'
      },
      body: JSON.stringify({
        error: 'Failed to retrieve vendor info',
        message: error.message
      })
    };
  }
}

/**
 * Handle OPTIONS requests for CORS preflight
 */
async function handleOptions(event) {
  return {
    statusCode: 200,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
      'Access-Control-Allow-Methods': 'GET,POST,OPTIONS'
    },
    body: ''
  };
}
