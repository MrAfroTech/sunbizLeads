const AWS = require('aws-sdk');

// Initialize AWS SDK
const dynamodb = new AWS.DynamoDB.DocumentClient();

// DynamoDB table name for storing vendor updates
const VENDOR_UPDATES_TABLE = process.env.VENDOR_UPDATES_TABLE || 'vendor-updates-table';

/**
 * Main Lambda handler for customer bridge API
 */
exports.handler = async (event, context) => {
  console.log('=== CUSTOMER BRIDGE LAMBDA START ===');
  console.log('Event received:', JSON.stringify(event, null, 2));
  
  try {
    const { httpMethod, path } = event;
    console.log(`Processing ${httpMethod || 'undefined'} request to ${path || 'undefined'}`);
    
    let result;
    
    // Handle case where httpMethod or path might be undefined
    if (!httpMethod || !path) {
      result = {
        statusCode: 400,
        body: JSON.stringify({ 
          error: 'Missing required fields: httpMethod and path are required',
          received: { httpMethod, path }
        })
      };
    } else {
      switch (httpMethod) {
        case 'POST':
          if (path === '/vendor-update') {
            result = await handleVendorUpdate(event);
          } else {
            result = {
              statusCode: 404,
              body: JSON.stringify({ error: 'Route not found' })
            };
          }
          break;
          
        case 'GET':
          if (path === '/vendor-info') {
            result = await handleGetVendorInfo(event);
          } else {
            result = {
              statusCode: 404,
              body: JSON.stringify({ error: 'Route not found' })
            };
          }
          break;
          
        default:
          result = {
            statusCode: 405,
            body: JSON.stringify({ error: 'Method not allowed' })
          };
          break;
      }
    }
    
    console.log('Handler result:', JSON.stringify(result, null, 2));
    console.log('=== CUSTOMER BRIDGE LAMBDA SUCCESS ===');
    
    return result;
    
  } catch (error) {
    console.error('=== CUSTOMER BRIDGE LAMBDA ERROR ===');
    console.error('Error in main handler:', error);
    console.error('Error stack:', error.stack);
    console.error('=== CUSTOMER BRIDGE LAMBDA ERROR END ===');
    
    return {
      statusCode: 500,
      body: JSON.stringify({
        error: 'Internal server error',
        message: error.message
      })
    };
  }
};

/**
 * Handle POST /vendor-update - Receives vendor updates from Point A
 */
async function handleVendorUpdate(event) {
  try {
    console.log('Handling vendor update request');
    
    // Parse the request body
    let vendorData;
    try {
      vendorData = JSON.parse(event.body);
    } catch (parseError) {
      console.error('Failed to parse request body:', parseError);
      return {
        statusCode: 400,
        body: JSON.stringify({ error: 'Invalid JSON in request body' })
      };
    }
    
    // Validate required fields
    if (!vendorData.vendorId || !vendorData.updateType) {
      return {
        statusCode: 400,
        body: JSON.stringify({ 
          error: 'Missing required fields: vendorId and updateType are required' 
        })
      };
    }
    
    // Add timestamp and unique ID
    const updateRecord = {
      id: `${vendorData.vendorId}-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      vendorId: vendorData.vendorId,
      updateType: vendorData.updateType,
      timestamp: new Date().toISOString(),
      data: vendorData.data || {},
      status: 'received'
    };
    
    console.log('Saving vendor update:', updateRecord);
    
    // Save to DynamoDB
    await dynamodb.put({
      TableName: VENDOR_UPDATES_TABLE,
      Item: updateRecord
    }).promise();
    
    console.log('Vendor update saved successfully');
    
    // Return success response
    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type',
        'Access-Control-Allow-Methods': 'POST, OPTIONS'
      },
      body: JSON.stringify({
        message: 'Got it, thanks!',
        updateId: updateRecord.id,
        timestamp: updateRecord.timestamp
      })
    };
    
  } catch (error) {
    console.error('Error handling vendor update:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({
        error: 'Failed to process vendor update',
        message: error.message
      })
    };
  }
}

/**
 * Handle GET /vendor-info - Provides latest vendor info to Customer UI
 */
async function handleGetVendorInfo(event) {
  try {
    console.log('Handling get vendor info request');
    
    // Parse query parameters
    const queryParams = event.queryStringParameters || {};
    const vendorId = queryParams.vendorId;
    const limit = parseInt(queryParams.limit) || 10;
    
    console.log('Query parameters:', { vendorId, limit });
    
    let scanParams = {
      TableName: VENDOR_UPDATES_TABLE,
      Limit: Math.min(limit, 100), // Cap at 100 items
      ScanIndexForward: false // Get newest first
    };
    
    // If vendorId is specified, filter by it
    if (vendorId) {
      scanParams.FilterExpression = 'vendorId = :vendorId';
      scanParams.ExpressionAttributeValues = {
        ':vendorId': vendorId
      };
    }
    
    console.log('Scanning DynamoDB with params:', scanParams);
    
    // Query DynamoDB
    const result = await dynamodb.scan(scanParams).promise();
    
    console.log(`Found ${result.Items.length} vendor updates`);
    
    // Sort by timestamp (newest first) and limit results
    const sortedItems = result.Items
      .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp))
      .slice(0, limit);
    
    // Return vendor info
    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type',
        'Access-Control-Allow-Methods': 'GET, OPTIONS'
      },
      body: JSON.stringify({
        message: 'Here is the latest vendor info!',
        totalUpdates: result.Items.length,
        returnedUpdates: sortedItems.length,
        updates: sortedItems
      })
    };
    
  } catch (error) {
    console.error('Error handling get vendor info:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({
        error: 'Failed to retrieve vendor info',
        message: error.message
      })
    };
  }
}

/**
 * Handle OPTIONS requests for CORS preflight
 */
async function handleOptions(event) {
  return {
    statusCode: 200,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
      'Access-Control-Allow-Methods': 'GET,POST,OPTIONS'
    },
    body: ''
  };
}
