const AWS = require('aws-sdk');
const crypto = require('crypto');

// Initialize AWS SDK
const dynamodb = new AWS.DynamoDB.DocumentClient();
const cognito = new AWS.CognitoIdentityServiceProvider();

// Table names
const CONNECTIONS_TABLE = process.env.CONNECTIONS_TABLE || 'vendor-websocket-connections';
const SESSIONS_TABLE = process.env.SESSIONS_TABLE || 'vendor-websocket-sessions';
const USERS_TABLE = process.env.USERS_TABLE || 'vendor-users';

// Session configuration
const SESSION_CONFIG = {
  maxConnectionsPerUser: 3,
  sessionTimeout: 24 * 60 * 60 * 1000, // 24 hours in milliseconds
  tokenExpiry: 60 * 60 * 1000, // 1 hour in milliseconds
  maxReconnectAttempts: 5
};

/**
 * Connection Manager Class
 */
class ConnectionManager {
  constructor() {
    this.activeConnections = new Map();
    this.userConnections = new Map();
    this.vendorConnections = new Map();
  }

  /**
   * Authenticate connection and create session
   */
  async authenticateConnection(connectionId, authToken, connectionType, metadata = {}) {
    try {
      let user = null;
      let session = null;

      // Validate authentication token
      if (authToken) {
        user = await this.validateAuthToken(authToken);
        if (!user) {
          throw new Error('Invalid authentication token');
        }
      }

      // Create or retrieve session
      session = await this.createSession(connectionId, user, connectionType, metadata);

      // Store connection information
      const connectionData = {
        connectionId,
        userId: user?.id || null,
        vendorId: metadata.vendorId || user?.vendorId || null,
        connectionType,
        sessionId: session.sessionId,
        metadata,
        timestamp: new Date().toISOString(),
        isActive: true,
        lastActivity: new Date().toISOString()
      };

      // Store in DynamoDB
      await dynamodb.put({
        TableName: CONNECTIONS_TABLE,
        Item: connectionData
      }).promise();

      // Update in-memory maps
      this.activeConnections.set(connectionId, connectionData);
      
      if (user?.id) {
        if (!this.userConnections.has(user.id)) {
          this.userConnections.set(user.id, new Set());
        }
        this.userConnections.get(user.id).add(connectionId);
      }

      if (connectionData.vendorId) {
        if (!this.vendorConnections.has(connectionData.vendorId)) {
          this.vendorConnections.set(connectionData.vendorId, new Set());
        }
        this.vendorConnections.get(connectionData.vendorId).add(connectionId);
      }

      console.log(`Connection authenticated: ${connectionId} for user: ${user?.id || 'anonymous'}`);
      
      return {
        success: true,
        user,
        session,
        connectionData
      };

    } catch (error) {
      console.error('Authentication error:', error);
      return {
        success: false,
        error: error.message
      };
    }
  }

  /**
   * Validate authentication token
   */
  async validateAuthToken(token) {
    try {
      // Try to decode JWT token (you might want to use a proper JWT library)
      const decoded = this.decodeJWT(token);
      
      if (!decoded) {
        return null;
      }

      // Check if token is expired
      if (decoded.exp && Date.now() >= decoded.exp * 1000) {
        return null;
      }

      // Get user from database
      const user = await this.getUserById(decoded.sub || decoded.userId);
      
      if (!user || !user.isActive) {
        return null;
      }

      return user;

    } catch (error) {
      console.error('Token validation error:', error);
      return null;
    }
  }

  /**
   * Create or retrieve session
   */
  async createSession(connectionId, user, connectionType, metadata) {
    try {
      const sessionId = `session_${Date.now()}_${crypto.randomBytes(8).toString('hex')}`;
      
      const sessionData = {
        sessionId,
        connectionId,
        userId: user?.id || null,
        vendorId: metadata.vendorId || user?.vendorId || null,
        connectionType,
        metadata,
        createdAt: new Date().toISOString(),
        expiresAt: new Date(Date.now() + SESSION_CONFIG.sessionTimeout).toISOString(),
        isActive: true
      };

      // Store session in DynamoDB
      await dynamodb.put({
        TableName: SESSIONS_TABLE,
        Item: sessionData
      }).promise();

      return sessionData;

    } catch (error) {
      console.error('Session creation error:', error);
      throw error;
    }
  }

  /**
   * Get user by ID
   */
  async getUserById(userId) {
    try {
      const result = await dynamodb.get({
        TableName: USERS_TABLE,
        Key: { id: userId }
      }).promise();

      return result.Item || null;

    } catch (error) {
      console.error('Error getting user:', error);
      return null;
    }
  }

  /**
   * Handle connection disconnection
   */
  async handleDisconnection(connectionId) {
    try {
      const connection = this.activeConnections.get(connectionId);
      
      if (!connection) {
        return;
      }

      // Mark connection as inactive in DynamoDB
      await dynamodb.update({
        TableName: CONNECTIONS_TABLE,
        Key: { connectionId },
        UpdateExpression: 'SET isActive = :isActive, disconnectedAt = :disconnectedAt',
        ExpressionAttributeValues: {
          ':isActive': false,
          ':disconnectedAt': new Date().toISOString()
        }
      }).promise();

      // Remove from in-memory maps
      this.activeConnections.delete(connectionId);
      
      if (connection.userId) {
        const userConnections = this.userConnections.get(connection.userId);
        if (userConnections) {
          userConnections.delete(connectionId);
          if (userConnections.size === 0) {
            this.userConnections.delete(connection.userId);
          }
        }
      }

      if (connection.vendorId) {
        const vendorConnections = this.vendorConnections.get(connection.vendorId);
        if (vendorConnections) {
          vendorConnections.delete(connectionId);
          if (vendorConnections.size === 0) {
            this.vendorConnections.delete(connection.vendorId);
          }
        }
      }

      // Mark session as inactive
      if (connection.sessionId) {
        await dynamodb.update({
          TableName: SESSIONS_TABLE,
          Key: { sessionId: connection.sessionId },
          UpdateExpression: 'SET isActive = :isActive, endedAt = :endedAt',
          ExpressionAttributeValues: {
            ':isActive': false,
            ':endedAt': new Date().toISOString()
          }
        }).promise();
      }

      console.log(`Connection removed: ${connectionId}`);

    } catch (error) {
      console.error('Error handling disconnection:', error);
    }
  }

  /**
   * Get active connections for a user
   */
  async getUserConnections(userId) {
    try {
      const result = await dynamodb.query({
        TableName: CONNECTIONS_TABLE,
        IndexName: 'UserIdIndex',
        KeyConditionExpression: 'userId = :userId',
        FilterExpression: 'isActive = :isActive',
        ExpressionAttributeValues: {
          ':userId': userId,
          ':isActive': true
        }
      }).promise();

      return result.Items || [];

    } catch (error) {
      console.error('Error getting user connections:', error);
      return [];
    }
  }

  /**
   * Get active connections for a vendor
   */
  async getVendorConnections(vendorId) {
    try {
      const result = await dynamodb.query({
        TableName: CONNECTIONS_TABLE,
        IndexName: 'VendorIdIndex',
        KeyConditionExpression: 'vendorId = :vendorId',
        FilterExpression: 'isActive = :isActive',
        ExpressionAttributeValues: {
          ':vendorId': vendorId,
          ':isActive': true
        }
      }).promise();

      return result.Items || [];

    } catch (error) {
      console.error('Error getting vendor connections:', error);
      return [];
    }
  }

  /**
   * Get all active connections
   */
  async getAllActiveConnections() {
    try {
      const result = await dynamodb.scan({
        TableName: CONNECTIONS_TABLE,
        FilterExpression: 'isActive = :isActive',
        ExpressionAttributeValues: {
          ':isActive': true
        }
      }).promise();

      return result.Items || [];

    } catch (error) {
      console.error('Error getting all connections:', error);
      return [];
    }
  }

  /**
   * Update connection activity
   */
  async updateConnectionActivity(connectionId) {
    try {
      await dynamodb.update({
        TableName: CONNECTIONS_TABLE,
        Key: { connectionId },
        UpdateExpression: 'SET lastActivity = :lastActivity',
        ExpressionAttributeValues: {
          ':lastActivity': new Date().toISOString()
        }
      }).promise();

      // Update in-memory connection
      const connection = this.activeConnections.get(connectionId);
      if (connection) {
        connection.lastActivity = new Date().toISOString();
      }

    } catch (error) {
      console.error('Error updating connection activity:', error);
    }
  }

  /**
   * Clean up expired sessions
   */
  async cleanupExpiredSessions() {
    try {
      const now = new Date().toISOString();
      
      const result = await dynamodb.scan({
        TableName: SESSIONS_TABLE,
        FilterExpression: 'expiresAt < :now AND isActive = :isActive',
        ExpressionAttributeValues: {
          ':now': now,
          ':isActive': true
        }
      }).promise();

      for (const session of result.Items || []) {
        await this.handleDisconnection(session.connectionId);
      }

      console.log(`Cleaned up ${result.Items?.length || 0} expired sessions`);

    } catch (error) {
      console.error('Error cleaning up expired sessions:', error);
    }
  }

  /**
   * Get connection statistics
   */
  async getConnectionStats() {
    try {
      const stats = {
        totalConnections: this.activeConnections.size,
        userConnections: this.userConnections.size,
        vendorConnections: this.vendorConnections.size,
        totalUsers: 0,
        totalVendors: 0
      };

      // Get counts from DynamoDB for accuracy
      const connectionsResult = await dynamodb.scan({
        TableName: CONNECTIONS_TABLE,
        FilterExpression: 'isActive = :isActive',
        ExpressionAttributeValues: { ':isActive': true }
      }).promise();

      const usersResult = await dynamodb.scan({
        TableName: USERS_TABLE,
        FilterExpression: 'isActive = :isActive',
        ExpressionAttributeValues: { ':isActive': true }
      }).promise();

      stats.totalConnections = connectionsResult.Items?.length || 0;
      stats.totalUsers = usersResult.Items?.length || 0;

      return stats;

    } catch (error) {
      console.error('Error getting connection stats:', error);
      return null;
    }
  }

  /**
   * Simple JWT decode (for basic validation)
   */
  decodeJWT(token) {
    try {
      const base64Url = token.split('.')[1];
      const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
      const jsonPayload = decodeURIComponent(atob(base64).split('').map(function(c) {
        return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
      }).join(''));

      return JSON.parse(jsonPayload);
    } catch (error) {
      return null;
    }
  }

  /**
   * Validate connection permissions
   */
  async validateConnectionPermissions(connectionId, action, targetId = null) {
    try {
      const connection = this.activeConnections.get(connectionId);
      
      if (!connection) {
        return { allowed: false, reason: 'Connection not found' };
      }

      // Check if connection is active
      if (!connection.isActive) {
        return { allowed: false, reason: 'Connection inactive' };
      }

      // Check user permissions based on action
      switch (action) {
        case 'sendMessage':
          return { allowed: true };
          
        case 'updateOrderStatus':
          // Only allow if user is vendor or admin
          if (connection.connectionType === 'vendor' || connection.connectionType === 'admin') {
            return { allowed: true };
          }
          return { allowed: false, reason: 'Insufficient permissions' };
          
        case 'updateVendorStatus':
          // Only allow if user is vendor or admin
          if (connection.connectionType === 'vendor' || connection.connectionType === 'admin') {
            return { allowed: true };
          }
          return { allowed: false, reason: 'Insufficient permissions' };
          
        case 'broadcast':
          // Only allow if user is admin
          if (connection.connectionType === 'admin') {
            return { allowed: true };
          }
          return { allowed: false, reason: 'Admin access required' };
          
        default:
          return { allowed: true };
      }

    } catch (error) {
      console.error('Permission validation error:', error);
      return { allowed: false, reason: 'Validation error' };
    }
  }
}

// Export singleton instance
module.exports = new ConnectionManager();

