const AWS = require('aws-sdk');

// Initialize AWS SDK
const dynamodb = new AWS.DynamoDB.DocumentClient();
const apigatewaymanagementapi = new AWS.ApiGatewayManagementApi({
  endpoint: process.env.WEBSOCKET_ENDPOINT
});

// DynamoDB table names
const CONNECTIONS_TABLE = process.env.CONNECTIONS_TABLE || 'vendor-websocket-connections';
const MESSAGES_TABLE = process.env.MESSAGES_TABLE || 'vendor-websocket-messages';

// Message types
const MESSAGE_TYPES = {
  CONNECT: 'connect',
  DISCONNECT: 'disconnect',
  MESSAGE: 'message',
  ORDER_UPDATE: 'orderUpdate',
  VENDOR_STATUS: 'vendorStatus',
  BROADCAST: 'broadcast',
  CHAT: 'chat',
  ERROR: 'error',
  VENDOR_ADDED: 'VENDOR_ADDED'
};

// Connection types
const CONNECTION_TYPES = {
  VENDOR: 'vendor',
  CUSTOMER: 'customer',
  ADMIN: 'admin'
};

/**
 * Main Lambda handler for WebSocket events
 */
exports.handler = async (event, context) => {
  console.log('=== LAMBDA HANDLER START ===');
  console.log('Event received:', JSON.stringify(event, null, 2));
  console.log('Context:', JSON.stringify(context, null, 2));
  
  try {
    const { routeKey, connectionId } = event.requestContext;
    console.log(`Processing route: ${routeKey} for connection: ${connectionId}`);
    
    let result;
    
    switch (routeKey) {
      case '$connect':
        console.log('Handling $connect route');
        result = await handleConnect(event);
        break;
      case '$disconnect':
        console.log('Handling $disconnect route');
        result = await handleDisconnect(event);
        break;
      case '$default':
        console.log('Handling $default route');
        result = await handleDefaultMessage(event);
        break;
      case 'square-oauth-callback':
        console.log('Handling Square OAuth callback');
        result = await handleSquareOAuthCallback(event);
        break;
      case 'stripe-oauth-callback':
        console.log('Handling Stripe OAuth callback');
        result = await handleStripeOAuthCallback(event);
        break;
      default:
        console.log(`Handling custom route: ${routeKey}`);
        result = await handleCustomRoute(event);
        break;
    }
    
    console.log('Route handler result:', JSON.stringify(result, null, 2));
    console.log('=== LAMBDA HANDLER SUCCESS ===');
    
    return result;
    
      } catch (error) {
      console.error('=== LAMBDA HANDLER ERROR ===');
      console.error('Error in main handler:', error);
      console.error('Error stack:', error.stack);
      console.error('=== LAMBDA HANDLER ERROR END ===');

      // For 410 errors, return success since this is expected behavior
      if (error.code === 'GoneException' || error.statusCode === 410) {
        console.log('Handling 410 error gracefully - returning success');
        return {
          statusCode: 200,
          body: JSON.stringify({
            message: 'Connection processed (client may have disconnected)',
            connectionId: event.requestContext?.connectionId || 'unknown'
          })
        };
      }

      return {
        statusCode: 500,
        body: JSON.stringify({
          error: 'Internal server error',
          message: error.message,
          routeKey: event.requestContext?.routeKey || 'unknown'
        })
      };
    }
};

/**
 * Handle new WebSocket connections
 */
async function handleConnect(event) {
  console.log('=== HANDLE CONNECT START ===');
  
  try {
    const { connectionId } = event.requestContext;
    const { queryStringParameters } = event;
    
    console.log('Connection ID:', connectionId);
    console.log('Query parameters:', JSON.stringify(queryStringParameters, null, 2));
    
    // Extract connection metadata
    const connectionData = {
      connectionId,
      connectionType: queryStringParameters?.type || CONNECTION_TYPES.CUSTOMER,
      userId: queryStringParameters?.userId || null,
      vendorId: queryStringParameters?.vendorId || null,
      timestamp: new Date().toISOString(),
      isActive: true
    };
    
    console.log('Connection data to store:', JSON.stringify(connectionData, null, 2));
    
    // Store connection in DynamoDB
    console.log('Storing connection in DynamoDB...');
    const dbResult = await dynamodb.put({
      TableName: CONNECTIONS_TABLE,
      Item: connectionData
    }).promise();
    
    console.log('DynamoDB put result:', JSON.stringify(dbResult, null, 2));
    console.log(`New connection established: ${connectionId}`);
    
    // Send welcome message
    console.log('Sending welcome message...');
    await sendMessage(connectionId, {
      type: MESSAGE_TYPES.CONNECT,
      message: 'Connected to vendor marketplace',
      connectionId,
      timestamp: new Date().toISOString()
    });
    
    console.log('=== HANDLE CONNECT SUCCESS ===');
    return { statusCode: 200, body: 'Connected' };
    
  } catch (error) {
    console.error('=== HANDLE CONNECT ERROR ===');
    console.error('Error in handleConnect:', error);
    console.error('Error stack:', error.stack);
    console.error('=== HANDLE CONNECT ERROR END ===');
    
    throw error;
  }
}

/**
 * Handle WebSocket disconnections
 */
async function handleDisconnect(event) {
  console.log('=== HANDLE DISCONNECT START ===');
  
  try {
    const { connectionId } = event.requestContext;
    console.log('Disconnecting connection:', connectionId);
    
    // Mark connection as inactive
    const updateResult = await dynamodb.update({
      TableName: CONNECTIONS_TABLE,
      Key: { connectionId },
      UpdateExpression: 'SET isActive = :isActive, disconnectedAt = :disconnectedAt',
      ExpressionAttributeValues: {
        ':isActive': false,
        ':disconnectedAt': new Date().toISOString()
      }
    }).promise();
    
    console.log('DynamoDB update result:', JSON.stringify(updateResult, null, 2));
    console.log(`Connection disconnected: ${connectionId}`);
    
    console.log('=== HANDLE DISCONNECT SUCCESS ===');
    return { statusCode: 200, body: 'Disconnected' };
    
  } catch (error) {
    console.error('=== HANDLE DISCONNECT ERROR ===');
    console.error('Error in handleDisconnect:', error);
    console.error('Error stack:', error.stack);
    console.error('=== HANDLE DISCONNECT ERROR END ===');
    
    throw error;
  }
}

/**
 * Handle default messages (fallback route)
 */
async function handleDefaultMessage(event) {
  console.log('=== HANDLE DEFAULT MESSAGE START ===');
  
  try {
    const { connectionId } = event.requestContext;
    const body = JSON.parse(event.body || '{}');
    
    console.log('Connection ID:', connectionId);
    console.log('Message body:', JSON.stringify(body, null, 2));
    
    // Route message based on type
    switch (body.type) {
      case MESSAGE_TYPES.CHAT:
        console.log('Routing to chat handler');
        return await handleChatMessage(event);
      case MESSAGE_TYPES.ORDER_UPDATE:
        console.log('Routing to order update handler');
        return await handleOrderUpdate(event);
      case MESSAGE_TYPES.VENDOR_STATUS:
        console.log('Routing to vendor status handler');
        return await handleVendorStatus(event);
      case MESSAGE_TYPES.BROADCAST:
        console.log('Routing to broadcast handler');
        return await handleBroadcast(event);
      default:
        console.log('No specific handler, echoing message back');
        // Echo message back to sender
        await sendMessage(connectionId, {
          type: MESSAGE_TYPES.MESSAGE,
          message: 'Message received',
          originalMessage: body,
          timestamp: new Date().toISOString()
        });
        console.log('=== HANDLE DEFAULT MESSAGE SUCCESS ===');
        return { statusCode: 200, body: 'Message processed' };
    }
    
  } catch (error) {
    console.error('=== HANDLE DEFAULT MESSAGE ERROR ===');
    console.error('Error in handleDefaultMessage:', error);
    console.error('Error stack:', error.stack);
    console.error('=== HANDLE DEFAULT MESSAGE ERROR END ===');
    
    throw error;
  }
}

/**
 * Handle custom route messages
 */
async function handleCustomRoute(event) {
  console.log('=== HANDLE CUSTOM ROUTE START ===');
  
  try {
    const { routeKey } = event.requestContext;
    const { connectionId } = event.requestContext;
    
    console.log('Custom route:', routeKey);
    console.log('Connection ID:', connectionId);
    
    switch (routeKey) {
      case 'sendMessage':
        console.log('Routing to chat handler');
        return await handleChatMessage(event);
      case 'updateOrderStatus':
        console.log('Routing to order update handler');
        return await handleOrderUpdate(event);
      case 'updateVendorStatus':
        console.log('Routing to vendor status handler');
        return await handleVendorStatus(event);
      case 'broadcast':
        console.log('Routing to broadcast handler');
        return await handleBroadcast(event);
      default:
        console.log(`Unknown route: ${routeKey}`);
        await sendMessage(connectionId, {
          type: MESSAGE_TYPES.ERROR,
          error: `Unknown route: ${routeKey}`,
          timestamp: new Date().toISOString()
        });
        console.log('=== HANDLE CUSTOM ROUTE SUCCESS (UNKNOWN ROUTE) ===');
        return { statusCode: 400, body: 'Unknown route' };
    }
    
  } catch (error) {
    console.error('=== HANDLE CUSTOM ROUTE ERROR ===');
    console.error('Error in handleCustomRoute:', error);
    console.error('Error stack:', error.stack);
    console.error('=== HANDLE CUSTOM ROUTE ERROR END ===');
    
    throw error;
  }
}

/**
 * Handle chat messages between users
 */
async function handleChatMessage(event) {
  console.log('=== HANDLE CHAT MESSAGE START ===');
  
  try {
    const { connectionId } = event.requestContext;
    const body = JSON.parse(event.body || '{}');
    
    console.log('Connection ID:', connectionId);
    console.log('Chat message body:', JSON.stringify(body, null, 2));
    
    const { recipientId, message, messageType = 'text' } = body;
    
    if (!recipientId || !message) {
      throw new Error('Missing recipientId or message');
    }
    
    // Store message in DynamoDB
    const messageData = {
      messageId: `msg_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      senderId: connectionId,
      recipientId,
      message,
      messageType,
      timestamp: new Date().toISOString(),
      isRead: false
    };
    
    console.log('Storing message in DynamoDB:', JSON.stringify(messageData, null, 2));
    
    const dbResult = await dynamodb.put({
      TableName: MESSAGES_TABLE,
      Item: messageData
    }).promise();
    
    console.log('Message stored in DynamoDB:', JSON.stringify(dbResult, null, 2));
    
    // Send message to recipient if they're online
    console.log('Looking for recipient connection...');
    const recipientConnection = await getActiveConnection(recipientId);
    
    if (recipientConnection) {
      console.log('Recipient found, sending message');
      await sendMessage(recipientConnection.connectionId, {
        type: MESSAGE_TYPES.CHAT,
        messageId: messageData.messageId,
        senderId: connectionId,
        message,
        messageType,
        timestamp: messageData.timestamp
      });
    } else {
      console.log('Recipient not online');
    }
    
    // Confirm message sent to sender
    console.log('Sending confirmation to sender');
    await sendMessage(connectionId, {
      type: MESSAGE_TYPES.CHAT,
      messageId: messageData.messageId,
      status: 'sent',
      timestamp: new Date().toISOString()
    });
    
    console.log('=== HANDLE CHAT MESSAGE SUCCESS ===');
    return { statusCode: 200, body: 'Message sent' };
    
  } catch (error) {
    console.error('=== HANDLE CHAT MESSAGE ERROR ===');
    console.error('Error in handleChatMessage:', error);
    console.error('Error stack:', error.stack);
    console.error('=== HANDLE CHAT MESSAGE ERROR END ===');
    
    throw error;
  }
}

/**
 * Handle order status updates
 */
async function handleOrderUpdate(event) {
  console.log('=== HANDLE ORDER UPDATE START ===');
  
  try {
    const { connectionId } = event.requestContext;
    const body = JSON.parse(event.body || '{}');
    
    console.log('Connection ID:', connectionId);
    console.log('Order update body:', JSON.stringify(body, null, 2));
    
    const { orderId, status, vendorId, customerId, details } = body;
    
    if (!orderId || !status) {
      throw new Error('Missing orderId or status');
    }
    
    // Store order update
    const updateData = {
      updateId: `update_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      orderId,
      status,
      vendorId,
      customerId,
      details,
      timestamp: new Date().toISOString(),
      updatedBy: connectionId
    };
    
    console.log('Order update data:', JSON.stringify(updateData, null, 2));
    
    // TODO: Update order in your main database
    console.log('Order update:', updateData);
    
    // Notify relevant parties
    if (customerId) {
      console.log('Looking for customer connection...');
      const customerConnection = await getActiveConnection(customerId);
      if (customerConnection) {
        console.log('Customer found, sending notification');
        await sendMessage(customerConnection.connectionId, {
          type: MESSAGE_TYPES.ORDER_UPDATE,
          orderId,
          status,
          details,
          timestamp: updateData.timestamp
        });
      }
    }
    
    if (vendorId) {
      console.log('Looking for vendor connections...');
      const vendorConnections = await getVendorConnections(vendorId);
      for (const conn of vendorConnections) {
        console.log('Sending notification to vendor connection:', conn.connectionId);
        await sendMessage(conn.connectionId, {
          type: MESSAGE_TYPES.ORDER_UPDATE,
          orderId,
          status,
          details,
          timestamp: updateData.timestamp
        });
      }
    }
    
    console.log('=== HANDLE ORDER UPDATE SUCCESS ===');
    return { statusCode: 200, body: 'Order updated' };
    
  } catch (error) {
    console.error('=== HANDLE ORDER UPDATE ERROR ===');
    console.error('Error in handleOrderUpdate:', error);
    console.error('Error stack:', error.stack);
    console.error('=== HANDLE ORDER UPDATE ERROR END ===');
    
    throw error;
  }
}

/**
 * Handle vendor status updates
 */
async function handleVendorStatus(event) {
  console.log('=== HANDLE VENDOR STATUS START ===');
  
  try {
    const { connectionId } = event.requestContext;
    const body = JSON.parse(event.body || '{}');
    
    console.log('Connection ID:', connectionId);
    console.log('Vendor status body:', JSON.stringify(body, null, 2));
    
    const { vendorId, status, availability = 'available', message = '' } = body;
    
    if (!vendorId || !status) {
      throw new Error('Missing vendorId or status');
    }
    
    // Update vendor status in connections table
    console.log('Updating vendor status in connections table...');
    const updateResult = await dynamodb.update({
      TableName: CONNECTIONS_TABLE,
      Key: { connectionId },
      UpdateExpression: 'SET vendorStatus = :status, availability = :availability, statusMessage = :message, lastStatusUpdate = :timestamp',
      ExpressionAttributeValues: {
        ':status': status,
        ':availability': availability,
        ':message': message,
        ':timestamp': new Date().toISOString()
      }
    }).promise();
    
    console.log('Vendor status updated:', JSON.stringify(updateResult, null, 2));
    
    // Broadcast status update to all connected customers
    console.log('Broadcasting status update to customers...');
    const customerConnections = await getConnectionsByType(CONNECTION_TYPES.CUSTOMER);
    
    for (const conn of customerConnections) {
      console.log('Sending status update to customer:', conn.connectionId);
      await sendMessage(conn.connectionId, {
        type: MESSAGE_TYPES.VENDOR_STATUS,
        vendorId,
        status,
        availability,
        message,
        timestamp: new Date().toISOString()
      });
    }
    
    console.log('=== HANDLE VENDOR STATUS SUCCESS ===');
    return { statusCode: 200, body: 'Vendor status updated' };
    
  } catch (error) {
    console.error('=== HANDLE VENDOR STATUS ERROR ===');
    console.error('Error in handleVendorStatus:', error);
    console.error('Error stack:', error.stack);
    console.error('=== HANDLE VENDOR STATUS ERROR END ===');
    
    throw error;
  }
}

/**
 * Handle broadcast messages
 */
async function handleBroadcast(event) {
  console.log('=== HANDLE BROADCAST START ===');
  
  try {
    const { connectionId } = event.requestContext;
    const body = JSON.parse(event.body || '{}');
    
    console.log('Connection ID:', connectionId);
    console.log('Broadcast body:', JSON.stringify(body, null, 2));
    
    const { message, targetType, targetIds } = body;
    
    if (!message) {
      throw new Error('Missing message');
    }
    
    let connections = [];
    
    if (targetType) {
      console.log(`Getting connections by type: ${targetType}`);
      connections = await getConnectionsByType(targetType);
    } else if (targetIds && Array.isArray(targetIds)) {
      console.log('Getting connections by IDs:', targetIds);
      connections = await getConnectionsByIds(targetIds);
    } else {
      console.log('Getting all active connections');
      connections = await getAllActiveConnections();
    }
    
    console.log(`Found ${connections.length} connections to broadcast to`);
    
    // Send broadcast message
    const broadcastData = {
      type: MESSAGE_TYPES.BROADCAST,
      message,
      senderId: connectionId,
      timestamp: new Date().toISOString(),
      targetType,
      targetIds
    };
    
    for (const conn of connections) {
      if (conn.connectionId !== connectionId) { // Don't send to sender
        console.log('Sending broadcast to:', conn.connectionId);
        await sendMessage(conn.connectionId, broadcastData);
      }
    }
    
    console.log('=== HANDLE BROADCAST SUCCESS ===');
    return { statusCode: 200, body: `Broadcast sent to ${connections.length} connections` };
    
  } catch (error) {
    console.error('=== HANDLE BROADCAST ERROR ===');
    console.error('Error in handleBroadcast:', error);
    console.error('Error stack:', error.stack);
    console.error('=== HANDLE BROADCAST ERROR END ===');
    
    throw error;
  }
}

/**
 * Send message to a specific connection
 */
async function sendMessage(connectionId, message) {
  console.log(`=== SEND MESSAGE START: ${connectionId} ===`);
  
  try {
    console.log('Sending message:', JSON.stringify(message, null, 2));
    
    const result = await apigatewaymanagementapi.postToConnection({
      ConnectionId: connectionId,
      Data: JSON.stringify(message)
    }).promise();
    
    console.log('Message sent successfully:', JSON.stringify(result, null, 2));
    console.log(`=== SEND MESSAGE SUCCESS: ${connectionId} ===`);
    
  } catch (error) {
    console.error(`=== SEND MESSAGE ERROR: ${connectionId} ===`);
    console.error('Error sending message:', error);
    
    if (error.statusCode === 410) {
      // Connection is stale, remove it gracefully
      console.log(`Connection ${connectionId} is stale (410), removing from DynamoDB`);
      try {
        await removeStaleConnection(connectionId);
        console.log(`Stale connection ${connectionId} cleaned up successfully`);
        // Don't throw error for 410s - this is expected behavior
        return;
      } catch (cleanupError) {
        console.error(`Failed to cleanup stale connection ${connectionId}:`, cleanupError);
        // Still don't throw - we don't want 410s to crash the Lambda
        return;
      }
    }
    
    // For non-410 errors, log and continue (don't crash the Lambda)
    console.error(`Non-410 error sending message to ${connectionId}:`, error.message);
    console.error(`=== SEND MESSAGE ERROR END: ${connectionId} ===`);
    // Don't throw - we want the Lambda to continue processing
  }
}

/**
 * Get active connection by user ID
 */
async function getActiveConnection(userId) {
  console.log(`=== GET ACTIVE CONNECTION START: ${userId} ===`);
  
  try {
    console.log('Querying DynamoDB for user connection...');
    
    const result = await dynamodb.query({
      TableName: CONNECTIONS_TABLE,
      IndexName: 'UserIdIndex',
      KeyConditionExpression: 'userId = :userId',
      FilterExpression: 'isActive = :isActive',
      ExpressionAttributeValues: {
        ':userId': userId,
        ':isActive': true
      }
    }).promise();
    
    console.log('DynamoDB query result:', JSON.stringify(result, null, 2));
    
    const connection = result.Items[0] || null;
    console.log(`Active connection found: ${connection ? 'YES' : 'NO'}`);
    
    console.log(`=== GET ACTIVE CONNECTION SUCCESS: ${userId} ===`);
    return connection;
    
  } catch (error) {
    console.error(`=== GET ACTIVE CONNECTION ERROR: ${userId} ===`);
    console.error('Error getting active connection:', error);
    console.error('Error stack:', error.stack);
    console.error(`=== GET ACTIVE CONNECTION ERROR END: ${userId} ===`);
    
    return null;
  }
}

/**
 * Get all connections by type
 */
async function getConnectionsByType(connectionType) {
  console.log(`=== GET CONNECTIONS BY TYPE START: ${connectionType} ===`);
  
  try {
    console.log('Querying DynamoDB for connections by type...');
    
    const result = await dynamodb.query({
      TableName: CONNECTIONS_TABLE,
      IndexName: 'ConnectionTypeIndex',
      KeyConditionExpression: 'connectionType = :type',
      FilterExpression: 'isActive = :isActive',
      ExpressionAttributeValues: {
        ':type': connectionType,
        ':isActive': true
      }
    }).promise();
    
    console.log('DynamoDB query result:', JSON.stringify(result, null, 2));
    
    const connections = result.Items || [];
    console.log(`Found ${connections.length} connections of type: ${connectionType}`);
    
    console.log(`=== GET CONNECTIONS BY TYPE SUCCESS: ${connectionType} ===`);
    return connections;
    
  } catch (error) {
    console.error(`=== GET CONNECTIONS BY TYPE ERROR: ${connectionType} ===`);
    console.error('Error getting connections by type:', error);
    console.error('Error stack:', error.stack);
    console.error(`=== GET CONNECTIONS BY TYPE ERROR END: ${connectionType} ===`);
    
    return [];
  }
}

/**
 * Get vendor connections
 */
async function getVendorConnections(vendorId) {
  console.log(`=== GET VENDOR CONNECTIONS START: ${vendorId} ===`);
  
  try {
    console.log('Querying DynamoDB for vendor connections...');
    
    const result = await dynamodb.query({
      TableName: CONNECTIONS_TABLE,
      IndexName: 'VendorIdIndex',
      KeyConditionExpression: 'vendorId = :vendorId',
      FilterExpression: 'isActive = :isActive',
      ExpressionAttributeValues: {
        ':vendorId': vendorId,
        ':isActive': true
      }
    }).promise();
    
    console.log('DynamoDB query result:', JSON.stringify(result, null, 2));
    
    const connections = result.Items || [];
    console.log(`Found ${connections.length} vendor connections`);
    
    console.log(`=== GET VENDOR CONNECTIONS SUCCESS: ${vendorId} ===`);
    return connections;
    
  } catch (error) {
    console.error(`=== GET VENDOR CONNECTIONS ERROR: ${vendorId} ===`);
    console.error('Error getting vendor connections:', error);
    console.error('Error stack:', error.stack);
    console.error(`=== GET VENDOR CONNECTIONS ERROR END: ${vendorId} ===`);
    
    return [];
  }
}

/**
 * Get connections by IDs
 */
async function getConnectionsByIds(connectionIds) {
  console.log(`=== GET CONNECTIONS BY IDS START ===`);
  
  try {
    console.log('Getting connections by IDs:', connectionIds);
    
    const connections = [];
    for (const id of connectionIds) {
      console.log(`Getting connection: ${id}`);
      const result = await dynamodb.get({
        TableName: CONNECTIONS_TABLE,
        Key: { connectionId: id }
      }).promise();
      
      if (result.Item && result.Item.isActive) {
        connections.push(result.Item);
      }
    }
    
    console.log(`Found ${connections.length} active connections`);
    console.log('=== GET CONNECTIONS BY IDS SUCCESS ===');
    return connections;
    
  } catch (error) {
    console.error('=== GET CONNECTIONS BY IDS ERROR ===');
    console.error('Error getting connections by IDs:', error);
    console.error('Error stack:', error.stack);
    console.error('=== GET CONNECTIONS BY IDS ERROR END ===');
    
    return [];
  }
}

/**
 * Get all active connections
 */
async function getAllActiveConnections() {
  console.log('=== GET ALL ACTIVE CONNECTIONS START ===');
  
  try {
    console.log('Scanning DynamoDB for all active connections...');
    
    const result = await dynamodb.scan({
      TableName: CONNECTIONS_TABLE,
      FilterExpression: 'isActive = :isActive',
      ExpressionAttributeValues: {
        ':isActive': true
      }
    }).promise();
    
    console.log('DynamoDB scan result:', JSON.stringify(result, null, 2));
    
    const connections = result.Items || [];
    console.log(`Found ${connections.length} total active connections`);
    
    console.log('=== GET ALL ACTIVE CONNECTIONS SUCCESS ===');
    return connections;
    
  } catch (error) {
    console.error('=== GET ALL ACTIVE CONNECTIONS ERROR ===');
    console.error('Error getting all active connections:', error);
    console.error('Error stack:', error.stack);
    console.error('=== GET ALL ACTIVE CONNECTIONS ERROR END ===');
    
    return [];
  }
}

/**
 * Remove stale connection
 */
async function removeStaleConnection(connectionId) {
  console.log(`=== REMOVE STALE CONNECTION START: ${connectionId} ===`);
  
  try {
    console.log('Updating connection as inactive...');
    
    const result = await dynamodb.update({
      TableName: CONNECTIONS_TABLE,
      Key: { connectionId },
      UpdateExpression: 'SET isActive = :isActive, disconnectedAt = :disconnectedAt',
      ExpressionAttributeValues: {
        ':isActive': false,
        ':disconnectedAt': new Date().toISOString()
      }
    }).promise();
    
    console.log('Connection marked as inactive:', JSON.stringify(result, null, 2));
    console.log(`=== REMOVE STALE CONNECTION SUCCESS: ${connectionId} ===`);
    
  } catch (error) {
    console.error(`=== REMOVE STALE CONNECTION ERROR: ${connectionId} ===`);
    console.error('Error removing stale connection:', error);
    console.error('Error stack:', error.stack);
    console.error(`=== REMOVE STALE CONNECTION ERROR END: ${connectionId} ===`);
  }
}

/**
 * Handle Square OAuth callback
 * This makes the system truly serverless - no backend needed!
 */
async function handleSquareOAuthCallback(event) {
  console.log('=== HANDLE SQUARE OAUTH CALLBACK START ===');
  
  try {
    const body = JSON.parse(event.body || '{}');
    const { code, state, vendorId } = body;
    
    if (!code) {
      throw new Error('Authorization code is required');
    }
    
    console.log('Processing Square OAuth callback:', { code: code.substring(0, 10) + '...', state, vendorId });
    
    // Exchange authorization code for access token
    const tokenResponse = await exchangeSquareCodeForToken(code);
    
    if (!tokenResponse.success) {
      throw new Error(`Token exchange failed: ${tokenResponse.error}`);
    }
    
    // Get merchant information
    const merchantInfo = await getSquareMerchantInfo(tokenResponse.accessToken);
    
    if (!merchantInfo.success) {
      throw new Error(`Failed to get merchant info: ${merchantInfo.error}`);
    }
    
    // Create vendor data
    const vendorData = {
      id: vendorId || `vendor_${Date.now()}`,
      merchantId: merchantInfo.merchant.id,
      accessToken: tokenResponse.accessToken,
      refreshToken: tokenResponse.refreshToken,
      businessName: merchantInfo.merchant.business_name || 'Unknown Business',
      businessType: merchantInfo.merchant.business_type || 'FOOD_AND_DRINK',
      country: merchantInfo.merchant.country || 'US',
      languageCode: merchantInfo.merchant.language_code || 'en-US',
      currency: merchantInfo.merchant.currency || 'USD',
      status: 'inactive', // Starts inactive until admin approval
      createdAt: new Date().toISOString(),
      lastUpdated: new Date().toISOString()
    };
    
    // Store vendor in DynamoDB
    await storeVendorInDynamoDB(vendorData);
    
    // Broadcast VENDOR_ADDED event to all connected customers
    await broadcastVendorAdded(vendorData);
    
    console.log('=== HANDLE SQUARE OAUTH CALLBACK SUCCESS ===');
    
    return {
      statusCode: 200,
      body: JSON.stringify({
        success: true,
        vendor: {
          id: vendorData.id,
          businessName: vendorData.businessName,
          status: vendorData.status,
          message: 'Vendor successfully connected to Square!'
        }
      })
    };
    
  } catch (error) {
    console.error('=== HANDLE SQUARE OAUTH CALLBACK ERROR ===');
    console.error('Error in Square OAuth callback:', error);
    console.error('Error stack:', error.stack);
    console.error('=== HANDLE SQUARE OAUTH CALLBACK ERROR END ===');
    
    return {
      statusCode: 500,
      body: JSON.stringify({
        success: false,
        error: 'Failed to complete Square OAuth process',
        message: error.message
      })
    };
  }
}

/**
 * Handle Stripe OAuth callback
 * This makes the system truly serverless - no backend needed!
 */
async function handleStripeOAuthCallback(event) {
  console.log('=== HANDLE STRIPE OAUTH CALLBACK START ===');
  
  try {
    const body = JSON.parse(event.body || '{}');
    const { code, state, vendorId } = body;
    
    if (!code) {
      throw new Error('Authorization code is required');
    }
    
    console.log('Processing Stripe OAuth callback:', { code: code.substring(0, 10) + '...', state, vendorId });
    
    // Exchange authorization code for access token
    const tokenResponse = await exchangeStripeCodeForToken(code);
    
    if (!tokenResponse.success) {
      throw new Error(`Token exchange failed: ${tokenResponse.error}`);
    }
    
    // Get account information
    const accountInfo = await getStripeAccountInfo(tokenResponse.accessToken);
    
    if (!accountInfo.success) {
      throw new Error(`Failed to get account info: ${accountInfo.error}`);
    }
    
    // Create vendor data
    const vendorData = {
      id: vendorId || `vendor_${Date.now()}`,
      stripeAccountId: tokenResponse.stripe_user_id,
      accessToken: tokenResponse.accessToken,
      refreshToken: tokenResponse.refreshToken,
      businessName: accountInfo.account.business_profile?.name || 'Unknown Business',
      businessType: 'stripe',
      country: accountInfo.account.country || 'US',
      currency: accountInfo.account.default_currency || 'usd',
      status: 'inactive', // Starts inactive until admin approval
      createdAt: new Date().toISOString(),
      lastUpdated: new Date().toISOString()
    };
    
    // Store vendor in DynamoDB
    await storeVendorInDynamoDB(vendorData);
    
    // Broadcast VENDOR_ADDED event to all connected customers
    await broadcastVendorAdded(vendorData);
    
    console.log('=== HANDLE STRIPE OAUTH CALLBACK SUCCESS ===');
    
    return {
      statusCode: 200,
      body: JSON.stringify({
        success: true,
        vendor: {
          id: vendorData.id,
          businessName: vendorData.businessName,
          status: vendorData.status,
          message: 'Vendor successfully connected to Stripe!'
        }
      })
    };
    
  } catch (error) {
    console.error('=== HANDLE STRIPE OAUTH CALLBACK ERROR ===');
    console.error('Error in Stripe OAuth callback:', error);
    console.error('Error stack:', error.stack);
    console.error('=== HANDLE STRIPE OAUTH CALLBACK ERROR END ===');
    
    return {
      statusCode: 500,
      body: JSON.stringify({
        success: false,
        error: 'Failed to complete Stripe OAuth process',
        message: error.message
      })
    };
  }
}

/**
 * Store vendor data in DynamoDB
 */
async function storeVendorInDynamoDB(vendorData) {
  console.log('Storing vendor in DynamoDB:', vendorData.id);
  
  const result = await dynamodb.put({
    TableName: 'vendors',
    Item: vendorData
  }).promise();
  
  console.log('Vendor stored successfully:', result);
  return result;
}

/**
 * Broadcast VENDOR_ADDED event to all connected customers
 */
async function broadcastVendorAdded(vendorData) {
  console.log('Broadcasting VENDOR_ADDED event for:', vendorData.businessName);
  
  try {
    // Get all customer connections
    const customerConnections = await getConnectionsByType(CONNECTION_TYPES.CUSTOMER);
    
    // Create the event payload
    const eventPayload = {
      type: MESSAGE_TYPES.VENDOR_ADDED,
      vendor: {
        merchantId: vendorData.merchantId || vendorData.stripeAccountId,
        businessName: vendorData.businessName,
        status: vendorData.status,
        connectedAt: vendorData.createdAt,
        businessType: vendorData.businessType,
        country: vendorData.country,
        currency: vendorData.currency
      }
    };
    
    // Send to all connected customers
    for (const conn of customerConnections) {
      try {
        await sendMessage(conn.connectionId, eventPayload);
        console.log('VENDOR_ADDED event sent to customer:', conn.connectionId);
      } catch (error) {
        console.warn('Failed to send to customer:', conn.connectionId, error.message);
      }
    }
    
    console.log(`✅ VENDOR_ADDED event broadcasted to ${customerConnections.length} customers`);
    
  } catch (error) {
    console.error('❌ Error broadcasting VENDOR_ADDED event:', error);
    // Don't fail the OAuth process if broadcasting fails
  }
}

/**
 * Exchange Square authorization code for access token
 */
async function exchangeSquareCodeForToken(code) {
  const https = require('https');
  
  return new Promise((resolve) => {
    const postData = JSON.stringify({
      client_id: process.env.SQUARE_APP_ID,
      client_secret: process.env.SQUARE_APP_SECRET,
      code: code,
      grant_type: 'authorization_code'
    });

    const options = {
      hostname: 'connect.squareup.com',
      path: '/oauth2/token',
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(postData)
      }
    };

    const req = https.request(options, (res) => {
      let responseData = '';
      
      res.on('data', (chunk) => {
        responseData += chunk;
      });
      
      res.on('end', () => {
        try {
          const parsedData = JSON.parse(responseData);
          if (res.statusCode >= 200 && res.statusCode < 300) {
            resolve({
              success: true,
              accessToken: parsedData.access_token,
              refreshToken: parsedData.refresh_token,
              expiresIn: parsedData.expires_in
            });
          } else {
            resolve({
              success: false,
              error: parsedData.error_description || 'Token exchange failed'
            });
          }
        } catch (error) {
          resolve({
            success: false,
            error: 'Failed to parse token response'
          });
        }
      });
    });

    req.on('error', (error) => {
      resolve({
        success: false,
        error: 'Token exchange request failed'
      });
    });

    req.write(postData);
    req.end();
  });
}

/**
 * Get Square merchant information
 */
async function getSquareMerchantInfo(accessToken) {
  const https = require('https');
  
  return new Promise((resolve) => {
    const options = {
      hostname: 'connect.squareup.com',
      path: '/v2/merchants/me',
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Square-Version': '2024-01-17'
      }
    };

    const req = https.request(options, (res) => {
      let responseData = '';
      
      res.on('data', (chunk) => {
        responseData += chunk;
      });
      
      res.on('end', () => {
        try {
          const parsedData = JSON.parse(responseData);
          if (res.statusCode >= 200 && res.statusCode < 300) {
            resolve({
              success: true,
              merchant: parsedData.merchant
            });
          } else {
            resolve({
              success: false,
              error: parsedData.error_description || 'Failed to get merchant info'
            });
          }
        } catch (error) {
          resolve({
            success: false,
            error: 'Failed to parse merchant response'
          });
        }
      });
    });

    req.on('error', (error) => {
      resolve({
        success: false,
        error: 'Merchant info request failed'
      });
    });

    req.end();
  });
}

/**
 * Exchange Stripe authorization code for access token
 */
async function exchangeStripeCodeForToken(code) {
  const https = require('https');
  
  return new Promise((resolve) => {
    const postData = `grant_type=authorization_code&client_secret=${process.env.STRIPE_SECRET_KEY}&code=${code}`;
    
    const options = {
      hostname: 'connect.stripe.com',
      path: '/oauth/token',
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Content-Length': Buffer.byteLength(postData)
      }
    };

    const req = https.request(options, (res) => {
      let responseData = '';
      
      res.on('data', (chunk) => {
        responseData += chunk;
      });
      
      res.on('end', () => {
        try {
          const parsedData = JSON.parse(responseData);
          if (res.statusCode >= 200 && res.statusCode < 300) {
            resolve({
              success: true,
              accessToken: parsedData.access_token,
              refreshToken: parsedData.refresh_token,
              stripe_user_id: parsedData.stripe_user_id
            });
          } else {
            resolve({
              success: false,
              error: parsedData.error_description || 'Failed to exchange code for token'
            });
          }
        } catch (error) {
          resolve({
            success: false,
            error: 'Failed to parse Stripe token response'
          });
        }
      });
    });

    req.on('error', (error) => {
      resolve({
        success: false,
        error: 'Stripe token request failed'
      });
    });

    req.write(postData);
    req.end();
  });
}

/**
 * Get Stripe account information
 */
async function getStripeAccountInfo(accessToken) {
  const https = require('https');
  
  return new Promise((resolve) => {
    const options = {
      hostname: 'api.stripe.com',
      path: '/v1/account',
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Stripe-Version': '2024-01-17'
      }
    };

    const req = https.request(options, (res) => {
      let responseData = '';
      
      res.on('data', (chunk) => {
        responseData += chunk;
      });
      
      res.on('end', () => {
        try {
          const parsedData = JSON.parse(responseData);
          if (res.statusCode >= 200 && res.statusCode < 300) {
            resolve({
              success: true,
              account: parsedData
            });
          } else {
            resolve({
              success: false,
              error: parsedData.error?.message || 'Failed to get account info'
            });
          }
        } catch (error) {
          resolve({
            success: false,
            error: 'Failed to parse account response'
          });
        }
      });
    });

    req.on('error', (error) => {
      resolve({
        success: false,
            error: 'Account info request failed'
          });
        });
        
        req.end();
      });
    }
