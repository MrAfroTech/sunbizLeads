# 🚀 Customer Bridge Lambda (Point B)

This Lambda function acts as a **message receiver** that catches vendor updates from Point A and makes them available to the Customer UI.

## 📋 What It Does

**Two Main Functions:**
1. **POST /vendor-update** - Receives vendor updates from Point A and saves them
2. **GET /vendor-info** - Provides the latest vendor info to the Customer UI

## 🏗️ Architecture

```
Point A (Vendor) → POST /vendor-update → Customer Bridge Lambda → DynamoDB
                                                                    ↓
Customer UI ← GET /vendor-info ← Customer Bridge Lambda ←──────────┘
```

## 🚀 Quick Start

### Step 1: Set Up DynamoDB Table
```bash
cd backend/scripts
node create-vendor-updates-table.js
```

### Step 2: Deploy Lambda Function
```bash
cd backend/scripts
node deploy-customer-bridge.js
```

### Step 3: Test the Function
```bash
cd backend/scripts
node test-customer-bridge.js
```

## 📊 API Endpoints

### POST /vendor-update
**Receives vendor updates from Point A**

**Request Body:**
```json
{
  "vendorId": "vendor-123",
  "updateType": "menu_update",
  "data": {
    "newItems": ["Mojito", "Margarita"],
    "removedItems": ["Old Fashioned"],
    "priceChanges": {
      "Mojito": 12.99,
      "Margarita": 13.99
    }
  }
}
```

**Response:**
```json
{
  "message": "Got it, thanks!",
  "updateId": "vendor-123-1703123456789-abc123def",
  "timestamp": "2023-12-21T10:30:56.789Z"
}
```

### GET /vendor-info
**Provides latest vendor info to Customer UI**

**Query Parameters:**
- `vendorId` (optional) - Filter by specific vendor
- `limit` (optional) - Number of updates to return (default: 10, max: 100)

**Example Request:**
```
GET /vendor-info?vendorId=vendor-123&limit=5
```

**Response:**
```json
{
  "message": "Here is the latest vendor info!",
  "totalUpdates": 15,
  "returnedUpdates": 5,
  "updates": [
    {
      "id": "vendor-123-1703123456789-abc123def",
      "vendorId": "vendor-123",
      "updateType": "menu_update",
      "timestamp": "2023-12-21T10:30:56.789Z",
      "data": {
        "newItems": ["Mojito", "Margarita"],
        "removedItems": ["Old Fashioned"],
        "priceChanges": {
          "Mojito": 12.99,
          "Margarita": 13.99
        }
      },
      "status": "received"
    }
  ]
}
```

## 🗄️ Data Storage

**DynamoDB Table: `vendor-updates-table`**

**Table Structure:**
- **Primary Key:** `id` (String) - Unique identifier
- **GSI:** `vendorId-timestamp-index` for efficient queries

**Record Structure:**
```json
{
  "id": "vendor-123-1703123456789-abc123def",
  "vendorId": "vendor-123",
  "updateType": "menu_update",
  "timestamp": "2023-12-21T10:30:56.789Z",
  "data": {},
  "status": "received"
}
```

## ⚙️ Configuration

**Environment Variables:**
- `VENDOR_UPDATES_TABLE` - DynamoDB table name (default: `vendor-updates-table`)

**Lambda Settings:**
- **Runtime:** Node.js 18.x
- **Timeout:** 30 seconds
- **Memory:** 256 MB
- **Handler:** `customer-bridge-lambda.handler`

## 🔧 Development

### Local Testing
```bash
# Test specific functions
node -e "
const { testVendorUpdate, testGetVendorInfo } = require('./test-customer-bridge.js');
testVendorUpdate().then(() => testGetVendorInfo());
"
```

### Adding New Update Types
1. Update the validation in `handleVendorUpdate()`
2. Add any new fields to the `updateRecord` object
3. Update tests to cover new functionality

## 🚨 Error Handling

**HTTP Status Codes:**
- `200` - Success
- `400` - Bad Request (invalid JSON, missing fields)
- `404` - Route not found
- `405` - Method not allowed
- `500` - Internal server error

**Error Response Format:**
```json
{
  "error": "Error description",
  "message": "Detailed error message"
}
```

## 🔒 Security & Permissions

**IAM Role:** `customer-bridge-lambda-role`

**Required Permissions:**
- CloudWatch Logs (create log groups/streams)
- DynamoDB (CRUD operations on vendor-updates-table)

## 📝 Logging

**CloudWatch Log Group:** `/aws/lambda/customer-bridge-lambda`

**Log Format:**
```
=== CUSTOMER BRIDGE LAMBDA START ===
Event received: {...}
Processing POST request to /vendor-update
Handling vendor update request
Saving vendor update: {...}
Vendor update saved successfully
Handler result: {...}
=== CUSTOMER BRIDGE LAMBDA SUCCESS ===
```

## 🧪 Testing

**Test Coverage:**
- ✅ POST /vendor-update - Success case
- ✅ GET /vendor-info - Success case
- ✅ Error handling - Invalid JSON
- ✅ 404 handling - Invalid routes
- ✅ CORS headers
- ✅ DynamoDB integration

**Run Tests:**
```bash
node test-customer-bridge.js
```

## 🚀 Deployment

**Manual Deployment:**
```bash
cd backend/scripts
node deploy-customer-bridge.js
```

**CI/CD Integration:**
```bash
# Build and deploy
npm run build
npm run deploy
```

## 🔍 Monitoring

**Key Metrics to Watch:**
- Lambda invocation count
- Lambda duration
- DynamoDB read/write capacity
- Error rates
- API Gateway 4xx/5xx responses

**CloudWatch Alarms:**
- Lambda errors > 0
- Lambda duration > 25 seconds
- DynamoDB throttling

## 🆘 Troubleshooting

**Common Issues:**

1. **DynamoDB Table Not Found**
   - Run `create-vendor-updates-table.js`
   - Check table name in environment variables

2. **Lambda Timeout**
   - Increase timeout in Lambda configuration
   - Check DynamoDB performance

3. **Permission Denied**
   - Verify IAM role has correct permissions
   - Check CloudWatch logs for detailed errors

4. **CORS Issues**
   - Verify CORS headers in responses
   - Check API Gateway CORS settings

## 📚 Next Steps

**Potential Enhancements:**
- Add authentication/authorization
- Implement update filtering and search
- Add update validation schemas
- Implement update archiving
- Add real-time notifications via WebSocket
- Implement update batching for performance

## 🤝 Support

**For Issues:**
1. Check CloudWatch logs first
2. Run test suite to verify functionality
3. Check DynamoDB table status
4. Verify IAM permissions

**Contact:** Development Team
