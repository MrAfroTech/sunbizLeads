/**
 * TicketSeam Update Event Lambda Function
 * Updates an existing event
 */

const AWS = require('aws-sdk');
const { createResponse, createErrorResponse } = require('../utils/responseHelper');

const dynamodb = new AWS.DynamoDB.DocumentClient();
const eventsTable = process.env.EVENTS_TABLE;

exports.handler = async (event) => {
  console.log('Update Event Lambda triggered:', JSON.stringify(event, null, 2));

  try {
    // Extract event ID from path parameters
    const eventId = event.pathParameters?.eventId;

    if (!eventId) {
      return createErrorResponse(400, 'Event ID is required');
    }

    // Parse request body
    const requestBody = JSON.parse(event.body);
    const updateData = requestBody;

    // Validate that event exists
    const getParams = {
      TableName: eventsTable,
      Key: {
        eventId: eventId
      }
    };

    const existingEvent = await dynamodb.get(getParams).promise();

    if (!existingEvent.Item) {
      return createErrorResponse(404, 'Event not found');
    }

    // Prepare update expression
    const timestamp = new Date().toISOString();
    const updateExpression = 'SET updatedAt = :updatedAt';
    const expressionAttributeValues = {
      ':updatedAt': timestamp
    };
    const expressionAttributeNames = {};

    // Build update expression dynamically
    const allowedFields = [
      'name', 'description', 'eventDate', 'startTime', 'endTime', 'timezone',
      'location', 'capacity', 'ticketTypes', 'images', 'settings', 'pricing', 'status'
    ];

    allowedFields.forEach(field => {
      if (updateData[field] !== undefined) {
        updateExpression += `, #${field} = :${field}`;
        expressionAttributeNames[`#${field}`] = field;
        expressionAttributeValues[`:${field}`] = updateData[field];
      }
    });

    // Update event in DynamoDB
    const updateParams = {
      TableName: eventsTable,
      Key: {
        eventId: eventId
      },
      UpdateExpression: updateExpression,
      ExpressionAttributeNames: expressionAttributeNames,
      ExpressionAttributeValues: expressionAttributeValues,
      ReturnValues: 'ALL_NEW'
    };

    const result = await dynamodb.update(updateParams).promise();

    console.log(`Event updated successfully: ${eventId}`);

    return createResponse(200, {
      message: 'Event updated successfully',
      eventId,
      event: result.Attributes
    });

  } catch (error) {
    console.error('Error updating event:', error);
    return createErrorResponse(500, 'Internal server error');
  }
};
