/**
 * TicketSeam Generate Ticket Lambda Function
 * Creates tickets with QR codes and processes payment
 */

const AWS = require('aws-sdk');
const { v4: uuidv4 } = require('uuid');
const QRCode = require('qrcode');
const crypto = require('crypto');
const { createResponse, createErrorResponse } = require('../utils/responseHelper');

const dynamodb = new AWS.DynamoDB.DocumentClient();
const s3 = new AWS.S3();
const ses = new AWS.SES();

const ticketsTable = process.env.TICKETS_TABLE;
const salesTable = process.env.SALES_TABLE;
const qrCodeBucket = process.env.QR_CODE_BUCKET;

exports.handler = async (event) => {
  console.log('Generate Ticket Lambda triggered:', JSON.stringify(event, null, 2));

  try {
    // Parse request body
    const requestBody = JSON.parse(event.body);
    const {
      eventId,
      purchaseId,
      ticketTypeId,
      attendeeEmail,
      attendeeName,
      quantity = 1,
      paymentData
    } = requestBody;

    // Validate required fields
    if (!eventId || !purchaseId || !ticketTypeId || !attendeeEmail || !attendeeName) {
      return createErrorResponse(400, 'Missing required fields');
    }

    // Get event details
    const event = await getEventDetails(eventId);
    if (!event) {
      return createErrorResponse(404, 'Event not found');
    }

    // Get ticket type details
    const ticketType = event.ticketTypes.find(tt => tt.typeId === ticketTypeId);
    if (!ticketType) {
      return createErrorResponse(404, 'Ticket type not found');
    }

    // Check availability
    if (ticketType.quantitySold + quantity > ticketType.quantityAvailable) {
      return createErrorResponse(400, 'Insufficient tickets available');
    }

    const timestamp = new Date().toISOString();
    const tickets = [];

    // Generate tickets
    for (let i = 0; i < quantity; i++) {
      const ticketId = `tkt_${uuidv4().replace(/-/g, '')}`;
      
      // Create QR code data
      const qrCodeData = {
        ticketId,
        eventId,
        typeId: ticketTypeId,
        purchaseId,
        attendeeEmail,
        timestamp,
        checksum: generateChecksum(ticketId, eventId, attendeeEmail),
        version: '1.0'
      };

      // Generate QR code
      const qrCodeBuffer = await QRCode.toBuffer(JSON.stringify(qrCodeData), {
        type: 'png',
        width: 300,
        margin: 2,
        color: {
          dark: '#000000',
          light: '#FFFFFF'
        }
      });

      // Upload QR code to S3
      const qrCodeKey = `tickets/${ticketId}.png`;
      await s3.upload({
        Bucket: qrCodeBucket,
        Key: qrCodeKey,
        Body: qrCodeBuffer,
        ContentType: 'image/png',
        ACL: 'private'
      }).promise();

      const qrCodeUrl = `https://${qrCodeBucket}.s3.amazonaws.com/${qrCodeKey}`;

      // Calculate pricing
      const pricing = calculatePricing(ticketType.price, event.pricing);

      // Create ticket document
      const ticketDocument = {
        ticketId,
        eventId,
        purchaseId,
        typeId: ticketTypeId,
        attendeeEmail,
        attendeeName,
        qrCode: qrCodeBuffer.toString('base64'),
        qrCodeUrl,
        status: 'active',
        price: ticketType.price,
        fees: pricing.fees,
        validation: {
          isValid: false,
          validatedAt: null,
          validatedBy: null,
          validationLocation: null,
          validationNotes: null
        },
        transfer: {
          isTransferable: true,
          transferCode: `TRF_${crypto.randomBytes(8).toString('hex').toUpperCase()}`,
          transferredTo: null,
          transferredAt: null,
          transferredBy: null
        },
        refund: {
          isRefundable: event.settings.allowRefunds,
          refundAmount: 0,
          refundReason: null,
          refundedAt: null,
          refundedBy: null
        },
        metadata: {
          seatNumber: null,
          section: ticketType.name,
          specialInstructions: '',
          dietaryRestrictions: '',
          accessibilityNeeds: ''
        },
        createdAt: timestamp,
        updatedAt: timestamp,
        expiresAt: new Date(event.eventDate + 'T' + event.endTime).toISOString()
      };

      // Save ticket to DynamoDB
      await dynamodb.put({
        TableName: ticketsTable,
        Item: ticketDocument
      }).promise();

      tickets.push({
        ticketId,
        attendeeEmail,
        attendeeName,
        qrCodeUrl,
        price: ticketType.price,
        fees: pricing.fees
      });
    }

    // Update event ticket counts
    await updateEventTicketCounts(eventId, ticketTypeId, quantity);

    // Send ticket email
    await sendTicketEmail(tickets, event, attendeeEmail);

    console.log('Tickets generated successfully:', tickets.length);

    return createResponse(201, {
      message: 'Tickets generated successfully',
      tickets: tickets.map(t => ({
        ticketId: t.ticketId,
        attendeeEmail: t.attendeeEmail,
        attendeeName: t.attendeeName,
        qrCodeUrl: t.qrCodeUrl
      })),
      totalAmount: tickets.reduce((sum, t) => sum + t.price + t.fees.total, 0)
    });

  } catch (error) {
    console.error('Error generating tickets:', error);
    return createErrorResponse(500, 'Internal server error');
  }
};

/**
 * Get event details from DynamoDB
 */
async function getEventDetails(eventId) {
  try {
    const result = await dynamodb.get({
      TableName: process.env.EVENTS_TABLE,
      Key: { eventId }
    }).promise();
    
    return result.Item;
  } catch (error) {
    console.error('Error getting event details:', error);
    return null;
  }
}

/**
 * Generate checksum for QR code validation
 */
function generateChecksum(ticketId, eventId, attendeeEmail) {
  const data = `${ticketId}-${eventId}-${attendeeEmail}`;
  return crypto.createHash('sha256').update(data).digest('hex').substring(0, 20);
}

/**
 * Calculate ticket pricing including fees
 */
function calculatePricing(basePrice, eventPricing) {
  const platformFee = basePrice * eventPricing.platformFee;
  const processingFee = basePrice * eventPricing.processingFee;
  const flatFee = eventPricing.flatFee;
  const totalFees = platformFee + processingFee + flatFee;

  return {
    platformFee: Math.round(platformFee * 100) / 100,
    processingFee: Math.round(processingFee * 100) / 100,
    flatFee: flatFee,
    total: Math.round(totalFees * 100) / 100
  };
}

/**
 * Update event ticket counts
 */
async function updateEventTicketCounts(eventId, ticketTypeId, quantity) {
  try {
    await dynamodb.update({
      TableName: process.env.EVENTS_TABLE,
      Key: { eventId },
      UpdateExpression: 'SET ticketTypes = :updatedTicketTypes, analytics.totalTicketsSold = analytics.totalTicketsSold + :quantity, analytics.lastUpdated = :timestamp',
      ExpressionAttributeValues: {
        ':updatedTicketTypes': await getUpdatedTicketTypes(eventId, ticketTypeId, quantity),
        ':quantity': quantity,
        ':timestamp': new Date().toISOString()
      }
    }).promise();
  } catch (error) {
    console.error('Error updating event ticket counts:', error);
  }
}

/**
 * Get updated ticket types with new quantities
 */
async function getUpdatedTicketTypes(eventId, ticketTypeId, quantity) {
  const event = await getEventDetails(eventId);
  if (!event) return [];

  return event.ticketTypes.map(tt => {
    if (tt.typeId === ticketTypeId) {
      return {
        ...tt,
        quantitySold: (tt.quantitySold || 0) + quantity
      };
    }
    return tt;
  });
}

/**
 * Send ticket email to attendee
 */
async function sendTicketEmail(tickets, event, attendeeEmail) {
  try {
    const ticketList = tickets.map(t => `
      <div style="border: 1px solid #ddd; padding: 20px; margin: 10px 0; border-radius: 8px;">
        <h3>${t.attendeeName}</h3>
        <p><strong>Event:</strong> ${event.name}</p>
        <p><strong>Date:</strong> ${event.eventDate} at ${event.startTime}</p>
        <p><strong>Location:</strong> ${event.location.address}, ${event.location.city}</p>
        <p><strong>Price:</strong> $${t.price.toFixed(2)}</p>
        <div style="text-align: center; margin: 20px 0;">
          <img src="${t.qrCodeUrl}" alt="QR Code" style="max-width: 200px;" />
        </div>
        <p style="font-size: 12px; color: #666;">
          Present this QR code at the event entrance for entry.
        </p>
      </div>
    `).join('');

    const emailHtml = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <title>Your SmartEntry Tickets</title>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background: #2c3e50; color: white; padding: 20px; text-align: center; border-radius: 8px 8px 0 0; }
          .content { background: #f9f9f9; padding: 20px; border-radius: 0 0 8px 8px; }
          .ticket { border: 1px solid #ddd; padding: 20px; margin: 10px 0; border-radius: 8px; background: white; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>🎫 Your SmartEntry Tickets</h1>
            <p>Thank you for your purchase!</p>
          </div>
          <div class="content">
            <h2>Event Details</h2>
            <p><strong>Event:</strong> ${event.name}</p>
            <p><strong>Date:</strong> ${event.eventDate} at ${event.startTime}</p>
            <p><strong>Location:</strong> ${event.location.address}, ${event.location.city}, ${event.location.state}</p>
            
            <h2>Your Tickets</h2>
            ${ticketList}
            
            <div style="margin-top: 30px; padding: 20px; background: #e8f4f8; border-radius: 8px;">
              <h3>Important Information</h3>
              <ul>
                <li>Please arrive 30 minutes before the event starts</li>
                <li>Present your QR code at the entrance</li>
                <li>Keep your tickets safe - they cannot be replaced</li>
                <li>Contact us if you have any questions</li>
              </ul>
            </div>
            
            <p style="text-align: center; margin-top: 30px; color: #666;">
              Powered by <strong>TicketSeam</strong> - Seamless ticketing for seamless events
            </p>
          </div>
        </div>
      </body>
      </html>
    `;

    await ses.sendEmail({
      Source: process.env.EMAIL_FROM,
      Destination: {
        ToAddresses: [attendeeEmail]
      },
      Message: {
        Subject: {
          Data: `Your tickets for ${event.name}`,
          Charset: 'UTF-8'
        },
        Body: {
          Html: {
            Data: emailHtml,
            Charset: 'UTF-8'
          }
        }
      }
    }).promise();

    console.log('Ticket email sent successfully to:', attendeeEmail);
  } catch (error) {
    console.error('Error sending ticket email:', error);
  }
}
