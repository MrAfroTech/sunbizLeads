/**
 * TicketSeam Process Payment Lambda Function
 * Handles payment processing for ticket purchases
 */

const AWS = require('aws-sdk');
const { v4: uuidv4 } = require('uuid');
const { createResponse, createErrorResponse } = require('../utils/responseHelper');

const dynamodb = new AWS.DynamoDB.DocumentClient();
const salesTable = process.env.SALES_TABLE;
const eventsTable = process.env.EVENTS_TABLE;

exports.handler = async (event) => {
  console.log('Process Payment Lambda triggered:', JSON.stringify(event, null, 2));

  try {
    // Parse request body
    const requestBody = JSON.parse(event.body);
    const {
      eventId,
      customerEmail,
      customerName,
      customerPhone,
      paymentMethod,
      paymentProvider,
      paymentProviderId,
      tickets,
      discounts = [],
      metadata = {}
    } = requestBody;

    // Validate required fields
    if (!eventId || !customerEmail || !customerName || !paymentMethod || !tickets || tickets.length === 0) {
      return createErrorResponse(400, 'Missing required fields');
    }

    // Get event details
    const event = await getEventDetails(eventId);
    if (!event) {
      return createErrorResponse(404, 'Event not found');
    }

    // Validate ticket availability and pricing
    const validationResult = await validateTickets(event, tickets);
    if (!validationResult.valid) {
      return createErrorResponse(400, validationResult.message);
    }

    // Calculate pricing
    const pricing = calculatePricing(validationResult.ticketTypes, event.pricing, discounts);
    
    // Generate purchase ID
    const purchaseId = `pur_${uuidv4().replace(/-/g, '')}`;
    const timestamp = new Date().toISOString();

    // Process payment (simulate for now - integrate with actual payment provider)
    const paymentResult = await processPayment({
      amount: pricing.total,
      currency: 'USD',
      paymentMethod,
      paymentProvider,
      paymentProviderId,
      customerEmail,
      customerName,
      metadata: {
        eventId,
        eventName: event.name,
        purchaseId,
        ...metadata
      }
    });

    if (!paymentResult.success) {
      return createErrorResponse(400, `Payment failed: ${paymentResult.message}`);
    }

    // Create sales record
    const salesDocument = {
      purchaseId,
      eventId,
      customerEmail,
      customerName,
      customerPhone: customerPhone || null,
      timestamp,
      paymentStatus: 'completed',
      paymentMethod,
      paymentProvider: paymentProvider || 'stripe',
      paymentProviderId: paymentResult.paymentId,
      tickets: validationResult.ticketTypes.map(tt => ({
        ticketId: null, // Will be set when tickets are generated
        typeId: tt.typeId,
        typeName: tt.name,
        quantity: tt.quantity,
        unitPrice: tt.price,
        totalPrice: tt.price * tt.quantity,
        attendeeEmail: tt.attendeeEmail,
        attendeeName: tt.attendeeName
      })),
      pricing: {
        subtotal: pricing.subtotal,
        platformFee: pricing.platformFee,
        processingFee: pricing.processingFee,
        flatFee: pricing.flatFee,
        tax: pricing.tax,
        discount: pricing.discount,
        total: pricing.total
      },
      discounts: discounts.map(d => ({
        code: d.code,
        type: d.type,
        value: d.value,
        description: d.description
      })),
      refund: {
        isRefundable: event.settings.allowRefunds,
        refundAmount: 0,
        refundReason: null,
        refundedAt: null,
        refundedBy: null,
        refundStatus: null
      },
      metadata: {
        ipAddress: metadata.ipAddress || 'unknown',
        userAgent: metadata.userAgent || 'unknown',
        referrer: metadata.referrer || null,
        utmSource: metadata.utmSource || null,
        utmMedium: metadata.utmMedium || null,
        utmCampaign: metadata.utmCampaign || null,
        deviceType: metadata.deviceType || 'unknown',
        browser: metadata.browser || 'unknown'
      },
      notifications: {
        confirmationSent: false,
        confirmationSentAt: null,
        reminderSent: false,
        reminderSentAt: null,
        lastNotificationSent: null
      },
      createdAt: timestamp,
      updatedAt: timestamp,
      expiresAt: new Date(event.eventDate + 'T' + event.endTime).toISOString()
    };

    // Save sales record
    await dynamodb.put({
      TableName: salesTable,
      Item: salesDocument
    }).promise();

    // Update event analytics
    await updateEventAnalytics(eventId, pricing.total, validationResult.totalTickets);

    console.log('Payment processed successfully:', purchaseId);

    return createResponse(201, {
      message: 'Payment processed successfully',
      purchaseId,
      paymentId: paymentResult.paymentId,
      totalAmount: pricing.total,
      tickets: validationResult.ticketTypes.map(tt => ({
        typeId: tt.typeId,
        typeName: tt.name,
        quantity: tt.quantity,
        totalPrice: tt.price * tt.quantity
      }))
    });

  } catch (error) {
    console.error('Error processing payment:', error);
    return createErrorResponse(500, 'Internal server error');
  }
};

/**
 * Get event details from DynamoDB
 */
async function getEventDetails(eventId) {
  try {
    const result = await dynamodb.get({
      TableName: eventsTable,
      Key: { eventId }
    }).promise();
    
    return result.Item;
  } catch (error) {
    console.error('Error getting event details:', error);
    return null;
  }
}

/**
 * Validate tickets and return pricing info
 */
async function validateTickets(event, requestedTickets) {
  const validatedTickets = [];
  let totalTickets = 0;

  for (const requestedTicket of requestedTickets) {
    const ticketType = event.ticketTypes.find(tt => tt.typeId === requestedTicket.typeId);
    
    if (!ticketType) {
      return { valid: false, message: `Ticket type ${requestedTicket.typeId} not found` };
    }

    if (!ticketType.isActive) {
      return { valid: false, message: `Ticket type ${ticketType.name} is not available` };
    }

    if (ticketType.quantitySold + requestedTicket.quantity > ticketType.quantityAvailable) {
      return { valid: false, message: `Insufficient ${ticketType.name} tickets available` };
    }

    if (requestedTicket.quantity > ticketType.maxPerPurchase) {
      return { valid: false, message: `Maximum ${ticketType.maxPerPurchase} ${ticketType.name} tickets per purchase` };
    }

    // Check early bird pricing
    let price = ticketType.price;
    if (ticketType.earlyBirdPrice && ticketType.earlyBirdEndDate) {
      const now = new Date();
      const earlyBirdEnd = new Date(ticketType.earlyBirdEndDate);
      if (now <= earlyBirdEnd) {
        price = ticketType.earlyBirdPrice;
      }
    }

    validatedTickets.push({
      typeId: ticketType.typeId,
      name: ticketType.name,
      price,
      quantity: requestedTicket.quantity,
      attendeeEmail: requestedTicket.attendeeEmail,
      attendeeName: requestedTicket.attendeeName
    });

    totalTickets += requestedTicket.quantity;
  }

  return {
    valid: true,
    ticketTypes: validatedTickets,
    totalTickets
  };
}

/**
 * Calculate pricing including fees and discounts
 */
function calculatePricing(ticketTypes, eventPricing, discounts) {
  let subtotal = 0;
  
  // Calculate subtotal
  ticketTypes.forEach(tt => {
    subtotal += tt.price * tt.quantity;
  });

  // Calculate fees
  const platformFee = subtotal * eventPricing.platformFee;
  const processingFee = subtotal * eventPricing.processingFee;
  const flatFee = eventPricing.flatFee;
  const tax = 0; // Could be calculated based on location
  const totalFees = platformFee + processingFee + flatFee + tax;

  // Apply discounts
  let discount = 0;
  discounts.forEach(d => {
    if (d.type === 'percentage') {
      discount += subtotal * (d.value / 100);
    } else if (d.type === 'fixed_amount') {
      discount += d.value;
    }
  });

  // Ensure discount doesn't exceed subtotal
  discount = Math.min(discount, subtotal);

  const total = subtotal + totalFees - discount;

  return {
    subtotal: Math.round(subtotal * 100) / 100,
    platformFee: Math.round(platformFee * 100) / 100,
    processingFee: Math.round(processingFee * 100) / 100,
    flatFee: flatFee,
    tax: tax,
    discount: Math.round(discount * 100) / 100,
    total: Math.round(total * 100) / 100
  };
}

/**
 * Process payment with external provider
 */
async function processPayment(paymentData) {
  // This is a simulation - integrate with actual payment provider
  // For now, we'll simulate a successful payment
  
  try {
    // Simulate payment processing delay
    await new Promise(resolve => setTimeout(resolve, 1000));

    // Simulate payment success (in real implementation, call Stripe, Square, etc.)
    const paymentId = `pi_${uuidv4().replace(/-/g, '')}`;
    
    return {
      success: true,
      paymentId,
      message: 'Payment processed successfully'
    };
  } catch (error) {
    console.error('Payment processing error:', error);
    return {
      success: false,
      message: 'Payment processing failed'
    };
  }
}

/**
 * Update event analytics
 */
async function updateEventAnalytics(eventId, revenue, ticketCount) {
  try {
    await dynamodb.update({
      TableName: eventsTable,
      Key: { eventId },
      UpdateExpression: 'SET analytics.totalRevenue = analytics.totalRevenue + :revenue, analytics.totalTicketsSold = analytics.totalTicketsSold + :tickets, analytics.lastUpdated = :timestamp',
      ExpressionAttributeValues: {
        ':revenue': revenue,
        ':tickets': ticketCount,
        ':timestamp': new Date().toISOString()
      }
    }).promise();
  } catch (error) {
    console.error('Error updating event analytics:', error);
  }
}
