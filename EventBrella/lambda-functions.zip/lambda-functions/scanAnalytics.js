/**
 * TicketSeam Scan Analytics Lambda Function
 * Tracks QR code scans and validation analytics
 */

const AWS = require('aws-sdk');
const { createResponse, createErrorResponse } = require('../utils/responseHelper');

const dynamodb = new AWS.DynamoDB.DocumentClient();
const validationsTable = process.env.VALIDATIONS_TABLE;
const eventsTable = process.env.EVENTS_TABLE;

exports.handler = async (event) => {
  console.log('Scan Analytics Lambda triggered:', JSON.stringify(event, null, 2));

  try {
    // Parse query parameters
    const queryParams = event.queryStringParameters || {};
    const {
      eventId,
      startDate,
      endDate,
      groupBy = 'hour'
    } = queryParams;

    if (!eventId) {
      return createErrorResponse(400, 'Event ID is required');
    }

    // Get scan data
    const scanData = await getScanData(eventId, startDate, endDate);
    
    // Generate analytics
    const analytics = generateScanAnalytics(scanData, groupBy);

    return createResponse(200, {
      eventId,
      period: {
        startDate: startDate || 'All time',
        endDate: endDate || 'Present'
      },
      analytics
    });

  } catch (error) {
    console.error('Error generating scan analytics:', error);
    return createErrorResponse(500, 'Internal server error');
  }
};

/**
 * Get scan data from validations table
 */
async function getScanData(eventId, startDate, endDate) {
  const params = {
    TableName: validationsTable,
    FilterExpression: 'eventId = :eventId',
    ExpressionAttributeValues: {
      ':eventId': eventId
    }
  };

  if (startDate) {
    params.FilterExpression += ' AND #timestamp >= :startDate';
    params.ExpressionAttributeNames = { '#timestamp': 'scanTimestamp' };
    params.ExpressionAttributeValues[':startDate'] = startDate;
  }

  if (endDate) {
    params.FilterExpression += ' AND #timestamp <= :endDate';
    if (!params.ExpressionAttributeNames) {
      params.ExpressionAttributeNames = { '#timestamp': 'scanTimestamp' };
    }
    params.ExpressionAttributeValues[':endDate'] = endDate;
  }

  const result = await dynamodb.scan(params).promise();
  return result.Items || [];
}

/**
 * Generate analytics from scan data
 */
function generateScanAnalytics(scanData, groupBy) {
  const totalScans = scanData.length;
  const validScans = scanData.filter(scan => scan.isValid).length;
  const invalidScans = totalScans - validScans;
  
  // Group by time period
  const groupedData = groupScansByTime(scanData, groupBy);
  
  // Calculate trends
  const trends = calculateTrends(groupedData);
  
  // Peak scan times
  const peakTimes = findPeakTimes(groupedData);
  
  return {
    summary: {
      totalScans,
      validScans,
      invalidScans,
      validityRate: totalScans > 0 ? (validScans / totalScans) * 100 : 0
    },
    trends,
    peakTimes,
    hourlyData: groupBy === 'hour' ? groupedData : null,
    dailyData: groupBy === 'day' ? groupedData : null
  };
}

/**
 * Group scans by time period
 */
function groupScansByTime(scanData, groupBy) {
  const groups = {};
  
  scanData.forEach(scan => {
    const scanTime = new Date(scan.scanTimestamp);
    let key;
    
    if (groupBy === 'hour') {
      key = scanTime.toISOString().substring(0, 13); // YYYY-MM-DDTHH
    } else if (groupBy === 'day') {
      key = scanTime.toISOString().substring(0, 10); // YYYY-MM-DD
    } else {
      key = scanTime.toISOString().substring(0, 7); // YYYY-MM
    }
    
    if (!groups[key]) {
      groups[key] = {
        timestamp: key,
        totalScans: 0,
        validScans: 0,
        invalidScans: 0
      };
    }
    
    groups[key].totalScans++;
    if (scan.isValid) {
      groups[key].validScans++;
    } else {
      groups[key].invalidScans++;
    }
  });
  
  return Object.values(groups).sort((a, b) => a.timestamp.localeCompare(b.timestamp));
}

/**
 * Calculate trends from grouped data
 */
function calculateTrends(groupedData) {
  if (groupedData.length < 2) {
    return {
      scanTrend: 0,
      validityTrend: 0
    };
  }
  
  const firstPeriod = groupedData[0];
  const lastPeriod = groupedData[groupedData.length - 1];
  
  const scanTrend = firstPeriod.totalScans > 0 ? 
    ((lastPeriod.totalScans - firstPeriod.totalScans) / firstPeriod.totalScans) * 100 : 0;
  
  const firstValidityRate = firstPeriod.totalScans > 0 ? 
    (firstPeriod.validScans / firstPeriod.totalScans) * 100 : 0;
  const lastValidityRate = lastPeriod.totalScans > 0 ? 
    (lastPeriod.validScans / lastPeriod.totalScans) * 100 : 0;
  
  const validityTrend = lastValidityRate - firstValidityRate;
  
  return {
    scanTrend: Math.round(scanTrend * 100) / 100,
    validityTrend: Math.round(validityTrend * 100) / 100
  };
}

/**
 * Find peak scan times
 */
function findPeakTimes(groupedData) {
  if (groupedData.length === 0) return [];
  
  const sortedData = [...groupedData].sort((a, b) => b.totalScans - a.totalScans);
  
  return sortedData.slice(0, 3).map(period => ({
    timestamp: period.timestamp,
    totalScans: period.totalScans,
    validityRate: period.totalScans > 0 ? 
      Math.round((period.validScans / period.totalScans) * 100) : 0
  }));
}
