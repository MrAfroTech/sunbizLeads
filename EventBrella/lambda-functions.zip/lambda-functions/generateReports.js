/**
 * TicketSeam Generate Reports Lambda Function
 * Generates analytics reports for events
 */

const AWS = require('aws-sdk');
const { createResponse, createErrorResponse } = require('../utils/responseHelper');

const dynamodb = new AWS.DynamoDB.DocumentClient();
const eventsTable = process.env.EVENTS_TABLE;
const salesTable = process.env.SALES_TABLE;

exports.handler = async (event) => {
  console.log('Generate Reports Lambda triggered:', JSON.stringify(event, null, 2));

  try {
    // Parse query parameters
    const queryParams = event.queryStringParameters || {};
    const {
      eventId,
      startDate,
      endDate,
      reportType = 'summary'
    } = queryParams;

    let reportData;

    switch (reportType) {
      case 'summary':
        reportData = await generateSummaryReport(eventId, startDate, endDate);
        break;
      case 'sales':
        reportData = await generateSalesReport(eventId, startDate, endDate);
        break;
      case 'tickets':
        reportData = await generateTicketReport(eventId, startDate, endDate);
        break;
      default:
        return createErrorResponse(400, 'Invalid report type');
    }

    return createResponse(200, {
      reportType,
      generatedAt: new Date().toISOString(),
      data: reportData
    });

  } catch (error) {
    console.error('Error generating report:', error);
    return createErrorResponse(500, 'Internal server error');
  }
};

/**
 * Generate summary report for an event
 */
async function generateSummaryReport(eventId, startDate, endDate) {
  // Get event details
  const eventParams = {
    TableName: eventsTable,
    Key: {
      eventId: eventId
    }
  };

  const eventResult = await dynamodb.get(eventParams).promise();
  
  if (!eventResult.Item) {
    throw new Error('Event not found');
  }

  const event = eventResult.Item;
  const analytics = event.analytics || {};

  // Get sales data
  const salesParams = {
    TableName: salesTable,
    FilterExpression: 'eventId = :eventId',
    ExpressionAttributeValues: {
      ':eventId': eventId
    }
  };

  if (startDate) {
    salesParams.FilterExpression += ' AND #timestamp >= :startDate';
    salesParams.ExpressionAttributeNames = { '#timestamp': 'timestamp' };
    salesParams.ExpressionAttributeValues[':startDate'] = startDate;
  }

  if (endDate) {
    salesParams.FilterExpression += ' AND #timestamp <= :endDate';
    if (!salesParams.ExpressionAttributeNames) {
      salesParams.ExpressionAttributeNames = { '#timestamp': 'timestamp' };
    }
    salesParams.ExpressionAttributeValues[':endDate'] = endDate;
  }

  const salesResult = await dynamodb.scan(salesParams).promise();
  const sales = salesResult.Items || [];

  // Calculate metrics
  const totalRevenue = sales.reduce((sum, sale) => sum + (sale.totalAmount || 0), 0);
  const totalTicketsSold = sales.reduce((sum, sale) => sum + (sale.ticketData?.length || 0), 0);
  const averageOrderValue = sales.length > 0 ? totalRevenue / sales.length : 0;

  return {
    event: {
      eventId: event.eventId,
      name: event.name,
      eventDate: event.eventDate,
      capacity: event.capacity
    },
    metrics: {
      totalRevenue,
      totalTicketsSold,
      totalOrders: sales.length,
      averageOrderValue,
      conversionRate: analytics.conversionRate || 0,
      ticketsRemaining: event.capacity - totalTicketsSold
    },
    period: {
      startDate: startDate || 'All time',
      endDate: endDate || 'Present'
    }
  };
}

/**
 * Generate detailed sales report
 */
async function generateSalesReport(eventId, startDate, endDate) {
  const salesParams = {
    TableName: salesTable,
    FilterExpression: 'eventId = :eventId',
    ExpressionAttributeValues: {
      ':eventId': eventId
    }
  };

  if (startDate) {
    salesParams.FilterExpression += ' AND #timestamp >= :startDate';
    salesParams.ExpressionAttributeNames = { '#timestamp': 'timestamp' };
    salesParams.ExpressionAttributeValues[':startDate'] = startDate;
  }

  if (endDate) {
    salesParams.FilterExpression += ' AND #timestamp <= :endDate';
    if (!salesParams.ExpressionAttributeNames) {
      salesParams.ExpressionAttributeNames = { '#timestamp': 'timestamp' };
    }
    salesParams.ExpressionAttributeValues[':endDate'] = endDate;
  }

  const result = await dynamodb.scan(salesParams).promise();
  
  return {
    sales: result.Items || [],
    totalCount: result.Items?.length || 0
  };
}

/**
 * Generate ticket-specific report
 */
async function generateTicketReport(eventId, startDate, endDate) {
  // This would typically involve more complex queries
  // For now, return basic ticket information
  const eventParams = {
    TableName: eventsTable,
    Key: {
      eventId: eventId
    }
  };

  const eventResult = await dynamodb.get(eventParams).promise();
  
  if (!eventResult.Item) {
    throw new Error('Event not found');
  }

  const event = eventResult.Item;

  return {
    event: {
      eventId: event.eventId,
      name: event.name,
      ticketTypes: event.ticketTypes || []
    },
    analytics: event.analytics || {}
  };
}
