/**
 * TicketSeam Validate Ticket Lambda Function
 * Validates tickets at event entry points
 */

const AWS = require('aws-sdk');
const crypto = require('crypto');
const { createResponse, createErrorResponse } = require('../utils/responseHelper');

const dynamodb = new AWS.DynamoDB.DocumentClient();
const ticketsTable = process.env.TICKETS_TABLE;
const validationsTable = process.env.VALIDATIONS_TABLE;

exports.handler = async (event) => {
  console.log('Validate Ticket Lambda triggered:', JSON.stringify(event, null, 2));

  try {
    // Parse request body
    const requestBody = JSON.parse(event.body);
    const {
      qrCodeData,
      staffId,
      staffName,
      validationLocation,
      validationMethod = 'qr_scan',
      deviceInfo,
      securityInfo
    } = requestBody;

    // Validate required fields
    if (!qrCodeData || !staffId || !staffName || !validationLocation) {
      return createErrorResponse(400, 'Missing required fields');
    }

    const timestamp = new Date().toISOString();
    const ticketId = qrCodeData.ticketId;

    // Get ticket details
    const ticket = await getTicketDetails(ticketId);
    if (!ticket) {
      return createErrorResponse(404, 'Ticket not found');
    }

    // Validate ticket status
    if (ticket.status !== 'active') {
      return createValidationResponse(ticket, 'invalid', 'Ticket is not active', timestamp);
    }

    // Check if ticket is expired
    const now = new Date();
    const expiresAt = new Date(ticket.expiresAt);
    if (now > expiresAt) {
      return createValidationResponse(ticket, 'expired', 'Ticket has expired', timestamp);
    }

    // Check for duplicate validation
    const existingValidation = await checkExistingValidation(ticketId);
    if (existingValidation) {
      return createValidationResponse(ticket, 'already_used', 'Ticket already used', timestamp, existingValidation);
    }

    // Validate QR code checksum
    const expectedChecksum = generateChecksum(ticketId, qrCodeData.eventId, qrCodeData.attendeeEmail);
    if (qrCodeData.checksum !== expectedChecksum) {
      return createValidationResponse(ticket, 'invalid', 'Invalid QR code checksum', timestamp);
    }

    // Create validation record
    const validationDocument = {
      ticketId,
      scanTimestamp: timestamp,
      eventId: ticket.eventId,
      validationStatus: 'valid',
      staffId,
      staffName,
      validationLocation,
      validationMethod,
      deviceInfo: deviceInfo || {},
      attendeeInfo: {
        email: ticket.attendeeEmail,
        name: ticket.attendeeName,
        ticketType: await getTicketTypeName(ticket.eventId, ticket.typeId),
        seatNumber: ticket.metadata?.seatNumber || null,
        specialInstructions: ticket.metadata?.specialInstructions || ''
      },
      validationData: {
        qrCodeData,
        checksum: qrCodeData.checksum,
        isValidChecksum: true,
        isExpired: false,
        isDuplicate: false,
        previousValidation: null
      },
      security: {
        ipAddress: securityInfo?.ipAddress || 'unknown',
        location: securityInfo?.location || null,
        networkInfo: securityInfo?.networkInfo || 'unknown',
        securityFlags: []
      },
      notes: '',
      flags: {
        isSuspicious: false,
        requiresReview: false,
        isTransfer: false,
        isRefund: false,
        isVip: ticket.metadata?.section?.toLowerCase().includes('vip') || false,
        hasSpecialAccess: !!ticket.metadata?.accessibilityNeeds
      },
      analytics: {
        waitTime: 0, // Could be calculated from queue data
        processingTime: 0, // Could be calculated from scan start time
        entryPoint: validationLocation,
        timeOfDay: getTimeOfDay(timestamp),
        dayOfWeek: getDayOfWeek(timestamp)
      },
      createdAt: timestamp,
      updatedAt: timestamp
    };

    // Save validation record
    await dynamodb.put({
      TableName: validationsTable,
      Item: validationDocument
    }).promise();

    // Update ticket status
    await updateTicketStatus(ticketId, 'used', timestamp);

    console.log('Ticket validated successfully:', ticketId);

    return createResponse(200, {
      message: 'Ticket validated successfully',
      validation: {
        ticketId,
        status: 'valid',
        attendeeName: ticket.attendeeName,
        attendeeEmail: ticket.attendeeEmail,
        ticketType: validationDocument.attendeeInfo.ticketType,
        validatedAt: timestamp,
        validatedBy: staffName,
        validationLocation
      }
    });

  } catch (error) {
    console.error('Error validating ticket:', error);
    return createErrorResponse(500, 'Internal server error');
  }
};

/**
 * Get ticket details from DynamoDB
 */
async function getTicketDetails(ticketId) {
  try {
    const result = await dynamodb.get({
      TableName: ticketsTable,
      Key: { ticketId }
    }).promise();
    
    return result.Item;
  } catch (error) {
    console.error('Error getting ticket details:', error);
    return null;
  }
}

/**
 * Check for existing validation
 */
async function checkExistingValidation(ticketId) {
  try {
    const result = await dynamodb.query({
      TableName: validationsTable,
      KeyConditionExpression: 'ticketId = :ticketId',
      ExpressionAttributeValues: {
        ':ticketId': ticketId
      },
      ScanIndexForward: false, // Get most recent first
      Limit: 1
    }).promise();

    return result.Items.length > 0 ? result.Items[0] : null;
  } catch (error) {
    console.error('Error checking existing validation:', error);
    return null;
  }
}

/**
 * Generate checksum for validation
 */
function generateChecksum(ticketId, eventId, attendeeEmail) {
  const data = `${ticketId}-${eventId}-${attendeeEmail}`;
  return crypto.createHash('sha256').update(data).digest('hex').substring(0, 20);
}

/**
 * Get ticket type name
 */
async function getTicketTypeName(eventId, typeId) {
  try {
    const result = await dynamodb.get({
      TableName: process.env.EVENTS_TABLE,
      Key: { eventId }
    }).promise();

    if (result.Item && result.Item.ticketTypes) {
      const ticketType = result.Item.ticketTypes.find(tt => tt.typeId === typeId);
      return ticketType ? ticketType.name : 'Unknown';
    }
    
    return 'Unknown';
  } catch (error) {
    console.error('Error getting ticket type name:', error);
    return 'Unknown';
  }
}

/**
 * Create validation response
 */
function createValidationResponse(ticket, status, message, timestamp, existingValidation = null) {
  const response = {
    message,
    validation: {
      ticketId: ticket.ticketId,
      status,
      attendeeName: ticket.attendeeName,
      attendeeEmail: ticket.attendeeEmail,
      validatedAt: timestamp,
      reason: message
    }
  };

  if (existingValidation) {
    response.validation.previousValidation = {
      validatedAt: existingValidation.scanTimestamp,
      validatedBy: existingValidation.staffName,
      validationLocation: existingValidation.validationLocation
    };
  }

  return createResponse(200, response);
}

/**
 * Update ticket status
 */
async function updateTicketStatus(ticketId, status, timestamp) {
  try {
    await dynamodb.update({
      TableName: ticketsTable,
      Key: { ticketId },
      UpdateExpression: 'SET #status = :status, updatedAt = :timestamp',
      ExpressionAttributeNames: {
        '#status': 'status'
      },
      ExpressionAttributeValues: {
        ':status': status,
        ':timestamp': timestamp
      }
    }).promise();
  } catch (error) {
    console.error('Error updating ticket status:', error);
  }
}

/**
 * Get time of day category
 */
function getTimeOfDay(timestamp) {
  const hour = new Date(timestamp).getHours();
  if (hour < 6) return 'late_night';
  if (hour < 12) return 'morning';
  if (hour < 17) return 'afternoon';
  if (hour < 21) return 'evening';
  return 'night';
}

/**
 * Get day of week
 */
function getDayOfWeek(timestamp) {
  const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  return days[new Date(timestamp).getDay()];
}
