/**
 * TicketSeam Track Sales Lambda Function
 * Tracks sales analytics and metrics
 */

const AWS = require('aws-sdk');
const { createResponse, createErrorResponse } = require('../utils/responseHelper');

const dynamodb = new AWS.DynamoDB.DocumentClient();
const salesTable = process.env.SALES_TABLE;
const eventsTable = process.env.EVENTS_TABLE;

exports.handler = async (event) => {
  console.log('Track Sales Lambda triggered:', JSON.stringify(event, null, 2));

  try {
    // Parse request body
    const requestBody = JSON.parse(event.body);
    const {
      eventId,
      orderId,
      customerEmail,
      ticketData,
      totalAmount,
      paymentMethod,
      timestamp = new Date().toISOString()
    } = requestBody;

    // Validate required fields
    if (!eventId || !orderId || !customerEmail || !totalAmount) {
      return createErrorResponse(400, 'Missing required fields');
    }

    // Create sales record
    const salesRecord = {
      purchaseId: orderId,
      eventId,
      customerEmail,
      ticketData,
      totalAmount: parseFloat(totalAmount),
      paymentMethod: paymentMethod || 'unknown',
      timestamp,
      status: 'completed',
      createdAt: timestamp
    };

    // Save sales record to DynamoDB
    const putParams = {
      TableName: salesTable,
      Item: salesRecord
    };

    await dynamodb.put(putParams).promise();

    // Update event analytics
    await updateEventAnalytics(eventId, totalAmount, ticketData);

    console.log(`Sales tracked for order: ${orderId}`);

    return createResponse(200, {
      message: 'Sales tracked successfully',
      orderId
    });

  } catch (error) {
    console.error('Error tracking sales:', error);
    return createErrorResponse(500, 'Internal server error');
  }
};

/**
 * Update event analytics with new sale
 */
async function updateEventAnalytics(eventId, totalAmount, ticketData) {
  try {
    // Get current event data
    const getParams = {
      TableName: eventsTable,
      Key: {
        eventId: eventId
      }
    };

    const result = await dynamodb.get(getParams).promise();
    
    if (!result.Item) {
      console.error(`Event not found: ${eventId}`);
      return;
    }

    const event = result.Item;
    const analytics = event.analytics || {};
    
    // Calculate new analytics
    const newTotalRevenue = (analytics.totalRevenue || 0) + parseFloat(totalAmount);
    const newTotalTicketsSold = (analytics.totalTicketsSold || 0) + ticketData.length;
    const newAverageOrderValue = newTotalRevenue / Math.max(1, analytics.totalOrders || 0);
    const newConversionRate = analytics.conversionRate || 0; // Would need more data to calculate properly

    // Update event with new analytics
    const updateParams = {
      TableName: eventsTable,
      Key: {
        eventId: eventId
      },
      UpdateExpression: 'SET analytics = :analytics, updatedAt = :updatedAt',
      ExpressionAttributeValues: {
        ':analytics': {
          totalRevenue: newTotalRevenue,
          totalTicketsSold: newTotalTicketsSold,
          averageOrderValue: newAverageOrderValue,
          conversionRate: newConversionRate,
          totalOrders: (analytics.totalOrders || 0) + 1,
          lastUpdated: new Date().toISOString()
        },
        ':updatedAt': new Date().toISOString()
      }
    };

    await dynamodb.update(updateParams).promise();
    console.log(`Event analytics updated for: ${eventId}`);

  } catch (error) {
    console.error('Error updating event analytics:', error);
  }
}
