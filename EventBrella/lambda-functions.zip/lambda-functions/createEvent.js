/**
 * TicketSeam Create Event Lambda Function
 * Creates a new event with ticket types and configuration
 */

const AWS = require('aws-sdk');
const { v4: uuidv4 } = require('uuid');
const { createResponse, createErrorResponse } = require('../utils/responseHelper');

const dynamodb = new AWS.DynamoDB.DocumentClient();
const eventsTable = process.env.EVENTS_TABLE;

exports.handler = async (event) => {
  console.log('Create Event Lambda triggered:', JSON.stringify(event, null, 2));

  try {
    // Parse request body
    const requestBody = JSON.parse(event.body);
    const {
      organizerId,
      venueId,
      name,
      description,
      eventDate,
      startTime,
      endTime,
      timezone,
      location,
      capacity,
      ticketTypes,
      images,
      settings,
      pricing
    } = requestBody;

    // Validate required fields
    if (!organizerId || !name || !eventDate || !startTime || !endTime || !location) {
      return createErrorResponse(400, 'Missing required fields');
    }

    // Generate event ID
    const eventId = `evt_${uuidv4().replace(/-/g, '')}`;
    const timestamp = new Date().toISOString();

    // Prepare event document
    const eventDocument = {
      eventId,
      organizerId,
      venueId: venueId || null,
      name,
      description: description || '',
      eventDate,
      startTime,
      endTime,
      timezone: timezone || 'America/New_York',
      location: {
        address: location.address || '',
        city: location.city || '',
        state: location.state || '',
        zipCode: location.zipCode || '',
        country: location.country || 'USA',
        coordinates: location.coordinates || null
      },
      capacity: capacity || 1000,
      status: 'draft',
      ticketTypes: ticketTypes || [],
      images: images || [],
      settings: {
        allowRefunds: settings?.allowRefunds ?? true,
        refundCutoffDate: settings?.refundCutoffDate || null,
        requireApproval: settings?.requireApproval ?? false,
        allowWaitlist: settings?.allowWaitlist ?? true,
        sendReminders: settings?.sendReminders ?? true,
        reminderDays: settings?.reminderDays || 7
      },
      pricing: {
        platformFee: pricing?.platformFee || 0.05,
        processingFee: pricing?.processingFee || 0.029,
        flatFee: pricing?.flatFee || 0.30
      },
      analytics: {
        totalRevenue: 0,
        totalTicketsSold: 0,
        conversionRate: 0,
        averageOrderValue: 0,
        lastUpdated: timestamp
      },
      createdAt: timestamp,
      updatedAt: timestamp,
      publishedAt: null,
      createdBy: organizerId,
      lastModifiedBy: organizerId
    };

    // Save event to DynamoDB
    const putParams = {
      TableName: eventsTable,
      Item: eventDocument,
      ConditionExpression: 'attribute_not_exists(eventId)' // Prevent overwrites
    };

    await dynamodb.put(putParams).promise();

    console.log('Event created successfully:', eventId);

    // Return success response
    return createResponse(201, {
      message: 'Event created successfully',
      eventId,
      event: {
        eventId,
        name,
        status: 'draft',
        eventDate,
        capacity,
        ticketTypes: ticketTypes?.length || 0
      }
    });

  } catch (error) {
    console.error('Error creating event:', error);

    if (error.code === 'ConditionalCheckFailedException') {
      return createErrorResponse(409, 'Event with this ID already exists');
    }

    return createErrorResponse(500, 'Internal server error');
  }
};

/**
 * Validate event data
 */
function validateEventData(eventData) {
  const errors = [];

  // Required field validation
  if (!eventData.organizerId) errors.push('Organizer ID is required');
  if (!eventData.name) errors.push('Event name is required');
  if (!eventData.eventDate) errors.push('Event date is required');
  if (!eventData.startTime) errors.push('Start time is required');
  if (!eventData.endTime) errors.push('End time is required');

  // Date validation
  if (eventData.eventDate) {
    const eventDate = new Date(eventData.eventDate);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    if (eventDate < today) {
      errors.push('Event date cannot be in the past');
    }
  }

  // Time validation
  if (eventData.startTime && eventData.endTime) {
    const startTime = new Date(`2000-01-01T${eventData.startTime}`);
    const endTime = new Date(`2000-01-01T${eventData.endTime}`);
    
    if (startTime >= endTime) {
      errors.push('End time must be after start time');
    }
  }

  // Capacity validation
  if (eventData.capacity && eventData.capacity < 1) {
    errors.push('Capacity must be at least 1');
  }

  // Ticket types validation
  if (eventData.ticketTypes && eventData.ticketTypes.length > 0) {
    eventData.ticketTypes.forEach((ticketType, index) => {
      if (!ticketType.name) {
        errors.push(`Ticket type ${index + 1} name is required`);
      }
      if (!ticketType.price || ticketType.price < 0) {
        errors.push(`Ticket type ${index + 1} price must be non-negative`);
      }
      if (ticketType.quantityAvailable && ticketType.quantityAvailable < 0) {
        errors.push(`Ticket type ${index + 1} quantity must be non-negative`);
      }
    });
  }

  return errors;
}
