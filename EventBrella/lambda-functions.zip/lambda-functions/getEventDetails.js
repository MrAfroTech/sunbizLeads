/**
 * TicketSeam Get Event Details Lambda Function
 * Gets detailed information about a specific event
 */

const AWS = require('aws-sdk');
const { createResponse, createErrorResponse } = require('../utils/responseHelper');

const dynamodb = new AWS.DynamoDB.DocumentClient();
const eventsTable = process.env.EVENTS_TABLE;

exports.handler = async (event) => {
  console.log('Get Event Details Lambda triggered:', JSON.stringify(event, null, 2));

  try {
    // Extract event ID from path parameters
    const eventId = event.pathParameters?.eventId;

    if (!eventId) {
      return createErrorResponse(400, 'Event ID is required');
    }

    // Get event from DynamoDB
    const getParams = {
      TableName: eventsTable,
      Key: {
        eventId: eventId
      }
    };

    const result = await dynamodb.get(getParams).promise();

    if (!result.Item) {
      return createErrorResponse(404, 'Event not found');
    }

    const event = result.Item;

    // Check if event is published (for public access)
    if (event.status !== 'published') {
      return createErrorResponse(403, 'Event is not available for public viewing');
    }

    // Format event for public consumption
    const eventDetails = {
      eventId: event.eventId,
      name: event.name,
      description: event.description,
      eventDate: event.eventDate,
      startTime: event.startTime,
      endTime: event.endTime,
      timezone: event.timezone,
      location: event.location,
      capacity: event.capacity,
      ticketTypes: event.ticketTypes?.map(ticketType => ({
        name: ticketType.name,
        price: ticketType.price,
        quantityAvailable: ticketType.quantityAvailable,
        description: ticketType.description,
        salesStartDate: ticketType.salesStartDate,
        salesEndDate: ticketType.salesEndDate
      })) || [],
      images: event.images || [],
      status: event.status,
      settings: {
        allowRefunds: event.settings?.allowRefunds,
        refundCutoffDate: event.settings?.refundCutoffDate,
        allowWaitlist: event.settings?.allowWaitlist
      },
      pricing: {
        platformFee: event.pricing?.platformFee,
        processingFee: event.pricing?.processingFee,
        flatFee: event.pricing?.flatFee
      },
      analytics: {
        totalTicketsSold: event.analytics?.totalTicketsSold || 0,
        totalRevenue: event.analytics?.totalRevenue || 0,
        conversionRate: event.analytics?.conversionRate || 0,
        averageOrderValue: event.analytics?.averageOrderValue || 0
      },
      createdAt: event.createdAt,
      publishedAt: event.publishedAt
    };

    console.log(`Retrieved event details for: ${eventId}`);

    return createResponse(200, {
      event: eventDetails
    });

  } catch (error) {
    console.error('Error getting event details:', error);
    return createErrorResponse(500, 'Internal server error');
  }
};
