/**
 * TicketSeam Send Ticket Email Lambda Function
 * Sends ticket confirmation emails to customers
 */

const AWS = require('aws-sdk');
const { createResponse, createErrorResponse } = require('../utils/responseHelper');

const ses = new AWS.SES({ region: 'us-east-1' });

exports.handler = async (event) => {
  console.log('Send Ticket Email Lambda triggered:', JSON.stringify(event, null, 2));

  try {
    // Parse SQS message
    const records = event.Records || [];
    
    for (const record of records) {
      const messageBody = JSON.parse(record.body);
      const { customerEmail, ticketData, eventData } = messageBody;

      if (!customerEmail || !ticketData || !eventData) {
        console.error('Missing required data for email:', messageBody);
        continue;
      }

      // Prepare email content
      const emailContent = generateTicketEmail(ticketData, eventData);

      // Send email via SES
      const emailParams = {
        Source: process.env.EMAIL_FROM || 'noreply@ticketseam.com',
        Destination: {
          ToAddresses: [customerEmail]
        },
        Message: {
          Subject: {
            Data: `Your tickets for ${eventData.name}`,
            Charset: 'UTF-8'
          },
          Body: {
            Html: {
              Data: emailContent,
              Charset: 'UTF-8'
            }
          }
        }
      };

      await ses.sendEmail(emailParams).promise();
      console.log(`Ticket email sent to: ${customerEmail}`);
    }

    return createResponse(200, {
      message: 'Emails processed successfully',
      processedCount: records.length
    });

  } catch (error) {
    console.error('Error sending ticket emails:', error);
    return createErrorResponse(500, 'Internal server error');
  }
};

/**
 * Generate HTML email content for ticket confirmation
 */
function generateTicketEmail(ticketData, eventData) {
  return `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="UTF-8">
      <title>Your TicketSeam Tickets</title>
      <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { background: #2c3e50; color: white; padding: 20px; text-align: center; }
        .content { padding: 20px; background: #f9f9f9; }
        .ticket { border: 2px dashed #3498db; padding: 15px; margin: 10px 0; background: white; }
        .qr-code { text-align: center; margin: 10px 0; }
        .footer { text-align: center; padding: 20px; font-size: 12px; color: #666; }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>🎫 Your TicketSeam Tickets</h1>
        </div>
        <div class="content">
          <h2>Event: ${eventData.name}</h2>
          <p><strong>Date:</strong> ${eventData.eventDate}</p>
          <p><strong>Time:</strong> ${eventData.startTime} - ${eventData.endTime}</p>
          <p><strong>Location:</strong> ${eventData.location?.address || 'TBD'}</p>
          
          <h3>Your Tickets:</h3>
          ${ticketData.tickets.map(ticket => `
            <div class="ticket">
              <h4>${ticket.ticketTypeName}</h4>
              <p><strong>Ticket ID:</strong> ${ticket.ticketId}</p>
              <p><strong>Price:</strong> $${ticket.price}</p>
              <div class="qr-code">
                <img src="${ticket.qrCodeUrl}" alt="QR Code" width="150" height="150">
              </div>
            </div>
          `).join('')}
          
          <p><strong>Total Paid:</strong> $${ticketData.totalAmount}</p>
          <p><strong>Order ID:</strong> ${ticketData.orderId}</p>
        </div>
        <div class="footer">
          <p>Thank you for using TicketSeam!</p>
          <p>Questions? Contact us at support@ticketseam.com</p>
        </div>
      </div>
    </body>
    </html>
  `;
}
