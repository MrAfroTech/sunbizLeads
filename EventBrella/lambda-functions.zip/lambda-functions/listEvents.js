/**
 * TicketSeam List Events Lambda Function
 * Lists all public events for customer browsing
 */

const AWS = require('aws-sdk');
const { createResponse, createErrorResponse } = require('../utils/responseHelper');

const dynamodb = new AWS.DynamoDB.DocumentClient();
const eventsTable = process.env.EVENTS_TABLE;

exports.handler = async (event) => {
  console.log('List Events Lambda triggered:', JSON.stringify(event, null, 2));

  try {
    // Parse query parameters
    const queryParams = event.queryStringParameters || {};
    const {
      limit = 20,
      offset = 0,
      category,
      location,
      dateFrom,
      dateTo,
      status = 'published'
    } = queryParams;

    // Build scan parameters
    const scanParams = {
      TableName: eventsTable,
      FilterExpression: '#status = :status',
      ExpressionAttributeNames: {
        '#status': 'status'
      },
      ExpressionAttributeValues: {
        ':status': status
      },
      Limit: parseInt(limit),
      ExclusiveStartKey: offset ? JSON.parse(Buffer.from(offset, 'base64').toString()) : undefined
    };

    // Add additional filters
    if (category) {
      scanParams.FilterExpression += ' AND contains(categories, :category)';
      scanParams.ExpressionAttributeValues[':category'] = category;
    }

    if (location) {
      scanParams.FilterExpression += ' AND contains(location.city, :location)';
      scanParams.ExpressionAttributeValues[':location'] = location;
    }

    if (dateFrom) {
      scanParams.FilterExpression += ' AND eventDate >= :dateFrom';
      scanParams.ExpressionAttributeValues[':dateFrom'] = dateFrom;
    }

    if (dateTo) {
      scanParams.FilterExpression += ' AND eventDate <= :dateTo';
      scanParams.ExpressionAttributeValues[':dateTo'] = dateTo;
    }

    // Scan events from DynamoDB
    const result = await dynamodb.scan(scanParams).promise();

    // Format events for public consumption
    const events = result.Items.map(event => ({
      eventId: event.eventId,
      name: event.name,
      description: event.description,
      eventDate: event.eventDate,
      startTime: event.startTime,
      endTime: event.endTime,
      timezone: event.timezone,
      location: event.location,
      capacity: event.capacity,
      ticketTypes: event.ticketTypes?.map(ticketType => ({
        name: ticketType.name,
        price: ticketType.price,
        quantityAvailable: ticketType.quantityAvailable,
        description: ticketType.description
      })) || [],
      images: event.images || [],
      status: event.status,
      analytics: {
        totalTicketsSold: event.analytics?.totalTicketsSold || 0,
        totalRevenue: event.analytics?.totalRevenue || 0
      },
      createdAt: event.createdAt,
      publishedAt: event.publishedAt
    }));

    // Prepare pagination info
    const pagination = {
      limit: parseInt(limit),
      offset: offset || 0,
      hasMore: !!result.LastEvaluatedKey,
      nextOffset: result.LastEvaluatedKey ? 
        Buffer.from(JSON.stringify(result.LastEvaluatedKey)).toString('base64') : null
    };

    console.log(`Found ${events.length} events`);

    return createResponse(200, {
      events,
      pagination,
      total: events.length
    });

  } catch (error) {
    console.error('Error listing events:', error);
    return createErrorResponse(500, 'Internal server error');
  }
};
