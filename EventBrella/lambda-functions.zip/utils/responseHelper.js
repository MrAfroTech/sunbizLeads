/**
 * TicketSeam Response Helper Utilities
 * Standardized response formatting for Lambda functions
 */

/**
 * Create a successful response
 */
function createResponse(statusCode, body, headers = {}) {
  return {
    statusCode,
    headers: {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
      'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
      ...headers
    },
    body: JSON.stringify(body)
  };
}

/**
 * Create an error response
 */
function createErrorResponse(statusCode, message, details = null) {
  const errorBody = {
    error: true,
    message,
    timestamp: new Date().toISOString()
  };

  if (details) {
    errorBody.details = details;
  }

  return createResponse(statusCode, errorBody);
}

/**
 * Create a validation error response
 */
function createValidationErrorResponse(errors) {
  return createErrorResponse(400, 'Validation failed', {
    validationErrors: errors
  });
}

/**
 * Create a not found response
 */
function createNotFoundResponse(resource) {
  return createErrorResponse(404, `${resource} not found`);
}

/**
 * Create an unauthorized response
 */
function createUnauthorizedResponse(message = 'Unauthorized') {
  return createErrorResponse(401, message);
}

/**
 * Create a forbidden response
 */
function createForbiddenResponse(message = 'Forbidden') {
  return createErrorResponse(403, message);
}

/**
 * Create a rate limit response
 */
function createRateLimitResponse(message = 'Rate limit exceeded') {
  return createErrorResponse(429, message);
}

/**
 * Create a server error response
 */
function createServerErrorResponse(message = 'Internal server error') {
  return createErrorResponse(500, message);
}

/**
 * Create a maintenance response
 */
function createMaintenanceResponse(message = 'Service temporarily unavailable') {
  return createErrorResponse(503, message);
}

/**
 * Validate request body against schema
 */
function validateRequestBody(body, schema) {
  const errors = [];

  for (const [field, rules] of Object.entries(schema)) {
    const value = body[field];

    // Required field validation
    if (rules.required && (value === undefined || value === null || value === '')) {
      errors.push(`${field} is required`);
      continue;
    }

    // Skip validation if field is not required and not present
    if (!rules.required && (value === undefined || value === null)) {
      continue;
    }

    // Type validation
    if (rules.type && typeof value !== rules.type) {
      errors.push(`${field} must be of type ${rules.type}`);
      continue;
    }

    // String length validation
    if (rules.type === 'string' && rules.minLength && value.length < rules.minLength) {
      errors.push(`${field} must be at least ${rules.minLength} characters long`);
    }

    if (rules.type === 'string' && rules.maxLength && value.length > rules.maxLength) {
      errors.push(`${field} must be no more than ${rules.maxLength} characters long`);
    }

    // Number validation
    if (rules.type === 'number' && rules.min !== undefined && value < rules.min) {
      errors.push(`${field} must be at least ${rules.min}`);
    }

    if (rules.type === 'number' && rules.max !== undefined && value > rules.max) {
      errors.push(`${field} must be no more than ${rules.max}`);
    }

    // Email validation
    if (rules.format === 'email' && !isValidEmail(value)) {
      errors.push(`${field} must be a valid email address`);
    }

    // Date validation
    if (rules.format === 'date' && !isValidDate(value)) {
      errors.push(`${field} must be a valid date`);
    }

    // Custom validation
    if (rules.validate && !rules.validate(value)) {
      errors.push(rules.message || `${field} is invalid`);
    }
  }

  return errors;
}

/**
 * Validate email format
 */
function isValidEmail(email) {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

/**
 * Validate date format
 */
function isValidDate(dateString) {
  const date = new Date(dateString);
  return date instanceof Date && !isNaN(date);
}

/**
 * Sanitize input data
 */
function sanitizeInput(data) {
  if (typeof data === 'string') {
    return data.trim().replace(/[<>]/g, '');
  }
  
  if (Array.isArray(data)) {
    return data.map(item => sanitizeInput(item));
  }
  
  if (typeof data === 'object' && data !== null) {
    const sanitized = {};
    for (const [key, value] of Object.entries(data)) {
      sanitized[key] = sanitizeInput(value);
    }
    return sanitized;
  }
  
  return data;
}

/**
 * Extract user information from request context
 */
function extractUserInfo(event) {
  const requestContext = event.requestContext || {};
  const authorizer = requestContext.authorizer || {};
  
  return {
    userId: authorizer.userId || null,
    userEmail: authorizer.userEmail || null,
    userRole: authorizer.userRole || null,
    organizationId: authorizer.organizationId || null
  };
}

/**
 * Log API request
 */
function logRequest(event, response) {
  const userInfo = extractUserInfo(event);
  const requestId = event.requestContext?.requestId || 'unknown';
  
  console.log(JSON.stringify({
    requestId,
    method: event.httpMethod,
    path: event.path,
    user: userInfo,
    statusCode: response.statusCode,
    timestamp: new Date().toISOString()
  }));
}

module.exports = {
  createResponse,
  createErrorResponse,
  createValidationErrorResponse,
  createNotFoundResponse,
  createUnauthorizedResponse,
  createForbiddenResponse,
  createRateLimitResponse,
  createServerErrorResponse,
  createMaintenanceResponse,
  validateRequestBody,
  sanitizeInput,
  extractUserInfo,
  logRequest
};
