// Square Integration Lambda Handler - Production Ready
// Handles OAuth flow and Square API integration

const https = require('https');
const crypto = require('crypto');

// Environment variables for Square production
const SQUARE_APPLICATION_ID = process.env.SQUARE_APPLICATION_ID;
const SQUARE_APPLICATION_SECRET = process.env.SQUARE_APPLICATION_SECRET;
const SQUARE_ENVIRONMENT = process.env.SQUARE_ENVIRONMENT || 'production';
const DATABASE_URL = process.env.DATABASE_URL;
const FRONTEND_URL = process.env.FRONTEND_URL || 'https://4kpajzuyfjzteslcq3sai5us6y0wqzqs.lambda-url.us-east-1.on.aws';

// In-memory storage for vendor data (in production, use DynamoDB)
const vendorSessions = new Map();

// Validate required environment variables
if (!SQUARE_APPLICATION_ID) {
    console.error('SQUARE_APPLICATION_ID not configured');
    throw new Error('Square Application ID not configured');
}

if (!SQUARE_APPLICATION_SECRET) {
    console.error('SQUARE_APPLICATION_SECRET not configured');
    throw new Error('Square Application Secret not configured');
}

// CORS headers for production
const corsHeaders = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization'
};

// Helper function to make HTTPS requests
function makeRequest(options, postData = null) {
    return new Promise((resolve, reject) => {
        const req = https.request(options, (res) => {
            let data = '';
            res.on('data', (chunk) => data += chunk);
            res.on('end', () => {
                try {
                    const parsed = JSON.parse(data);
                    resolve({ status: res.statusCode, data: parsed });
                } catch (e) {
                    resolve({ status: res.statusCode, data: data });
                }
            });
        });

        req.on('error', reject);
        
        if (postData) {
            req.write(postData);
        }
        
        req.end();
    });
}

// Generate secure state parameter for OAuth
function generateState() {
    return crypto.randomBytes(32).toString('hex');
}

// Start OAuth flow
async function handleStartOAuth(event) {
    try {
        const queryParams = new URLSearchParams(event.queryStringParameters || {});
        const email = queryParams.get('email');
        const business = queryParams.get('business');
        
        if (!email) {
            return {
                statusCode: 400,
                headers: corsHeaders,
                body: JSON.stringify({ error: 'Email parameter is required' })
            };
        }

        // Generate secure session ID and state parameter
        const sessionId = generateState();
        const state = generateState();
        
        // Store vendor data in session
        vendorSessions.set(sessionId, {
            email: email,
            business: business,
            createdAt: Date.now(),
            state: state
        });
        
        // Clean up old sessions (older than 1 hour)
        const oneHourAgo = Date.now() - (60 * 60 * 1000);
        for (const [id, session] of vendorSessions.entries()) {
            if (session.createdAt < oneHourAgo) {
                vendorSessions.delete(id);
            }
        }
        
        // Build Square authorization URL for production
        const authEndpoint = 'https://connect.squareup.com/oauth2/authorize';
        const redirectUri = `${FRONTEND_URL}/square-oauth-callback`;
        const scopes = 'MERCHANT_PROFILE_READ PAYMENTS_READ ORDERS_READ ORDERS_WRITE';
        
        // Use session ID as state parameter (Square will return this unchanged)
        const authState = sessionId;
        
        // DEBUGGING: Log all the values being used
        console.log('🔍 DEBUG: OAuth Configuration Values');
        console.log('  - FRONTEND_URL:', FRONTEND_URL);
        console.log('  - SQUARE_APPLICATION_ID:', SQUARE_APPLICATION_ID);
        console.log('  - SQUARE_ENVIRONMENT:', SQUARE_ENVIRONMENT);
        console.log('  - Email:', email);
        console.log('  - Business:', business);
        console.log('  - Session ID:', sessionId);
        console.log('  - Auth State:', authState);
        console.log('  - Redirect URI:', redirectUri);
        console.log('  - Scopes:', scopes);
        
        const authUrl = `${authEndpoint}?client_id=${encodeURIComponent(SQUARE_APPLICATION_ID)}&scope=${encodeURIComponent(scopes)}&redirect_uri=${encodeURIComponent(redirectUri)}&state=${authState}`;
        
        // DEBUGGING: Log the final constructed URL
        console.log('🔍 DEBUG: Final OAuth URL');
        console.log('  - Auth Endpoint:', authEndpoint);
        console.log('  - Full Auth URL:', authUrl);
        console.log('  - Encoded Redirect URI:', encodeURIComponent(redirectUri));
        
        console.log(`OAuth started for email: ${email}, business: ${business}, session: ${sessionId}`);
        
        return {
            statusCode: 200,
            headers: corsHeaders,
            body: JSON.stringify({
                success: true,
                authUrl: authUrl,
                sessionId: sessionId,
                message: 'Redirecting to Square OAuth',
                debug: {
                    frontendUrl: FRONTEND_URL,
                    redirectUri: redirectUri,
                    encodedRedirectUri: encodeURIComponent(redirectUri),
                    environment: SQUARE_ENVIRONMENT
                }
            })
        };
        
    } catch (error) {
        console.error('Error starting OAuth:', error);
        return {
            statusCode: 500,
            headers: corsHeaders,
            body: JSON.stringify({ 
                error: 'Failed to start OAuth flow',
                details: error.message 
            })
        };
    }
}

// Handle OAuth callback
async function handleOAuthCallback(event) {
    try {
        const queryParams = new URLSearchParams(event.queryStringParameters || {});
        const code = queryParams.get('code');
        const state = queryParams.get('state');
        const error = queryParams.get('error');
        
        if (error) {
            console.error('OAuth error:', error);
            return {
                statusCode: 400,
                headers: corsHeaders,
                body: JSON.stringify({ 
                    error: 'OAuth authorization failed',
                    details: error 
                })
            };
        }
        
        if (!code) {
            return {
                statusCode: 400,
                headers: corsHeaders,
                body: JSON.stringify({ error: 'Authorization code is required' })
            };
        }
        
        // Extract vendor data from session storage using state as session ID
        let vendorEmail = 'unknown@email.com';
        let vendorBusiness = 'Unknown Business';
        
        if (state) {
            const session = vendorSessions.get(state);
            if (session) {
                vendorEmail = session.email || 'unknown@email.com';
                vendorBusiness = session.business || 'Unknown Business';
                console.log('🔍 DEBUG: Retrieved vendor data from session');
                console.log('  - Email:', vendorEmail);
                console.log('  - Business:', vendorBusiness);
                console.log('  - Session ID:', state);
                
                // Clean up the session after use
                vendorSessions.delete(state);
            } else {
                console.warn('Session not found for state:', state);
                console.log('Available sessions:', Array.from(vendorSessions.keys()));
            }
        }
        
        // Exchange authorization code for access token
        const tokenEndpoint = 'https://connect.squareup.com/oauth2/token';
        // Use the Lambda's own endpoint for OAuth callback - this must match what's configured in Square
        const redirectUri = `${FRONTEND_URL}/square-oauth-callback`;
        
        const tokenData = {
            client_id: SQUARE_APPLICATION_ID,
            client_secret: SQUARE_APPLICATION_SECRET,
            code: code,
            grant_type: 'authorization_code',
            redirect_uri: redirectUri
        };
        
        const tokenOptions = {
            hostname: 'connect.squareup.com',
            port: 443,
            path: '/oauth2/token',
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Square-Version': '2024-12-18'
            }
        };
        
        const postData = new URLSearchParams(tokenData).toString();
        
        const tokenResponse = await makeRequest(tokenOptions, postData);
        
        if (tokenResponse.status !== 200) {
            console.error('Token exchange failed:', tokenResponse);
            return {
                statusCode: 400,
                headers: corsHeaders,
                body: JSON.stringify({ 
                    error: 'Failed to exchange authorization code for access token',
                    details: tokenResponse.data 
                })
            };
        }
        
        const { access_token, refresh_token, merchant_id } = tokenResponse.data;
        
        // Get vendor data from the OAuth request
        const email = event.queryStringParameters?.email || 'unknown@email.com';
        const business = event.queryStringParameters?.business || 'Unknown Business';
        
        console.log(`OAuth completed successfully for merchant: ${merchant_id}`);
        console.log(`Vendor data: ${business} (${email})`);
        
        // Store vendor in AWS (this will be called by the frontend)
        console.log(`OAuth completed successfully for merchant: ${merchant_id}`);
        console.log(`Vendor data: ${business} (${email})`);
        
        // Redirect to Lambda's own success page with vendor data
        const successUrl = `${FRONTEND_URL}/square-success?merchant_id=${merchant_id}&business=${encodeURIComponent(business)}&email=${encodeURIComponent(email)}`;
        
        return {
            statusCode: 200,
            headers: corsHeaders,
            body: JSON.stringify({
                success: true,
                merchant_id: merchant_id,
                business_name: business,
                email: email,
                redirect_url: successUrl,
                message: 'Square integration completed successfully. Please complete vendor registration.',
                next_step: 'Complete vendor registration in the success page'
            })
        };
        
    } catch (error) {
        console.error('Error handling OAuth callback:', error);
        return {
            statusCode: 500,
            headers: corsHeaders,
            body: JSON.stringify({ 
                error: 'Failed to complete OAuth flow',
                details: error.message 
            })
        };
    }
}

// Handle sessions debug endpoint
async function handleGetSessions(event) {
    try {
        const sessions = Array.from(vendorSessions.entries()).map(([id, session]) => ({
            id: id,
            email: session.email,
            business: session.business,
            createdAt: new Date(session.createdAt).toISOString(),
            age: Math.round((Date.now() - session.createdAt) / 1000) + 's ago'
        }));
        
        return {
            statusCode: 200,
            headers: corsHeaders,
            body: JSON.stringify({
                success: true,
                sessionCount: vendorSessions.size,
                sessions: sessions,
                message: 'Current vendor sessions'
            })
        };
        
    } catch (error) {
        console.error('Error getting sessions:', error);
        return {
            statusCode: 500,
            headers: corsHeaders,
            body: JSON.stringify({ 
                error: 'Failed to get sessions',
                details: error.message 
            })
        };
    }
}

// Handle Square success page
async function handleSquareSuccess(event) {
    try {
        const queryParams = new URLSearchParams(event.queryStringParameters || {});
        const merchantId = queryParams.get('merchant_id');
        const business = queryParams.get('business');
        const email = queryParams.get('email');
        
        if (!merchantId) {
            return {
                statusCode: 400,
                headers: corsHeaders,
                body: JSON.stringify({ error: 'Merchant ID is required' })
            };
        }
        
        // Return HTML success page with EzDrink styling
        const htmlContent = `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Square Integration Success - EzDrink</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700&family=Playfair+Display:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        body { 
            font-family: 'Montserrat', -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', sans-serif;
            background: #121212;
            color: #ffffff;
            line-height: 1.6;
            min-height: 100vh;
            position: relative;
            overflow-x: hidden;
        }
        
        /* Grid Background Pattern */
        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: 
                linear-gradient(rgba(255, 255, 255, 0.03) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255, 255, 255, 0.03) 1px, transparent 1px);
            background-size: 40px 40px;
            z-index: -2;
        }
        
        /* Gradient Overlays */
        body::after {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: 
                radial-gradient(circle at 30% 20%, rgba(212, 175, 55, 0.1) 0%, transparent 50%),
                radial-gradient(circle at 70% 60%, rgba(212, 175, 55, 0.08) 0%, transparent 50%);
            z-index: -1;
        }
        
        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 40px 20px;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
        }
        
        .success-card {
            background: #0a0a0a;
            border: 1px solid rgba(212, 175, 55, 0.2);
            border-radius: 12px;
            padding: 40px;
            text-align: center;
            box-shadow: 0 25px 50px rgba(0, 0, 0, 0.3), 0 0 30px rgba(212, 175, 55, 0.15);
            backdrop-filter: blur(10px);
            width: 100%;
            max-width: 600px;
        }
        
        .success-icon {
            font-size: 80px;
            margin-bottom: 30px;
            background: linear-gradient(135deg, #d4af37, #f5d76e, #926f34);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        h1 {
            font-family: 'Playfair Display', serif;
            font-size: 32px;
            font-weight: 600;
            margin-bottom: 10px;
            background: linear-gradient(135deg, #d4af37, #f5d76e);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .subtitle {
            color: rgba(255, 255, 255, 0.7);
            font-size: 16px;
            margin-bottom: 40px;
            font-weight: 300;
        }
        
        .info-box {
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(212, 175, 55, 0.2);
            border-radius: 10px;
            padding: 25px;
            margin: 30px 0;
            text-align: left;
        }
        
        .info-box h3 {
            font-family: 'Playfair Display', serif;
            font-size: 20px;
            font-weight: 600;
            margin-bottom: 20px;
            color: #d4af37;
        }
        
        .info-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px 0;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .info-item:last-child {
            border-bottom: none;
        }
        
        .info-label {
            font-weight: 500;
            color: rgba(255, 255, 255, 0.8);
        }
        
        .info-value {
            font-weight: 600;
            color: #ffffff;
            font-family: 'Monaco', 'Menlo', monospace;
            background: rgba(212, 175, 55, 0.1);
            padding: 4px 8px;
            border-radius: 4px;
            border: 1px solid rgba(212, 175, 55, 0.3);
        }
        
        .next-steps {
            background: rgba(212, 175, 55, 0.05);
            border: 1px solid rgba(212, 175, 55, 0.2);
            border-radius: 10px;
            padding: 25px;
            margin: 30px 0;
        }
        
        .next-steps h3 {
            font-family: 'Playfair Display', serif;
            font-size: 20px;
            font-weight: 600;
            margin-bottom: 15px;
            color: #d4af37;
        }
        
        .next-steps p {
            color: rgba(255, 255, 255, 0.8);
            margin-bottom: 15px;
        }
        
        .next-steps ul {
            list-style: none;
            padding: 0;
        }
        
        .next-steps li {
            color: rgba(255, 255, 255, 0.7);
            padding: 8px 0;
            position: relative;
            padding-left: 25px;
        }
        
        .next-steps li::before {
            content: '✨';
            position: absolute;
            left: 0;
            color: #d4af37;
        }
        
        .button-group {
            display: flex;
            gap: 15px;
            justify-content: center;
            margin-top: 40px;
            flex-wrap: wrap;
        }
        
        .btn {
            display: inline-block;
            padding: 15px 30px;
            text-decoration: none;
            border-radius: 25px;
            font-weight: 600;
            font-size: 14px;
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
            min-width: 160px;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #d4af37, #f5d76e, #926f34);
            color: #000000;
            box-shadow: 0 4px 12px rgba(212, 175, 55, 0.2);
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(212, 175, 55, 0.3);
        }
        
        .btn-secondary {
            background: rgba(255, 255, 255, 0.05);
            color: #ffffff;
            border: 1px solid rgba(212, 175, 55, 0.3);
        }
        
        .btn-secondary:hover {
            background: rgba(255, 255, 255, 0.1);
            border-color: rgba(212, 175, 55, 0.5);
        }
        
        @media (max-width: 768px) {
            .container { padding: 20px 15px; }
            .success-card { padding: 30px 20px; }
            h1 { font-size: 28px; }
            .button-group { flex-direction: column; align-items: center; }
            .btn { width: 100%; max-width: 280px; }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="success-card">
            <div class="success-icon">🎉</div>
            <h1>Integration Successful!</h1>
            <p class="subtitle">Your Square account is now connected to EzDrink</p>
            
            <div class="info-box">
                <h3>Integration Details</h3>
                <div class="info-item">
                    <span class="info-label">Merchant ID:</span>
                    <span class="info-value">${merchantId}</span>
                </div>
                <div class="info-item">
                    <span class="info-label">Business Name:</span>
                    <span class="info-value">${business || 'N/A'}</span>
                </div>
                <div class="info-item">
                    <span class="info-label">Email:</span>
                    <span class="info-value">${email || 'N/A'}</span>
                </div>
            </div>
            
            <div class="next-steps">
                <h3>What Happens Next?</h3>
                <p>Your Square account is now fully integrated with the EzDrink platform!</p>
                <ul>
                    <li>Mobile orders will flow directly to your Square POS</li>
                    <li>Your menu and inventory will sync automatically</li>
                    <li>Real-time order notifications and updates</li>
                    <li>Access to advanced analytics and insights</li>
                </ul>
            </div>
            
            <div class="button-group">
                <a href="https://seamlessly.us" class="btn btn-primary">Go to EzDrink</a>
                <a href="https://app.squareup.com" class="btn btn-secondary">Square Dashboard</a>
            </div>
        </div>
    </div>
</body>
</html>`;
        
        return {
            statusCode: 200,
            headers: {
                ...corsHeaders,
                'Content-Type': 'text/html'
            },
            body: htmlContent
        };
        
    } catch (error) {
        console.error('Error handling Square success page:', error);
        return {
            statusCode: 500,
            headers: corsHeaders,
            body: JSON.stringify({ 
                error: 'Failed to display success page',
                details: error.message 
            })
        };
    }
}

// Test Square connection
async function testSquareConnection(event) {
    try {
        const body = JSON.parse(event.body || '{}');
        const { access_token, merchant_id } = body;
        
        if (!access_token || !merchant_id) {
            return {
                statusCode: 400,
                headers: corsHeaders,
                body: JSON.stringify({ error: 'Access token and merchant ID are required' })
            };
        }
        
        // Test Square API connection by getting merchant info
        const apiOptions = {
            hostname: 'connect.squareup.com',
            port: 443,
            path: '/v2/merchants',
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${access_token}`,
                'Square-Version': '2024-12-18'
            }
        };
        
        const apiResponse = await makeRequest(apiOptions);
        
        if (apiResponse.status !== 200) {
            return {
                statusCode: 400,
                headers: corsHeaders,
                body: JSON.stringify({ 
                    error: 'Failed to connect to Square API',
                    details: apiResponse.data 
                })
            };
        }
        
        return {
            statusCode: 200,
            headers: corsHeaders,
            body: JSON.stringify({
                success: true,
                message: 'Square connection test successful',
                merchant_data: apiResponse.data
            })
        };
        
    } catch (error) {
        console.error('Error testing Square connection:', error);
        return {
            statusCode: 500,
            headers: corsHeaders,
            body: JSON.stringify({ 
                error: 'Failed to test Square connection',
                details: error.message 
            })
        };
    }
}

// Main Lambda handler
exports.handler = async (event) => {
    console.log('=== SQUARE LAMBDA HANDLER ===');
    console.log('Event:', JSON.stringify(event, null, 2));
    console.log('Environment:', SQUARE_ENVIRONMENT);
    console.log('Application ID:', SQUARE_APPLICATION_ID ? 'Configured' : 'Missing');
    
    // DEBUGGING: Log all environment variables
    console.log('🔍 DEBUG: Environment Variables');
    console.log('  - FRONTEND_URL:', FRONTEND_URL);
    console.log('  - SQUARE_APPLICATION_ID:', SQUARE_APPLICATION_ID);
    console.log('  - SQUARE_ENVIRONMENT:', SQUARE_ENVIRONMENT);
    console.log('  - DATABASE_URL:', DATABASE_URL ? 'Configured' : 'Missing');
    
    // Handle CORS preflight
    if (event.httpMethod === 'OPTIONS') {
        return {
            statusCode: 200,
            headers: corsHeaders,
            body: ''
        };
    }
    
    const path = event.rawPath || event.path || '';
    const method = event.httpMethod || 'GET';
    
    try {
        // Route requests based on path and method
        if (path === '/start-oauth' && method === 'GET') {
            return await handleStartOAuth(event);
        }
        
        if ((path === '/oauth-callback' || path === '/square-oauth-callback') && method === 'GET') {
            return await handleOAuthCallback(event);
        }
        
        if (path === '/square-success' && method === 'GET') {
            return await handleSquareSuccess(event);
        }
        
        if (path === '/sessions' && method === 'GET') {
            return await handleGetSessions(event);
        }
        
        if (path === '/test-connection' && method === 'POST') {
            return await testSquareConnection(event);
        }
        
        // Default response
        return {
            statusCode: 404,
            headers: corsHeaders,
            body: JSON.stringify({ 
                error: 'Endpoint not found',
                available_endpoints: [
                    'GET /start-oauth',
                    'GET /oauth-callback',
                    'GET /square-oauth-callback',
                    'GET /square-success',
                    'GET /sessions',
                    'POST /test-connection'
                ]
            })
        };
        
    } catch (error) {
        console.error('Lambda handler error:', error);
        return {
            statusCode: 500,
            headers: corsHeaders,
            body: JSON.stringify({ 
                error: 'Internal server error',
                details: error.message 
            })
        };
    }
};
