// Square Integration Lambda Handler - Production Ready
// Handles OAuth flow and Square API integration

const https = require('https');
const crypto = require('crypto');

// Environment variables for Square production
const SQUARE_APPLICATION_ID = process.env.SQUARE_APPLICATION_ID;
const SQUARE_APPLICATION_SECRET = process.env.SQUARE_APPLICATION_SECRET;
const SQUARE_ENVIRONMENT = process.env.SQUARE_ENVIRONMENT || 'production';
const DATABASE_URL = process.env.DATABASE_URL;
const FRONTEND_URL = process.env.FRONTEND_URL || 'https://4kpajzuyfjzteslcq3sai5us6y0wqzqs.lambda-url.us-east-1.on.aws';

// Validate required environment variables
if (!SQUARE_APPLICATION_ID) {
    console.error('SQUARE_APPLICATION_ID not configured');
    throw new Error('Square Application ID not configured');
}

if (!SQUARE_APPLICATION_SECRET) {
    console.error('SQUARE_APPLICATION_SECRET not configured');
    throw new Error('Square Application Secret not configured');
}

// CORS headers for production
const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
    'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
    'Content-Type': 'application/json'
};

// Helper function to make HTTPS requests
function makeRequest(options, postData = null) {
    return new Promise((resolve, reject) => {
        const req = https.request(options, (res) => {
            let data = '';
            res.on('data', (chunk) => data += chunk);
            res.on('end', () => {
                try {
                    const parsed = JSON.parse(data);
                    resolve({ status: res.statusCode, data: parsed });
                } catch (e) {
                    resolve({ status: res.statusCode, data: data });
                }
            });
        });

        req.on('error', reject);
        
        if (postData) {
            req.write(postData);
        }
        
        req.end();
    });
}

// Generate secure state parameter for OAuth
function generateState() {
    return crypto.randomBytes(32).toString('hex');
}

// Start OAuth flow
async function handleStartOAuth(event) {
    try {
        const queryParams = new URLSearchParams(event.queryStringParameters || {});
        const email = queryParams.get('email');
        const business = queryParams.get('business');
        
        if (!email) {
            return {
                statusCode: 400,
                headers: corsHeaders,
                body: JSON.stringify({ error: 'Email parameter is required' })
            };
        }

        // Generate secure state parameter
        const state = generateState();
        
        // Build Square authorization URL for production
        const authEndpoint = 'https://connect.squareup.com/oauth2/authorize';
        const redirectUri = `${FRONTEND_URL}/square-oauth-callback`;
        const scopes = 'MERCHANT_PROFILE_READ PAYMENTS_READ ORDERS_READ ORDERS_WRITE';
        
        // DEBUGGING: Log all the values being used
        console.log('🔍 DEBUG: OAuth Configuration Values');
        console.log('  - FRONTEND_URL:', FRONTEND_URL);
        console.log('  - SQUARE_APPLICATION_ID:', SQUARE_APPLICATION_ID);
        console.log('  - SQUARE_ENVIRONMENT:', SQUARE_ENVIRONMENT);
        console.log('  - Email:', email);
        console.log('  - Business:', business);
        console.log('  - State:', state);
        console.log('  - Redirect URI:', redirectUri);
        console.log('  - Scopes:', scopes);
        
        const authUrl = `${authEndpoint}?client_id=${encodeURIComponent(SQUARE_APPLICATION_ID)}&scope=${encodeURIComponent(scopes)}&redirect_uri=${encodeURIComponent(redirectUri)}&state=${state}`;
        
        // DEBUGGING: Log the final constructed URL
        console.log('🔍 DEBUG: Final OAuth URL');
        console.log('  - Auth Endpoint:', authEndpoint);
        console.log('  - Full Auth URL:', authUrl);
        console.log('  - Encoded Redirect URI:', encodeURIComponent(redirectUri));
        
        // Store state temporarily (in production, you'd store this in a database)
        // For now, we'll include it in the response for demo purposes
        console.log(`OAuth started for email: ${email}, business: ${business}, state: ${state}`);
        
        return {
            statusCode: 200,
            headers: corsHeaders,
            body: JSON.stringify({
                success: true,
                authUrl: authUrl,
                state: state,
                message: 'Redirecting to Square OAuth',
                debug: {
                    frontendUrl: FRONTEND_URL,
                    redirectUri: redirectUri,
                    encodedRedirectUri: encodeURIComponent(redirectUri),
                    environment: SQUARE_ENVIRONMENT
                }
            })
        };
        
    } catch (error) {
        console.error('Error starting OAuth:', error);
        return {
            statusCode: 500,
            headers: corsHeaders,
            body: JSON.stringify({ 
                error: 'Failed to start OAuth flow',
                details: error.message 
            })
        };
    }
}

// Handle OAuth callback
async function handleOAuthCallback(event) {
    try {
        const queryParams = new URLSearchParams(event.queryStringParameters || {});
        const code = queryParams.get('code');
        const state = queryParams.get('state');
        const error = queryParams.get('error');
        
        if (error) {
            console.error('OAuth error:', error);
            return {
                statusCode: 400,
                headers: corsHeaders,
                body: JSON.stringify({ 
                    error: 'OAuth authorization failed',
                    details: error 
                })
            };
        }
        
        if (!code) {
            return {
                statusCode: 400,
                headers: corsHeaders,
                body: JSON.stringify({ error: 'Authorization code is required' })
            };
        }
        
        // Exchange authorization code for access token
        const tokenEndpoint = 'https://connect.squareup.com/oauth2/token';
        const redirectUri = `${FRONTEND_URL}/square-oauth-callback`;
        
        const tokenData = {
            client_id: SQUARE_APPLICATION_ID,
            client_secret: SQUARE_APPLICATION_SECRET,
            code: code,
            grant_type: 'authorization_code',
            redirect_uri: redirectUri
        };
        
        const tokenOptions = {
            hostname: 'connect.squareup.com',
            port: 443,
            path: '/oauth2/token',
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Square-Version': '2024-12-18'
            }
        };
        
        const postData = new URLSearchParams(tokenData).toString();
        
        const tokenResponse = await makeRequest(tokenOptions, postData);
        
        if (tokenResponse.status !== 200) {
            console.error('Token exchange failed:', tokenResponse);
            return {
                statusCode: 400,
                headers: corsHeaders,
                body: JSON.stringify({ 
                    error: 'Failed to exchange authorization code for access token',
                    details: tokenResponse.data 
                })
            };
        }
        
        const { access_token, refresh_token, merchant_id } = tokenResponse.data;
        
        // Get vendor data from the OAuth request
        const email = event.queryStringParameters?.email || 'unknown@email.com';
        const business = event.queryStringParameters?.business || 'Unknown Business';
        
        // Store vendor in AWS (this will be called by the frontend)
        console.log(`OAuth completed successfully for merchant: ${merchant_id}`);
        console.log(`Vendor data: ${business} (${email})`);
        
        // Redirect to frontend success page with vendor data
        const frontendUrl = process.env.FRONTEND_FRONTEND_URL || 'https://seamless.us';
        const successUrl = `${frontendUrl}/square-success?merchant_id=${merchant_id}&business=${encodeURIComponent(business)}&email=${encodeURIComponent(email)}`;
        
        return {
            statusCode: 200,
            headers: corsHeaders,
            body: JSON.stringify({
                success: true,
                merchant_id: merchant_id,
                business_name: business,
                email: email,
                redirect_url: successUrl,
                message: 'Square integration completed successfully. Please complete vendor registration.',
                next_step: 'Complete vendor registration in the success page'
            })
        };
        
    } catch (error) {
        console.error('Error handling OAuth callback:', error);
        return {
            statusCode: 500,
            headers: corsHeaders,
            body: JSON.stringify({ 
                error: 'Failed to complete OAuth flow',
                details: error.message 
            })
        };
    }
}

// Test Square connection
async function testSquareConnection(event) {
    try {
        const body = JSON.parse(event.body || '{}');
        const { access_token, merchant_id } = body;
        
        if (!access_token || !merchant_id) {
            return {
                statusCode: 400,
                headers: corsHeaders,
                body: JSON.stringify({ error: 'Access token and merchant ID are required' })
            };
        }
        
        // Test Square API connection by getting merchant info
        const apiOptions = {
            hostname: 'connect.squareup.com',
            port: 443,
            path: '/v2/merchants',
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${access_token}`,
                'Square-Version': '2024-12-18'
            }
        };
        
        const apiResponse = await makeRequest(apiOptions);
        
        if (apiResponse.status !== 200) {
            return {
                statusCode: 400,
                headers: corsHeaders,
                body: JSON.stringify({ 
                    error: 'Failed to connect to Square API',
                    details: apiResponse.data 
                })
            };
        }
        
        return {
            statusCode: 200,
            headers: corsHeaders,
            body: JSON.stringify({
                success: true,
                message: 'Square connection test successful',
                merchant_data: apiResponse.data
            })
        };
        
    } catch (error) {
        console.error('Error testing Square connection:', error);
        return {
            statusCode: 500,
            headers: corsHeaders,
            body: JSON.stringify({ 
                error: 'Failed to test Square connection',
                details: error.message 
            })
        };
    }
}

// Main Lambda handler
exports.handler = async (event) => {
    console.log('=== SQUARE LAMBDA HANDLER ===');
    console.log('Event:', JSON.stringify(event, null, 2));
    console.log('Environment:', SQUARE_ENVIRONMENT);
    console.log('Application ID:', SQUARE_APPLICATION_ID ? 'Configured' : 'Missing');
    
    // DEBUGGING: Log all environment variables
    console.log('🔍 DEBUG: Environment Variables');
    console.log('  - FRONTEND_URL:', FRONTEND_URL);
    console.log('  - SQUARE_APPLICATION_ID:', SQUARE_APPLICATION_ID);
    console.log('  - SQUARE_ENVIRONMENT:', SQUARE_ENVIRONMENT);
    console.log('  - DATABASE_URL:', DATABASE_URL ? 'Configured' : 'Missing');
    
    // Handle CORS preflight
    if (event.httpMethod === 'OPTIONS') {
        return {
            statusCode: 200,
            headers: corsHeaders,
            body: ''
        };
    }
    
    const path = event.rawPath || event.path || '';
    const method = event.httpMethod || 'GET';
    
    try {
        // Route requests based on path and method
        if (path === '/start-oauth' && method === 'GET') {
            return await handleStartOAuth(event);
        }
        
        if (path === '/oauth-callback' && method === 'GET') {
            return await handleOAuthCallback(event);
        }
        
        if (path === '/test-connection' && method === 'POST') {
            return await testSquareConnection(event);
        }
        
        // Default response
        return {
            statusCode: 404,
            headers: corsHeaders,
            body: JSON.stringify({ 
                error: 'Endpoint not found',
                available_endpoints: [
                    'GET /start-oauth',
                    'GET /oauth-callback', 
                    'POST /test-connection'
                ]
            })
        };
        
    } catch (error) {
        console.error('Lambda handler error:', error);
        return {
            statusCode: 500,
            headers: corsHeaders,
            body: JSON.stringify({ 
                error: 'Internal server error',
                details: error.message 
            })
        };
    }
};
