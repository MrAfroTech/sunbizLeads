// Enhanced Lambda callback handler for Clover OAuth with token exchange
// Replicated from Square's proven OAuth flow pattern

// Load environment variables
// Environment variables are set in Lambda configuration

// Clover application credentials from environment variables
const CLOVER_APPLICATION_ID = process.env.CLOVER_CLIENT_ID || process.env.REACT_APP_CLOVER_CLIENT_ID;
const CLOVER_CLIENT_SECRET = process.env.CLOVER_CLIENT_SECRET || process.env.REACT_APP_CLOVER_CLIENT_SECRET;
const CLOVER_ENVIRONMENT = process.env.CLOVER_ENVIRONMENT || 'production'; // 'sandbox' or 'production'

// AWS SDK v3 imports
const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, PutCommand } = require('@aws-sdk/lib-dynamodb');
const https = require('https');

// Configure AWS SDK v3
const client = new DynamoDBClient({ region: process.env.AWS_REGION || 'us-east-1' });
const dynamodb = DynamoDBDocumentClient.from(client);

exports.handler = async (event) => {
    console.log('Event received:', JSON.stringify(event, null, 2));
    
    try {
        // Handle CORS preflight
        if (event.httpMethod === 'OPTIONS') {
            return {
                statusCode: 200,
                headers: {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
                    'Access-Control-Allow-Methods': 'GET,POST,OPTIONS'
                },
                body: ''
            };
        }

        // Parse query parameters
        const queryParams = event.queryStringParameters || {};
        console.log('Query parameters:', queryParams);
        
        const { code, state, merchant_id, employee_id, client_id } = queryParams;
        
        // Validate required parameters
        if (!code) {
            console.error('Missing authorization code');
            return {
                statusCode: 400,
                headers: {
                    'Access-Control-Allow-Origin': '*',
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    error: 'Missing authorization code',
                    receivedParams: queryParams
                })
            };
        }

        if (!state) {
            console.error('Missing state parameter');
            return {
                statusCode: 400,
                headers: {
                    'Access-Control-Allow-Origin': '*',
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    error: 'Missing state parameter',
                    receivedParams: queryParams
                })
            };
        }

        // State parameter is now just the token
        const token = state;
        console.log('Received token:', token);
        
        // For now, we'll use the merchant_id and employee_id from the URL
        // In a production system, you'd look up the full integration data using the token
        const stateData = {
            customer_id: `clover_${merchant_id}`,
            businessName: 'Clover Business', // This could be looked up from the token
            email: 'clover@example.com' // This could be looked up from the token
        };

        // Exchange authorization code for access token
        const tokenResponse = await exchangeCodeForToken(code);
        console.log('Token exchange successful');

        // Store credentials in DynamoDB
        const tableName = process.env.DYNAMODB_CLOVER_TABLE || 'seamless-clover-tokens';
        
        // Ensure expires_in is a valid number
        const expiresIn = parseInt(tokenResponse.expires_in) || 3600; // Default to 1 hour if invalid
        const expiresAt = Date.now() + (expiresIn * 1000);
        
        const item = {
            vendor_id: stateData.customer_id || `clover_${merchant_id}`,
            merchant_id: merchant_id || 'unknown',
            employee_id: employee_id || 'unknown',
            access_token: tokenResponse.access_token,
            refresh_token: tokenResponse.refresh_token,
            expires_at: expiresAt,
            environment: process.env.CLOVER_ENVIRONMENT || 'production',
            business_name: stateData.businessName || 'Unknown Business',
            email: stateData.email || 'unknown@example.com',
            pos_system: 'clover',
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString()
        };

        await dynamodb.send(new PutCommand({
            TableName: tableName,
            Item: item
        }));

        console.log('Credentials stored in DynamoDB');

        // Redirect to frontend
        const frontendUrl = process.env.CLOVER_FRONTEND_URL || 'https://api.seamlessly.us';
        const redirectUrl = `${frontendUrl}/clover/success?status=success&vendor_id=${item.vendor_id}`;

        return {
            statusCode: 302,
            headers: {
                'Location': redirectUrl,
                'Access-Control-Allow-Origin': '*'
            },
            body: ''
        };

    } catch (error) {
        console.error('Error processing OAuth callback:', error);
        
        const frontendUrl = process.env.CLOVER_FRONTEND_URL || 'https://api.seamlessly.us';
        const errorRedirectUrl = `${frontendUrl}/clover/error?error=${encodeURIComponent(error.message)}`;

        return {
            statusCode: 302,
            headers: {
                'Location': errorRedirectUrl,
                'Access-Control-Allow-Origin': '*'
            },
            body: ''
        };
    }
};

async function exchangeCodeForToken(authorizationCode) {
    return new Promise((resolve, reject) => {
        const postData = JSON.stringify({
            client_id: process.env.CLOVER_CLIENT_ID,
            client_secret: process.env.CLOVER_CLIENT_SECRET,
            code: authorizationCode,
            grant_type: 'authorization_code'
        });

        const options = {
            hostname: 'clover.com',
            port: 443,
            path: '/oauth/token',
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Content-Length': Buffer.byteLength(postData)
            }
        };

        const req = https.request(options, (res) => {
            let data = '';
            
            res.on('data', (chunk) => {
                data += chunk;
            });
            
            res.on('end', () => {
                try {
                    const response = JSON.parse(data);
                    if (response.error) {
                        reject(new Error(`Clover API error: ${response.error_description || response.error}`));
                    } else {
                        resolve(response);
                    }
                } catch (error) {
                    reject(new Error(`Failed to parse token response: ${error.message}`));
                }
            });
        });

        req.on('error', (error) => {
            reject(new Error(`Request failed: ${error.message}`));
        });

        req.write(postData);
        req.end();
    });
}
