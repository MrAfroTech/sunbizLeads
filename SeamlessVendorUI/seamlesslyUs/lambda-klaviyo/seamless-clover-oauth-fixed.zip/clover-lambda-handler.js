// Enhanced Lambda callback handler for Clover OAuth with token exchange
// Replicated from Square's proven OAuth flow pattern

// Load environment variables
// Environment variables are set in Lambda configuration

// Clover application credentials from environment variables
const CLOVER_APPLICATION_ID = process.env.CLOVER_CLIENT_ID || process.env.REACT_APP_CLOVER_CLIENT_ID;
const CLOVER_CLIENT_SECRET = process.env.CLOVER_CLIENT_SECRET || process.env.REACT_APP_CLOVER_CLIENT_SECRET;
const CLOVER_ENVIRONMENT = process.env.CLOVER_ENVIRONMENT || 'sandbox'; // 'sandbox' or 'production'

async function exchangeCodeForToken(authorizationCode, event) {
    try {
        console.log('Starting Clover token exchange...');
        console.log('Authorization code received:', authorizationCode.substring(0, 10) + '...');
        
        // Determine the correct token endpoint based on Clover's documentation
        const tokenEndpoint = CLOVER_ENVIRONMENT === 'sandbox' 
            ? 'https://sandbox.dev.clover.com/oauth/token'
            : 'https://api.clover.com/oauth/token';
            
        // Get the redirect URI from environment variable
        const redirectUri = process.env.CLOVER_REDIRECT_URI;
        
        if (!redirectUri) {
            throw new Error('CLOVER_REDIRECT_URI environment variable is not set');
        }
        
        console.log('Token endpoint:', tokenEndpoint);
        console.log('Redirect URI:', redirectUri);
        
        // Prepare token exchange request using form-encoded data as per OAuth 2.0 spec
        const tokenRequestData = new URLSearchParams({
            client_id: process.env.CLOVER_CLIENT_ID,
            client_secret: process.env.CLOVER_CLIENT_SECRET,
            code: authorizationCode,
            grant_type: 'authorization_code',
            redirect_uri: redirectUri
        });
        
        console.log('Token request prepared (client_secret redacted)');
        console.log('Request data keys:', Array.from(tokenRequestData.keys()));
        
        const axios = require('axios');
        
        try {
            const response = await axios.post(tokenEndpoint, tokenRequestData, {
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'Accept': 'application/json'
                }
            });
            
            console.log('Token response status:', response.status);
            console.log('Token response headers:', response.headers);
            console.log('Token response data keys:', Object.keys(response.data));
            
            const tokenData = response.data;
            
            // Store the token securely (you might want to save this to a database)
            console.log('Token exchange successful');
            console.log('Access token received:', tokenData.access_token?.substring(0, 20) + '...');
            console.log('Merchant ID:', tokenData.merchant_id);
            console.log('Token type:', tokenData.token_type);
            console.log('Expires in:', tokenData.expires_in);
            
            return {
                success: true,
                data: tokenData
            };
            
        } catch (axiosError) {
            console.error('Axios error during token exchange:');
            console.error('Status:', axiosError.response?.status);
            console.error('Status text:', axiosError.response?.statusText);
            console.error('Response data:', axiosError.response?.data);
            console.error('Response headers:', axiosError.response?.headers);
            console.error('Request data sent:', tokenRequestData.toString().replace(CLOVER_CLIENT_SECRET, '***REDACTED***'));
            
            return {
                success: false,
                error: `Token exchange failed: ${axiosError.response?.status || 'Unknown'}`,
                details: axiosError.response?.data || axiosError.message,
                status: axiosError.response?.status
            };
        }
        
    } catch (error) {
        console.error('Error during token exchange:', error);
        return {
            success: false,
            error: error.message,
            details: error.stack
        };
    }
}

exports.handler = async (event, context) => {
    // Enable detailed CloudWatch logging
    console.log('=== SEAMLESS CLOVER OAUTH CALLBACK DEBUG ===');
    console.log('Event:', JSON.stringify(event, null, 2));
    console.log('Context:', JSON.stringify(context, null, 2));
    console.log('Headers:', JSON.stringify(event.headers, null, 2));
    console.log('Raw Path:', event.rawPath || 'NONE');
    console.log('Raw Query String:', event.rawQueryString || 'NONE');
    console.log('Request Context Method:', event.requestContext?.http?.method || 'NONE');
    console.log('Request Context Path:', event.requestContext?.http?.path || 'NONE');
    
    try {
        // Handle preflight OPTIONS request for CORS
        if (event.requestContext?.http?.method === 'OPTIONS') {
            console.log('Handling OPTIONS preflight request');
            return {
                statusCode: 200,
                headers: {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
                    'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
                    'Access-Control-Max-Age': '86400'
                },
                body: JSON.stringify({ message: 'CORS preflight handled' })
            };
        }
        
        // Extract OAuth parameters with enhanced logging
        let queryParams = {};
        let code, state, error, error_description, merchant_id, employee_id;
        
        if (event.rawQueryString) {
            // Parse raw query string manually - this is the primary source for Lambda Function URLs
            const params = new URLSearchParams(event.rawQueryString);
            code = params.get('code');
            state = params.get('state');
            error = params.get('error');
            error_description = params.get('error_description');
            merchant_id = params.get('merchant_id');
            employee_id = params.get('employee_id');
            console.log('Extracted from rawQueryString');
        } else if (event.queryStringParameters) {
            // Fallback to queryStringParameters if they exist
            queryParams = event.queryStringParameters;
            code = queryParams.code;
            state = queryParams.state;
            error = queryParams.error;
            error_description = queryParams.error_description;
            merchant_id = queryParams.merchant_id;
            employee_id = queryParams.employee_id;
            console.log('Extracted from queryStringParameters');
        }
        
        console.log('=== OAUTH PARAMETER ANALYSIS ===');
        console.log('rawQueryString:', event.rawQueryString);
        console.log('queryStringParameters:', event.queryStringParameters);
        console.log('Authorization code present:', !!code);
        console.log('State parameter present:', !!state);
        console.log('Error parameter present:', !!error);
        console.log('Merchant ID present:', !!merchant_id);
        console.log('Employee ID present:', !!employee_id);
        
        // Handle OAuth error responses
        if (error) {
            console.error('OAuth Error received:', error);
            console.error('Error description:', error_description);
            return {
                statusCode: 400,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    error: 'OAuth Error',
                    details: error_description || error,
                    debug: {
                        receivedParams: queryParams,
                        timestamp: new Date().toISOString(),
                        requestId: context.awsRequestId
                    }
                })
            };
        }
        
        // Check for authorization code with detailed error reporting
        if (!code) {
            console.error('=== MISSING AUTHORIZATION CODE ERROR ===');
            console.error('Event structure:', {
                hasRawQueryString: !!event.rawQueryString,
                hasQueryStringParams: !!event.queryStringParameters,
                rawQueryString: event.rawQueryString,
                queryStringParams: event.queryStringParameters
            });
            
            return {
                statusCode: 400,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    error: 'Missing authorization code',
                    message: 'The OAuth callback did not include the required authorization code',
                    debug: {
                        receivedParams: event.rawQueryString,
                        expectedParams: ['code'],
                        optionalParams: ['state', 'merchant_id', 'employee_id'],
                        timestamp: new Date().toISOString(),
                        requestId: context.awsRequestId,
                        functionName: context.functionName,
                        rawQueryString: event.rawQueryString
                    },
                    troubleshooting: {
                        checkOAuthURL: 'Ensure the OAuth authorization URL includes response_type=code',
                        checkRedirectURI: 'Verify the redirect_uri matches exactly what was registered with Clover',
                        checkCloverSetup: 'Confirm the Clover app is properly configured for OAuth'
                    }
                })
            };
        }
        
        console.log('=== AUTHORIZATION CODE VALIDATION ===');
        console.log('Authorization code received successfully');
        console.log('Code length:', code.length);
        console.log('Code preview:', code.substring(0, 10) + '...');
        console.log('Code format valid:', /^[A-Za-z0-9_-]+$/.test(code));
        
        // Exchange authorization code for access token
        const tokenExchangeResult = await exchangeCodeForToken(code, event);
        
        if (tokenExchangeResult.success) {
            console.log('=== TOKEN EXCHANGE SUCCESS ===');
            console.log('Token exchange completed successfully');
            
            // Return success response with token info
            const successResponse = {
                statusCode: 200,
                headers: {
                    'Content-Type': 'text/html',
                    'Access-Control-Allow-Origin': '*'
                },
                body: `
                    <!DOCTYPE html>
                    <html>
                    <head>
                        <title>Clover OAuth Success</title>
                        <style>
                            body { 
                                font-family: Arial, sans-serif; 
                                max-width: 600px; 
                                margin: 50px auto; 
                                padding: 20px;
                                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                                min-height: 100vh;
                            }
                            .container {
                                background: white;
                                padding: 30px;
                                border-radius: 10px;
                                box-shadow: 0 10px 30px rgba(0,0,0,0.2);
                            }
                            .success { color: #28a745; }
                            .info { background: #f8f9fa; padding: 15px; border-radius: 5px; margin: 20px 0; }
                            .code { font-family: monospace; background: #e9ecef; padding: 10px; border-radius: 3px; word-break: break-all; font-size: 12px; }
                            .debug { background: #fff3cd; padding: 15px; border-radius: 5px; margin: 20px 0; border-left: 4px solid #ffc107; }
                        </style>
                    </head>
                    <body>
                        <div class="container">
                            <h1 class="success">🎉 Clover OAuth Complete!</h1>
                            <p>Successfully connected to Clover and obtained access token.</p>
                            
                            <div class="info">
                                <h3>Connection Details:</h3>
                                <p><strong>Merchant ID:</strong> <span class="code">${tokenExchangeResult.data.merchant_id || 'N/A'}</span></p>
                                <p><strong>Access Token:</strong></p>
                                <div class="code">${tokenExchangeResult.data.access_token.substring(0, 20)}...</div>
                                <p><strong>Token Type:</strong> ${tokenExchangeResult.data.token_type || 'Bearer'}</p>
                                <p><strong>Expires In:</strong> ${tokenExchangeResult.data.expires_in ? `${tokenExchangeResult.data.expires_in} seconds` : 'Never'}</p>
                                <p><strong>Scopes:</strong> ${(tokenExchangeResult.data.scope || []).join(', ') || 'Default'}</p>
                            </div>
                            
                            <div class="info">
                                <h3>Status:</h3>
                                <ol>
                                    <li>✅ OAuth authorization successful</li>
                                    <li>✅ Authorization code received</li>
                                    <li>✅ Access token obtained</li>
                                    <li>✅ Ready to make Clover API calls</li>
                                </ol>
                            </div>
                            
                            <div class="debug">
                                <h3>Debug Information:</h3>
                                <p><strong>Request ID:</strong> ${context.awsRequestId}</p>
                                <p><strong>Function:</strong> ${context.functionName}</p>
                                <p><strong>Timestamp:</strong> ${new Date().toISOString()}</p>
                            </div>
                            
                            <p><em>Your Clover integration is now active! You can close this window.</em></p>
                        </div>
                    </body>
                    </html>
                `
            };
            
            return successResponse;
            
        } else {
            console.error('=== TOKEN EXCHANGE FAILURE ===');
            console.error('Token exchange failed:', tokenExchangeResult.error);
            console.error('Error details:', tokenExchangeResult.details);
            console.error('HTTP status:', tokenExchangeResult.status);
            
            return {
                statusCode: 400,
                headers: {
                    'Content-Type': 'text/html',
                    'Access-Control-Allow-Origin': '*'
                },
                body: `
                    <!DOCTYPE html>
                    <html>
                    <head>
                        <title>Clover OAuth Error</title>
                        <style>
                            body { 
                                font-family: Arial, sans-serif; 
                                max-width: 600px; 
                                margin: 50px auto; 
                                padding: 20px;
                                background: linear-gradient(135deg, #dc3545 0%, #c82333 100%);
                                min-height: 100vh;
                            }
                            .container {
                                background: white;
                                padding: 30px;
                                border-radius: 10px;
                                box-shadow: 0 10px 30px rgba(0,0,0,0.2);
                            }
                            .error { color: #dc3545; }
                            .info { background: #f8f9fa; padding: 15px; border-radius: 5px; margin: 20px 0; }
                            .debug { background: #fff3cd; padding: 15px; border-radius: 5px; margin: 20px 0; border-left: 4px solid #ffc107; }
                        </style>
                    </head>
                    <body>
                        <div class="container">
                            <h1 class="error">❌ Token Exchange Failed</h1>
                            <div class="info">
                                <p><strong>Error:</strong> ${tokenExchangeResult.error}</p>
                                <p><strong>Details:</strong> ${tokenExchangeResult.details || 'No additional details'}</p>
                                ${tokenExchangeResult.status ? `<p><strong>HTTP Status:</strong> ${tokenExchangeResult.status}</p>` : ''}
                            </div>
                            
                            <div class="debug">
                                <h3>Debug Information:</h3>
                                <p><strong>Request ID:</strong> ${context.awsRequestId}</p>
                                <p><strong>Function:</strong> ${context.functionName}</p>
                                <p><strong>Timestamp:</strong> ${new Date().toISOString()}</p>
                            </div>
                            
                            <p>Check the Lambda logs for more information.</p>
                        </div>
                    </body>
                    </html>
                `
            };
        }
        
    } catch (error) {
        console.error('=== LAMBDA EXECUTION ERROR ===');
        console.error('Lambda execution error:', error);
        console.error('Error stack:', error.stack);
        console.error('Error name:', error.name);
        console.error('Error message:', error.message);
        
        return {
            statusCode: 500,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                error: 'Internal server error',
                message: error.message,
                debug: {
                    timestamp: new Date().toISOString(),
                    requestId: context.awsRequestId,
                    functionName: context.functionName,
                    errorName: error.name,
                    errorStack: error.stack
                }
            })
        };
    }
};
